# BuckDuck · StoreFront USA

Weekly grocery delivery marketplace. Independent grocery stores run their own storefronts; customers fill one cart across many stores, choose a **Saturday delivery window** (6 AM–12 PM or 12 PM–4 PM) and pay by card, Apple Pay or Google Pay. Stores pack orders in BuckDuck bags; BuckDuck drivers pick up and deliver.

**Version 2 — Python microservices.** Six independently deployable services, each with its own database, behind one SEO-friendly website.

| Service | Port (local) | Owns (its own database) | What it does |
|---|---|---|---|
| `web` | 8000 | — (no database) | Server-rendered public website (SEO), the signed-in app at `/app/`, and the API gateway |
| `identity` | 8001 | `users` | Sign-up, sign-in (JWT), roles, profiles, user administration |
| `catalog` | 8002 | `stores`, `products`, stock | Storefronts, products, photos, stock, store approval and commission |
| `orders` | 8003 | `checkouts`, `orders`, items, events | Pricing, checkout, order lifecycle, merchant queue, admin operations, finance |
| `payments` | 8004 | `payments`, `refunds`, `merchant_accounts`, `transfers` | Stripe card / Apple Pay / Google Pay, refunds, Stripe Connect payouts, webhooks |
| `delivery` | 8005 | `delivery_windows`, `drivers`, `delivery_jobs` | Saturday windows and capacity, drivers, job board, routes, proof of delivery |

See **[docs/ARCHITECTURE.md](docs/ARCHITECTURE.md)** for how the services talk to each other and why each can run on its own.

## Run it locally (no Docker)

Requires **Python 3.12+**.

```bash
python -m venv .venv && source .venv/bin/activate     # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python run_local.py                                     # starts all six services
```

Open **http://localhost:8000**. Each service creates its own SQLite database in `./data/` and loads demo data on first start. Every service has interactive API docs at `http://localhost:800X/docs`.

Run only some services — each one starts and works on its own:

```bash
python run_local.py catalog web      # browse stores and products; checkout shows "temporarily unavailable"
```

Demo accounts (password **`demo1234`**): `customer@buckduck.com`, `merchant@buckduck.com`, `driver@buckduck.com`, `admin@buckduck.com`. With `DEMO_MODE=true` a bar at the bottom of every page switches roles in one click. Reset demo data by deleting `./data/`.

## Run it with Docker (PostgreSQL, one database per service)

```bash
python scripts/make_env.py           # writes .env with strong random secrets
docker compose up --build            # postgres + 6 services
```

Open **http://localhost:8000**. PostgreSQL gets five databases (`identity`, `catalog`, `orders`, `payments`, `delivery`), each with its own login that can only reach its own data. Only the `web` container is exposed; the back-end services and the database sit on a private network.

## Deploy

**Render:** push the repository to GitHub, then **New → Blueprint**. `render.yaml` creates the public web service, five private services and five PostgreSQL databases, and generates the shared secrets. Add `PUBLIC_BASE_URL` and your Stripe keys in the dashboard.

**Any container host** (AWS ECS, Google Cloud Run, Azure Container Apps, Fly.io, Kubernetes, a VPS): build each image with `docker build -f services/<name>/Dockerfile .`, give each back-end service its `<NAME>_DATABASE_URL`, give every service the same `JWT_SECRET` and `INTERNAL_TOKEN`, and point each service at the others with `IDENTITY_URL`, `CATALOG_URL`, `ORDERS_URL`, `PAYMENTS_URL`, `DELIVERY_URL`. Expose only `web`.

### Going-live checklist
- [ ] `python scripts/make_env.py --production` (sets `DEMO_MODE=false`, `SEED_DEMO_DATA=false`) or set those yourself
- [ ] `PUBLIC_BASE_URL=https://your-domain` — used for canonical URLs, the sitemap and Stripe return links
- [ ] HTTPS in front of `web` (the host's load balancer or a reverse proxy)
- [ ] Live Stripe keys, webhook, Apple Pay domain (see below)
- [ ] Create your first admin (below), set fees, service ZIP codes and windows in **Admin → Settings**
- [ ] Daily backups of each PostgreSQL database and the catalog media volume
- [ ] Submit `https://your-domain/sitemap.xml` in Google Search Console and Bing Webmaster Tools

**First real admin:** register normally on the site, then run against the identity database:
`UPDATE users SET role='admin' WHERE email='you@yourdomain.com';`

## Payments (Stripe)

Without Stripe keys the payments service runs a simulator, so the whole platform can be demoed end to end.

1. Put `STRIPE_SECRET_KEY` and `STRIPE_PUBLISHABLE_KEY` in `.env` (start with `sk_test_` / `pk_test_`).
2. Stripe Dashboard → Settings → Payment methods: turn on **Cards, Apple Pay, Google Pay** (and Link if wanted). The code uses PaymentIntents with automatic payment methods, so no code change is needed.
3. **Apple Pay domain:** Payment methods → Apple Pay → Add domain. Save the file Stripe gives you as `services/web/static/.well-known/apple-developer-merchantid-domain-association`. Apple Pay appears only over HTTPS in Safari / iOS with a card in Wallet.
4. **Webhook:** Developers → Webhooks → endpoint `https://YOUR-DOMAIN/api/stripe/webhook`, events `payment_intent.succeeded`, `payment_intent.payment_failed`, `account.updated`. Put the signing secret in `STRIPE_WEBHOOK_SECRET`.
5. **Store payouts:** Connect → enable Express accounts. Merchants click **Connect with Stripe** on their Payouts page. When an order is delivered, the store's share is transferred automatically; transfers for stores that haven't connected yet wait and are sent as soon as they do.

## SEO

The public site is rendered on the server, so search engines see complete pages without running JavaScript:

- Real URLs: `/stores`, `/categories/african-groceries`, `/stores/accra-market`, `/products/1-gari-white-4-lb`, `/how-it-works`, `/sell`, `/drive`
- Unique `<title>`, meta description, canonical link, Open Graph and Twitter tags on every page; one `<h1>` per page; breadcrumbs
- JSON-LD structured data: `Organization`, `WebSite` + `SearchAction`, `GroceryStore` with address and offer catalog, `Product` + `Offer` (price, availability), `ItemList`, `BreadcrumbList`, `FAQPage`
- Live `/sitemap.xml` (every store, category and product, with last-modified dates) and `/robots.txt`
- 301 redirects to canonical product URLs, real 404 status for missing pages, `noindex` on search results and the signed-in app
- Fast: no JavaScript needed to read a page, gzip, caching headers, lazy-loaded images, `font-display: swap`

## Tests

```bash
pytest -q tests                                                     # SQLite
TEST_PG_BASE="postgresql://user:pw@localhost:5432/" pytest -q tests # PostgreSQL (needs databases test_identity … test_delivery)
```

The suite starts its own copy of every service and covers the full order lifecycle, cancellations and refunds, every dashboard endpoint, security (roles, forged tokens, internal endpoints), SEO output, and **independence**: it stops services mid-test and checks that the rest keep working and that queued events are delivered once the stopped service returns.

## Repository layout

```
services/
  common/buckduck_common/   shared infrastructure only: config, database, auth, service calls, outbox, seed data
  identity/  catalog/  orders/  payments/  delivery/   one service.py + Dockerfile each
  web/       service.py (pages + gateway), templates/ (Jinja2), static/ (CSS, app.js, site.js, icons, PWA)
infra/postgres/init-databases.sh   creates one database + login per service
docker-compose.yml  render.yaml  requirements.txt  run_local.py  scripts/make_env.py
tests/              end-to-end and independence tests
docs/               architecture guide, business plan, business requirements, illustration
```

## Mobile app

The site and the driver app are an installable Progressive Web App (iPhone: Safari → Share → Add to Home Screen; Android: Install prompt). For App Store / Google Play listings, wrap the same site with [Capacitor](https://capacitorjs.com).
