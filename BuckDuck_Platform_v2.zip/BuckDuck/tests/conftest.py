"""Spins up a private copy of the platform (one process per service, fresh databases) for the tests."""
from __future__ import annotations

import os
import subprocess
import sys
import tempfile
import time
from pathlib import Path

import httpx
import pytest

ROOT = Path(__file__).resolve().parents[1]
PORTS = {"identity": 9101, "catalog": 9102, "orders": 9103, "payments": 9104, "delivery": 9105, "web": 9100}


class Stack:
    def __init__(self):
        self.tmp = tempfile.mkdtemp(prefix="buckduck-test-")
        self.procs: dict[str, subprocess.Popen] = {}
        self.env = dict(os.environ, DATA_DIR=self.tmp, DEMO_MODE="true", SEED_DEMO_DATA="true",
                        JWT_SECRET="test-jwt", INTERNAL_TOKEN="test-internal",
                        **{f"{n.upper()}_URL": f"http://127.0.0.1:{p}" for n, p in PORTS.items()})
        for k in ("DATABASE_URL", "STRIPE_SECRET_KEY") + tuple(f"{n.upper()}_DATABASE_URL" for n in PORTS):
            self.env.pop(k, None)
        if os.environ.get("TEST_PG_BASE"):   # e.g. postgresql://user:pw@localhost:5432/  → one database per service
            for n in PORTS:
                if n != "web":
                    self.env[f"{n.upper()}_DATABASE_URL"] = os.environ["TEST_PG_BASE"] + f"test_{n}"

    def url(self, name: str) -> str:
        return f"http://127.0.0.1:{PORTS[name]}"

    def start(self, *names: str) -> None:
        for n in names:
            if n in self.procs and self.procs[n].poll() is None:
                continue
            env = dict(self.env, PYTHONPATH=os.pathsep.join([str(ROOT / "services" / "common"), str(ROOT / "services" / n)]))
            self.procs[n] = subprocess.Popen([sys.executable, "-m", "uvicorn", "service:app", "--host", "127.0.0.1", "--port", str(PORTS[n]),
                                              "--log-level", "warning"], cwd=ROOT / "services" / n, env=env)
        for n in names:
            for _ in range(80):
                try:
                    if httpx.get(self.url(n) + "/healthz", timeout=1).status_code == 200:
                        break
                except httpx.HTTPError:
                    pass
                time.sleep(0.25)
            else:
                raise RuntimeError(f"{n} did not start")

    def stop(self, *names: str) -> None:
        for n in names:
            p = self.procs.pop(n, None)
            if p:
                p.terminate()
                p.wait(timeout=10)

    def stop_all(self) -> None:
        self.stop(*list(self.procs))


@pytest.fixture(scope="session")
def stack():
    s = Stack()
    s.start("identity", "catalog", "orders", "payments", "delivery", "web")
    yield s
    s.stop_all()


@pytest.fixture(scope="session")
def web(stack):
    return stack.url("web")


def login(web: str, email: str) -> dict:
    r = httpx.post(web + "/api/auth/login", json={"email": email, "password": "demo1234"})
    r.raise_for_status()
    return {"Authorization": "Bearer " + r.json()["token"]}


def wait_for(fn, timeout: float = 15.0, every: float = 0.3):
    end = time.time() + timeout
    last = None
    while time.time() < end:
        last = fn()
        if last:
            return last
        time.sleep(every)
    return last
