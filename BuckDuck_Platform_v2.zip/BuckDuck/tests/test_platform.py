"""End-to-end tests through the public gateway, plus service-independence and resilience tests.

Run:  pytest -q tests        (starts its own copy of every service on ports 9100-9105)
"""
from __future__ import annotations

import json
import re

import httpx
import pytest

from conftest import login, wait_for

ADDR = {"line1": "8800 Bellaire Blvd", "city": "Houston", "state": "TX", "zip": "77036"}


def place_order(web: str, cust: dict, slug: str = "accra-market", method: str = "card") -> dict:
    products = httpx.get(f"{web}/api/stores/{slug}").json()["products"][:3]
    items = [{"product_id": p["id"], "qty": 2} for p in products]
    win = next(w for w in httpx.get(web + "/api/windows").json()["windows"] if w["open"])
    co = httpx.post(web + "/api/checkout", headers=cust, json={"items": items, "tip_cents": 400, "window_id": win["id"], "address": ADDR, "phone": "713-555-0000"})
    assert co.status_code == 200, co.text
    r = httpx.post(f"{web}/api/checkout/{co.json()['checkout_id']}/confirm", headers=cust, json={"payment_method": method})
    assert r.status_code == 200, r.text
    return r.json()["orders"][0]


# ------------------------------------------------------------------ full lifecycle
def test_full_order_lifecycle(web):
    cust, merch, drv = login(web, "customer@buckduck.com"), login(web, "merchant@buckduck.com"), login(web, "driver@buckduck.com")
    before = {p["id"]: p["stock"] for p in httpx.get(web + "/api/stores/accra-market").json()["products"][:3]}
    o = place_order(web, cust, method="apple_pay")
    assert o["status"] == "placed" and o["payment_method"] == "apple_pay"
    # catalog decremented stock (event via outbox)
    after = wait_for(lambda: (lambda d: d if all(d[k] == before[k] - 2 for k in before) else None)(
        {p["id"]: p["stock"] for p in httpx.get(web + "/api/stores/accra-market").json()["products"][:3]}))
    assert after, "stock was not decremented"
    for st in ("accepted", "packing"):
        assert httpx.post(f"{web}/api/merchant/orders/{o['id']}/status", headers=merch, json={"status": st}).status_code == 200
    assert httpx.post(f"{web}/api/merchant/orders/{o['id']}/status", headers=merch, json={"status": "ready", "bags": 2}).status_code == 200
    assert wait_for(lambda: any(j["id"] == o["id"] for j in httpx.get(web + "/api/driver/available", headers=drv).json()["orders"]))
    httpx.post(web + "/api/driver/online", headers=drv, json={"online": True})
    assert httpx.post(f"{web}/api/driver/orders/{o['id']}/claim", headers=drv).status_code == 200
    assert httpx.post(f"{web}/api/driver/orders/{o['id']}/status", headers=drv, json={"status": "picked_up"}).status_code == 200
    assert httpx.post(f"{web}/api/driver/orders/{o['id']}/status", headers=drv, json={"status": "delivered", "proof_note": "Handed to customer"}).status_code == 200
    final = wait_for(lambda: (lambda x: x if x["status"] == "delivered" else None)(httpx.get(f"{web}/api/orders/{o['id']}", headers=cust).json()["order"]))
    assert final and final["driver_name"] == "Kwame Asante"
    assert [e["status"] for e in final["events"]][-2:] == ["picked_up", "delivered"]
    # store connects payouts → queued transfer is paid
    assert httpx.post(web + "/api/merchant/stripe/onboard", headers=merch).json()["connected"]
    weeks = httpx.get(web + "/api/merchant/payouts", headers=merch).json()["weeks"]
    assert any(w["transferred"] for w in weeks)


def test_customer_cancel_refunds_and_restores_stock(web):
    cust = login(web, "customer@buckduck.com")
    o = place_order(web, cust, slug="lagos-pantry")
    pid = httpx.get(f"{web}/api/orders/{o['id']}", headers=cust).json()["order"]["items"][0]["product_id"]
    stock = lambda: next(p["stock"] for p in httpx.get(web + "/api/stores/lagos-pantry").json()["products"] if p["id"] == pid)  # noqa: E731
    reduced = wait_for(lambda: stock())
    r = httpx.post(f"{web}/api/orders/{o['id']}/cancel", headers=cust)
    assert r.status_code == 200 and r.json()["order"]["status"] == "cancelled"
    assert wait_for(lambda: stock() == reduced + 2)


def test_checkout_validation(web):
    cust = login(web, "customer@buckduck.com")
    win = next(w for w in httpx.get(web + "/api/windows").json()["windows"] if w["open"])
    small = httpx.post(web + "/api/checkout", headers=cust, json={"items": [{"product_id": 17, "qty": 1}], "window_id": win["id"], "address": ADDR, "phone": "1"})
    assert small.status_code == 400 and "Minimum order" in small.json()["error"]
    q = httpx.post(web + "/api/checkout/quote", json={"items": [{"product_id": 1, "qty": 2, "price_cents": 1}]}).json()
    assert q["subtotal_cents"] == 1798, "client-sent prices must be ignored"


def test_every_dashboard_endpoint(web):
    """Every read endpoint behind the merchant portal, driver app and admin console answers correctly."""
    roles = {"merchant@buckduck.com": ["/api/me", "/api/merchant/summary", "/api/merchant/orders", "/api/merchant/orders?scope=all",
                                       "/api/merchant/products", "/api/merchant/store", "/api/merchant/payouts"],
             "driver@buckduck.com": ["/api/me", "/api/driver/summary", "/api/driver/available", "/api/driver/route", "/api/driver/history"],
             "admin@buckduck.com": ["/api/admin/overview", "/api/admin/orders", "/api/admin/orders?status=ready&q=bd", "/api/admin/stores",
                                    "/api/admin/users", "/api/admin/users?role=driver&q=a", "/api/admin/drivers", "/api/admin/windows",
                                    "/api/admin/finance", "/api/admin/settings"],
             "customer@buckduck.com": ["/api/me", "/api/orders"]}
    for email, paths in roles.items():
        h = login(web, email)
        for p in paths:
            r = httpx.get(web + p, headers=h)
            assert r.status_code == 200, f"{email} {p}: {r.status_code} {r.text[:200]}"
    admin = login(web, "admin@buckduck.com")
    s = httpx.put(web + "/api/admin/settings", headers=admin, json={"delivery_fee_cents": "649", "default_commission_rate": "0.12", "order_cutoff_hours": "20"}).json()["settings"]
    assert (s["delivery_fee_cents"], s["default_commission_rate"], s["order_cutoff_hours"]) == ("649", "0.12", "20")
    httpx.put(web + "/api/admin/settings", headers=admin, json={"delivery_fee_cents": "599", "default_commission_rate": "0.15", "order_cutoff_hours": "24"})
    assert httpx.post(web + "/api/admin/stores/7", headers=admin, json={"status": "active"}).json()["store"]["status"] == "active"
    delivered = httpx.get(web + "/api/admin/orders?status=delivered", headers=admin).json()["orders"][0]
    r = httpx.post(f"{web}/api/admin/orders/{delivered['id']}/refund", headers=admin, json={"amount_cents": 300, "reason": "Bruised plantains"})
    assert r.status_code == 200 and "Partial refund" in r.json()["order"]["events"][-1]["note"]


# ------------------------------------------------------------------ security
def test_roles_and_internal_endpoints_are_protected(stack, web):
    cust = login(web, "customer@buckduck.com")
    assert httpx.get(web + "/api/admin/overview", headers=cust).status_code == 403
    assert httpx.get(web + "/api/merchant/summary", headers=cust).status_code == 403
    assert httpx.get(web + "/api/orders").status_code == 401
    assert httpx.get(web + "/api/admin/overview", headers={"Authorization": "Bearer forged.token.value"}).status_code == 401
    for svc, path in (("orders", "/internal/checkouts/1/paid"), ("delivery", "/internal/jobs"), ("payments", "/internal/refunds")):
        assert httpx.post(stack.url(svc) + path, json={}).status_code == 403
    assert httpx.get(web + "/internal/stats").status_code == 404, "gateway must never expose internal endpoints"
    assert httpx.post(web + "/api/auth/login", json={"email": "admin@buckduck.com", "password": "wrong"}).status_code == 401


# ------------------------------------------------------------------ SEO
def test_seo_pages(web):
    for path, ld_type in (("/", "Organization"), ("/stores/accra-market", "GroceryStore"), ("/products/1-gari-white-4-lb", "Product"), ("/how-it-works", "FAQPage")):
        r = httpx.get(web + path)
        assert r.status_code == 200
        html = r.text
        assert re.search(r"<title>[^<]{20,}</title>", html)
        assert '<meta name="description"' in html and '<link rel="canonical"' in html and 'property="og:title"' in html
        blocks = [json.loads(b) for b in re.findall(r'<script type="application/ld\+json">(.*?)</script>', html, re.S)]
        assert ld_type in [b["@type"] for b in blocks]
        assert html.count("<h1") == 1
    assert httpx.get(web + "/products/1", follow_redirects=False).status_code == 301
    assert httpx.get(web + "/stores/does-not-exist").status_code == 404
    sm = httpx.get(web + "/sitemap.xml").text
    assert sm.count("<url>") > 60 and "/stores/accra-market" in sm
    assert "Disallow: /app/" in httpx.get(web + "/robots.txt").text
    assert "noindex" in httpx.get(web + "/search?q=yam").text


# ------------------------------------------------------------------ independence & resilience
def test_browsing_works_while_orders_and_payments_are_down(stack, web):
    stack.stop("orders", "payments")
    try:
        assert httpx.get(web + "/").status_code == 200
        assert httpx.get(web + "/stores/accra-market").status_code == 200
        assert httpx.get(web + "/api/stores").status_code == 200
        r = httpx.post(web + "/api/checkout/quote", json={"items": [{"product_id": 1, "qty": 1}]})
        assert r.status_code == 503 and "temporarily unavailable" in r.json()["error"]
        cfg = httpx.get(web + "/api/config").json()   # composite endpoint falls back to defaults
        assert cfg["delivery_fee_cents"] == 599
    finally:
        stack.start("orders", "payments")


def test_admin_overview_degrades_when_a_service_is_down(stack, web):
    admin = login(web, "admin@buckduck.com")
    stack.stop("identity")
    try:
        d = httpx.get(web + "/api/admin/overview", headers=admin)   # token is verified locally — no identity call needed
        assert d.status_code == 200
        assert "identity" in d.json()["degraded_services"]
    finally:
        stack.start("identity")


def test_events_are_retried_when_delivery_is_down(stack, web):
    cust = login(web, "customer@buckduck.com")
    stack.stop("delivery")
    try:
        products = httpx.get(web + "/api/stores/green-valley-produce").json()["products"][:4]
        # delivery is down, so the window cannot be verified: checkout must refuse cleanly
        r = httpx.post(web + "/api/checkout", headers=cust, json={"items": [{"product_id": p["id"], "qty": 3} for p in products], "window_id": 17,
                                                                  "address": ADDR, "phone": "1"})
        assert r.status_code == 503
    finally:
        stack.start("delivery")
    o = place_order(web, cust, slug="green-valley-produce")
    merch = login(web, "greenvalley@buckduck.com")
    stack.stop("delivery")
    try:
        assert httpx.post(f"{web}/api/merchant/orders/{o['id']}/status", headers=merch, json={"status": "accepted"}).status_code == 200
        assert httpx.get(stack.url("orders") + "/healthz").json()["outbox_pending"] >= 1   # event is waiting, not lost
    finally:
        stack.start("delivery")
    assert wait_for(lambda: httpx.get(stack.url("orders") + "/healthz").json()["outbox_pending"] == 0, timeout=30)


def test_each_service_starts_alone_with_its_own_database(stack):
    for svc in ("identity", "catalog", "orders", "payments", "delivery"):
        h = httpx.get(stack.url(svc) + "/healthz").json()
        assert h["ok"] and h["database"] == "ok"
        assert httpx.get(stack.url(svc) + "/openapi.json").status_code == 200


if __name__ == "__main__":
    raise SystemExit(pytest.main([__file__, "-q"]))
