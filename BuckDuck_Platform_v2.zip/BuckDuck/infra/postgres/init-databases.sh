#!/bin/sh
# Runs once, when the PostgreSQL volume is first created.
# Each service gets its own database and its own login, and can only reach its own data.
set -eu
for svc in identity catalog orders payments delivery; do
  upper=$(echo "$svc" | tr '[:lower:]' '[:upper:]')
  pw=$(eval echo "\${${upper}_DB_PASSWORD}")
  psql -v ON_ERROR_STOP=1 --username "$POSTGRES_USER" --dbname postgres <<SQL
CREATE ROLE ${svc}_svc LOGIN PASSWORD '${pw}';
CREATE DATABASE ${svc} OWNER ${svc}_svc;
REVOKE ALL ON DATABASE ${svc} FROM PUBLIC;
SQL
done
echo "Created databases: identity catalog orders payments delivery"
