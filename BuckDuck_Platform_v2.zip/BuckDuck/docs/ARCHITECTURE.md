# BuckDuck architecture

## Overview

```mermaid
flowchart LR
  B[Browser / PWA<br/>shoppers · merchants · drivers · admins] -->|HTTPS| W[web<br/>SEO pages + API gateway]
  W --> I[identity]
  W --> C[catalog]
  W --> O[orders]
  W --> P[payments]
  W --> D[delivery]
  I --- IDB[(identity DB)]
  C --- CDB[(catalog DB)]
  O --- ODB[(orders DB)]
  P --- PDB[(payments DB)]
  D --- DDB[(delivery DB)]
  S[Stripe] -->|webhooks| W
  P -->|PaymentIntents · refunds · transfers| S
  O -. events .-> D
  O -. events .-> C
  O -. events .-> P
  D -. events .-> O
  P -. events .-> O
  I -. events .-> D
```

## Principles

1. **Database per service.** No service reads another service's tables. In production each database also has its own login, so isolation is enforced by PostgreSQL, not just by convention.
2. **Snapshots instead of joins.** An order stores the store name, address, customer, window and driver as they were at purchase. Receipts, history and finance reports never depend on another service being online.
3. **Local token checks.** `identity` signs a JWT (HS256, 7-day expiry) containing the user id and role. Every service verifies it itself, so signing in is the only step that needs identity running.
4. **Two kinds of calls.**
   - *Synchronous HTTP* (`buckduck_common.http.call`) only where the user is waiting for an answer, such as checkout needing current prices from catalog. If the other service is down, the caller returns a clear `503 … temporarily unavailable` message.
   - *Events through a transactional outbox* (`buckduck_common.outbox`) for everything else. The event is written in the same database transaction as the change, then delivered. If the receiver is down it is retried with backoff (up to 5 minutes between tries) until it succeeds. Receivers are idempotent.
5. **Graceful degradation.** `try_call` returns a fallback when an optional dependency is down. For example, the admin overview still loads without identity and lists the missing service in `degraded_services`, and the composite `/api/config` falls back to defaults.
6. **Internal endpoints are private.** `/internal/*` routes require `X-Internal-Token` and are never routed by the gateway. Only `web` is exposed to the internet.

## Who owns what

| Data / rule | Owner | Others get it via |
|---|---|---|
| Users, passwords, roles | identity | JWT claims; `/internal/users` |
| Stores, products, prices, stock, commission rate | catalog | `/internal/products/lookup` at checkout; stock events |
| Fees, checkout, orders, order status | orders | snapshots copied into delivery jobs; events |
| Payments, refunds, store bank accounts, transfers | payments | `/internal/payments/*`; paid events |
| Delivery windows, capacity, drivers, jobs, proof of delivery | delivery | `/internal/windows/{id}`; delivery events |

## Event catalog

| Event (outbox → endpoint) | From → To | When | Receiver's job |
|---|---|---|---|
| `POST /internal/stock/decrement` | orders → catalog | order paid | reduce stock once per order |
| `POST /internal/stock/restore` | orders → catalog | order cancelled | put stock back once per order |
| `POST /internal/jobs` | orders → delivery | order paid | create the delivery job (counts toward window capacity) |
| `POST /internal/jobs/{id}/sync` | orders → delivery | any status change | mirror status / bag count on the job |
| `POST /internal/transfers` | orders → payments | order delivered | pay the store its share (waits if Stripe not connected) |
| `POST /internal/checkouts/{id}/paid` | payments → orders | Stripe webhook succeeded | release the order to the store |
| `POST /internal/orders/{id}/delivery-event` | delivery → orders | assigned · released · picked_up · delivered | update status, driver and proof on the order |
| `POST /internal/drivers` | identity → delivery | driver signs up / edits profile | create or update the driver profile |
| `POST /internal/drivers/{id}/status` | identity → delivery | admin suspends a driver | take them offline and release open jobs |

## Order lifecycle

`pending_payment → placed → accepted → packing → ready (+ bag count) → picked_up → delivered`, with `cancelled` (customer before acceptance, store before packing, or admin) and `refunded` (admin, full or partial).

## Gateway routing (web)

| Path prefix | Service |
|---|---|
| `/api/auth`, `/api/me`, `/api/admin/users` | identity |
| `/api/stores`, `/api/products`, `/api/search`, `/api/catalog`, `/api/merchant/store`, `/api/merchant/products`, `/api/admin/stores` | catalog |
| `/api/windows`, `/api/driver`, `/api/admin/windows`, `/api/admin/drivers` | delivery |
| `/api/payments`, `/api/merchant/stripe`, `/api/stripe` | payments |
| `/api/checkout`, `/api/orders`, `/api/merchant/*`, `/api/admin/*` (rest) | orders |
| `/api/config`, `/api/admin/settings` | composed by web from several services |

## Scaling notes

- Every service is stateless apart from its database, so you can run several copies behind a load balancer (`WEB_CONCURRENCY` sets workers per container).
- The outbox works with several copies of a service. Events may occasionally be delivered twice, which receivers already handle.
- When volume grows, swap the HTTP outbox delivery for a message broker (RabbitMQ, SQS, Pub/Sub) without changing business code: only `Outbox.flush` changes.
- Product photos are served by catalog from a volume. Move them to S3-compatible storage by changing `save_image` in `buckduck_common.util`.
