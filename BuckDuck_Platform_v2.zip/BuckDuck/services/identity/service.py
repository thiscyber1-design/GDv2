"""Identity service — accounts, sign-in, roles and user administration.

Owns: users. Database: its own (IDENTITY_DATABASE_URL).
Issues the JWT every other service verifies on its own.
"""
from __future__ import annotations

import re

from fastapi import Depends, HTTPException, Request
from sqlalchemy import Column, Integer, MetaData, String, Table

from buckduck_common import seed
from buckduck_common.app import create_app
from buckduck_common.auth import create_token, hash_password, internal_only, require, verify_password
from buckduck_common.config import database_url, env
from buckduck_common.db import Database
from buckduck_common.http import ServiceUnavailable, call, try_call
from buckduck_common.outbox import Outbox, outbox_table
from buckduck_common.util import now_iso, req, s

md = MetaData()
Table("users", md,
      Column("id", Integer, primary_key=True, autoincrement=True),
      Column("email", String(120), unique=True, nullable=False),
      Column("password_hash", String(200), nullable=False),
      Column("name", String(80), nullable=False),
      Column("role", String(20), nullable=False, index=True),
      Column("phone", String(30)),
      Column("status", String(20), nullable=False, default="active"),
      Column("created_at", String(40), nullable=False))
outbox_table(md)

db = Database(database_url("identity"), md)
outbox = Outbox(db)
app = create_app("identity", "Accounts, authentication and user administration.", db=db, outbox=outbox)
EMAIL_RE = re.compile(r"^[^\s@]+@[^\s@]+\.[^\s@]+$")


def public_user(u: dict) -> dict:
    return {k: u.get(k) for k in ("id", "email", "name", "role", "phone", "status", "created_at")}


@app.on_event("startup")
def startup():
    db.create_all()
    if env("SEED_DEMO_DATA", "true") == "true" and not db.scalar("SELECT COUNT(*) FROM users"):
        pw = hash_password(seed.DEMO_PASSWORD)
        with db.tx() as t:
            t.insert_many("users", [dict(id=u["id"], email=u["email"], password_hash=pw, name=u["name"], role=u["role"], phone=u["phone"],
                                         status=u["status"], created_at=u["created_at"]) for u in seed.dataset()["users"]])
        db.fix_sequences(["users"])
    outbox.start()


# ---------------------------------------------------------------- public
@app.post("/api/auth/register", tags=["auth"])
def register(body: dict):
    role = body.get("role") if body.get("role") in ("customer", "merchant", "driver") else "customer"
    email = req(body.get("email"), "Email", 120).lower()
    if not EMAIL_RE.match(email):
        raise HTTPException(400, "Enter a valid email")
    password = str(body.get("password") or "")
    if len(password) < 8:
        raise HTTPException(400, "Password must be at least 8 characters")
    name = req(body.get("name"), "Name", 80)
    if db.one("SELECT id FROM users WHERE email=:e", e=email):
        raise HTTPException(409, "An account with that email already exists")
    if role == "merchant":
        req(body.get("store_name"), "Store name", 80)
    phone = s(body.get("phone"), 30)
    with db.tx() as t:
        uid = t.insert("users", dict(email=email, password_hash=hash_password(password), name=name, role=role, phone=phone,
                                     status="active", created_at=now_iso()))
        if role == "driver":
            outbox.enqueue(t, "delivery", "/internal/drivers", dict(id=uid, name=name, phone=phone, vehicle=s(body.get("vehicle"), 80), status="active"))
    if role == "merchant":
        # A merchant account is useless without its store, so this call is synchronous with compensation.
        try:
            call("catalog", "POST", "/internal/stores", json=dict(owner_id=uid, name=body.get("store_name"), category=body.get("category"),
                                                                     address=body.get("address"), city=body.get("city"), state=body.get("state"),
                                                                     zip=body.get("zip"), phone=phone, tagline=body.get("tagline"), description=body.get("description")))
        except Exception:
            db.one("DELETE FROM users WHERE id=:id RETURNING id", id=uid)
            raise
    outbox.flush()
    user = db.one("SELECT * FROM users WHERE id=:id", id=uid)
    return {"token": create_token(user), "user": public_user(user)}


@app.post("/api/auth/login", tags=["auth"])
def login(body: dict, request: Request):
    _rate_limit(request)
    user = db.one("SELECT * FROM users WHERE email=:e", e=s(body.get("email"), 120).lower())
    if not user or not verify_password(str(body.get("password") or ""), user["password_hash"]):
        raise HTTPException(401, "Incorrect email or password")
    if user["status"] != "active":
        raise HTTPException(403, "This account is suspended. Contact support.")
    return {"token": create_token(user), "user": public_user(user)}


_hits: dict[str, list[float]] = {}


def _rate_limit(request: Request) -> None:
    import time
    ip = request.headers.get("x-forwarded-for", request.client.host if request.client else "?").split(",")[0].strip()
    now = time.time()
    h = [t for t in _hits.get(ip, []) if now - t < 900]
    h.append(now)
    _hits[ip] = h
    if len(h) > 30:
        raise HTTPException(429, "Too many attempts. Try again in a few minutes.")


@app.get("/api/me", tags=["account"])
def me(user=Depends(require())):
    u = db.one("SELECT * FROM users WHERE id=:id", id=user["id"])
    if not u or u["status"] != "active":
        raise HTTPException(401, "Please sign in to continue")
    out = {"user": public_user(u)}
    if u["role"] == "merchant":
        out["store"] = try_call("catalog", "GET", f"/internal/stores/by-owner/{u['id']}", fallback={}).get("store")
    if u["role"] == "driver":
        d = try_call("delivery", "GET", f"/internal/drivers/{u['id']}", fallback={}).get("driver") or {}
        out["user"].update(vehicle=d.get("vehicle"), driver_online=bool(d.get("online")))
    return out


@app.put("/api/me", tags=["account"])
def update_me(body: dict, user=Depends(require())):
    u = db.one("SELECT * FROM users WHERE id=:id", id=user["id"])
    name = req(body.get("name") or u["name"], "Name", 80)
    phone = s(body.get("phone") if body.get("phone") is not None else u["phone"], 30)
    with db.tx() as t:
        t.run("UPDATE users SET name=:n, phone=:p WHERE id=:id", n=name, p=phone, id=u["id"])
        if u["role"] == "driver":
            outbox.enqueue(t, "delivery", "/internal/drivers", dict(id=u["id"], name=name, phone=phone, vehicle=s(body.get("vehicle"), 80) or None))
    outbox.flush()
    return {"user": public_user(db.one("SELECT * FROM users WHERE id=:id", id=u["id"]))}


# ---------------------------------------------------------------- admin
@app.get("/api/admin/users", tags=["admin"])
def admin_users(role: str = "", q: str = "", _=Depends(require("admin"))):
    sql = "SELECT * FROM users WHERE (LOWER(name) LIKE :q OR LOWER(email) LIKE :q)"
    p = {"q": f"%{q.lower()[:60]}%"}
    if role:
        sql += " AND role=:r"
        p["r"] = role
    users = db.all(sql + " ORDER BY created_at DESC LIMIT 300", **p)
    counts = try_call("orders", "GET", "/internal/stats/customer-order-counts", fallback={}) or {}
    return {"users": [dict(public_user(u), order_count=int(counts.get(str(u["id"]), 0))) for u in users]}


@app.post("/api/admin/users/{uid}", tags=["admin"])
def admin_user_status(uid: int, body: dict, admin=Depends(require("admin"))):
    u = db.one("SELECT * FROM users WHERE id=:id", id=uid)
    if not u:
        raise HTTPException(404, "User not found")
    if u["id"] == admin["id"]:
        raise HTTPException(400, "You cannot change your own account status")
    status = body.get("status") if body.get("status") in ("active", "suspended") else u["status"]
    with db.tx() as t:
        t.run("UPDATE users SET status=:s WHERE id=:id", s=status, id=uid)
        if u["role"] == "driver":
            outbox.enqueue(t, "delivery", f"/internal/drivers/{uid}/status", {"status": status})
    outbox.flush()
    return {"user": public_user(db.one("SELECT * FROM users WHERE id=:id", id=uid))}


# ---------------------------------------------------------------- internal (service-to-service)
@app.get("/internal/users", dependencies=[Depends(internal_only)], tags=["internal"])
def internal_users(ids: str = ""):
    id_list = [int(x) for x in ids.split(",") if x.strip().isdigit()][:500]
    if not id_list:
        return {"users": []}
    rows = db.all(f"SELECT * FROM users WHERE id IN ({','.join(str(i) for i in id_list)})")
    return {"users": [public_user(u) for u in rows]}


@app.get("/internal/stats", dependencies=[Depends(internal_only)], tags=["internal"])
def internal_stats():
    return {r["role"]: r["c"] for r in db.all("SELECT role, COUNT(*) AS c FROM users GROUP BY role")}


__all__ = ["app", "ServiceUnavailable"]
