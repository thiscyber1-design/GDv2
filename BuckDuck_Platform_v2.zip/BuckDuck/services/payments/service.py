"""Payments service — Stripe PaymentIntents (card, Apple Pay, Google Pay, Link), refunds,
Stripe Connect onboarding for stores, payouts (transfers) and Stripe webhooks.

Owns: payments, refunds, merchant_accounts, transfers. Database: its own (PAYMENTS_DATABASE_URL).
Card data never reaches BuckDuck: Stripe Elements collects it in Stripe-hosted fields.
Without STRIPE_SECRET_KEY the service runs a safe simulator so the whole platform can be demoed.
"""
from __future__ import annotations

import logging
import secrets

from fastapi import Depends, HTTPException, Request
from sqlalchemy import Column, Integer, MetaData, String, Table, Text

from buckduck_common.app import create_app
from buckduck_common.auth import internal_only, require
from buckduck_common.config import database_url, env
from buckduck_common.db import Database
from buckduck_common.http import call
from buckduck_common.outbox import Outbox, outbox_table
from buckduck_common.util import now_iso, s, to_int

md = MetaData()
Table("payments", md,
      Column("id", Integer, primary_key=True, autoincrement=True),
      Column("checkout_id", Integer, unique=True, nullable=False), Column("customer_id", Integer, nullable=False),
      Column("amount_cents", Integer, nullable=False), Column("currency", String(3), nullable=False, default="usd"),
      Column("status", String(30), nullable=False),   # requires_payment | succeeded | failed | refunded | partially_refunded
      Column("method", String(30)), Column("provider", String(20), nullable=False), Column("provider_ref", String(120), index=True),
      Column("client_secret", String(200)), Column("created_at", String(40), nullable=False), Column("updated_at", String(40)))
Table("refunds", md,
      Column("id", Integer, primary_key=True, autoincrement=True),
      Column("payment_id", Integer, nullable=False, index=True), Column("order_id", Integer),
      Column("amount_cents", Integer, nullable=False), Column("reason", Text), Column("provider_ref", String(120)),
      Column("created_at", String(40), nullable=False))
Table("merchant_accounts", md,
      Column("store_id", Integer, primary_key=True, autoincrement=False), Column("owner_id", Integer),
      Column("account_id", String(120)), Column("charges_enabled", Integer, nullable=False, default=0),
      Column("updated_at", String(40)))
Table("transfers", md,
      Column("id", Integer, primary_key=True, autoincrement=True),
      Column("order_id", Integer, unique=True, nullable=False), Column("store_id", Integer, nullable=False, index=True),
      Column("amount_cents", Integer, nullable=False), Column("status", String(20), nullable=False),   # pending_account | paid | failed
      Column("provider_ref", String(120)), Column("created_at", String(40), nullable=False), Column("updated_at", String(40)))
outbox_table(md)

db = Database(database_url("payments"), md)
outbox = Outbox(db)
app = create_app("payments", "Stripe payments, refunds, store payouts and webhooks.", db=db, outbox=outbox)

log = logging.getLogger("buckduck.payments")
STRIPE_KEY = env("STRIPE_SECRET_KEY")
MODE = "stripe" if STRIPE_KEY else "demo"
if STRIPE_KEY:
    import stripe
    stripe.api_key = STRIPE_KEY


@app.on_event("startup")
def startup():
    db.create_all()
    outbox.start()


def _wallet_method(pi) -> str:
    pm = getattr(pi, "payment_method", None)
    try:
        if pm and not isinstance(pm, str):
            wallet = getattr(getattr(pm, "card", None), "wallet", None)
            if wallet and getattr(wallet, "type", None):
                return wallet.type   # apple_pay | google_pay | link
            return pm.type or "card"
    except Exception:  # noqa: BLE001
        pass
    return "card"


# ---------------------------------------------------------------- public
@app.get("/api/payments/config", tags=["payments"])
def payments_config():
    return {"mode": MODE, "publishableKey": env("STRIPE_PUBLISHABLE_KEY") if MODE == "stripe" else None, "country": "US", "currency": "usd"}


@app.post("/api/merchant/stripe/onboard", tags=["merchant"])
def merchant_onboard(request: Request, user=Depends(require("merchant"))):
    store = call("catalog", "GET", f"/internal/stores/by-owner/{user['id']}").get("store")
    if not store:
        raise HTTPException(404, "No store found for this account")
    acct = db.one("SELECT * FROM merchant_accounts WHERE store_id=:s", s=store["id"])
    origin = env("PUBLIC_BASE_URL") or str(request.base_url).rstrip("/")
    return_url = f"{origin}/app/#/merchant/payouts"
    if MODE == "demo":
        aid = (acct or {}).get("account_id") or f"acct_demo_{secrets.token_hex(6)}"
        _save_account(store, user, aid, True)
        _retry_pending_transfers(store["id"])
        return {"url": None, "connected": True}
    aid = (acct or {}).get("account_id")
    if not aid:
        a = stripe.Account.create(type="express", country="US", email=user["email"], business_type="company",
                                  business_profile={"name": store["name"], "mcc": "5411", "product_description": "Grocery store on the BuckDuck marketplace"},
                                  capabilities={"transfers": {"requested": True}}, metadata={"store_id": str(store["id"])})
        aid = a.id
    a = stripe.Account.retrieve(aid)
    enabled = bool(a.charges_enabled or a.payouts_enabled)
    _save_account(store, user, aid, enabled)
    if enabled:
        return {"url": stripe.Account.create_login_link(aid).url, "connected": True}
    link = stripe.AccountLink.create(account=aid, refresh_url=return_url, return_url=return_url, type="account_onboarding")
    return {"url": link.url, "connected": False}


def _save_account(store: dict, user: dict, aid: str, enabled: bool) -> None:
    db.one("""INSERT INTO merchant_accounts(store_id,owner_id,account_id,charges_enabled,updated_at) VALUES(:s,:o,:a,:e,:u)
              ON CONFLICT(store_id) DO UPDATE SET account_id=excluded.account_id, charges_enabled=excluded.charges_enabled, updated_at=excluded.updated_at
              RETURNING store_id""", s=store["id"], o=user["id"], a=aid, e=1 if enabled else 0, u=now_iso())


@app.post("/api/stripe/webhook", tags=["payments"])
async def stripe_webhook(request: Request):
    if MODE != "stripe" or not env("STRIPE_WEBHOOK_SECRET"):
        raise HTTPException(400, "Webhooks are not configured")
    payload = await request.body()
    try:
        event = stripe.Webhook.construct_event(payload, request.headers.get("stripe-signature", ""), env("STRIPE_WEBHOOK_SECRET"))
    except Exception as e:  # noqa: BLE001
        raise HTTPException(400, f"Webhook signature error: {e}")  # noqa: B904
    obj = event["data"]["object"]
    if event["type"] == "payment_intent.succeeded":
        method = "card"
        try:
            method = _wallet_method(stripe.PaymentIntent.retrieve(obj["id"], expand=["payment_method"]))
        except Exception:  # noqa: BLE001
            pass
        _mark_succeeded(db.one("SELECT * FROM payments WHERE provider_ref=:r", r=obj["id"]), method)
    elif event["type"] == "payment_intent.payment_failed":
        db.one("UPDATE payments SET status='failed', updated_at=:u WHERE provider_ref=:r AND status='requires_payment' RETURNING id", u=now_iso(), r=obj["id"])
    elif event["type"] == "account.updated":
        db.one("UPDATE merchant_accounts SET charges_enabled=:e, updated_at=:u WHERE account_id=:a RETURNING store_id",
               e=1 if (obj.get("charges_enabled") or obj.get("payouts_enabled")) else 0, u=now_iso(), a=obj["id"])
        acct = db.one("SELECT store_id FROM merchant_accounts WHERE account_id=:a", a=obj["id"])
        if acct:
            _retry_pending_transfers(acct["store_id"])
    return {"received": True}


def _mark_succeeded(p: dict | None, method: str) -> None:
    if not p or p["status"] in ("succeeded", "refunded", "partially_refunded"):
        return
    with db.tx() as t:
        t.run("UPDATE payments SET status='succeeded', method=:m, updated_at=:u WHERE id=:id", m=method, u=now_iso(), id=p["id"])
        outbox.enqueue(t, "orders", f"/internal/checkouts/{p['checkout_id']}/paid", {"method": method, "payment_ref": p["provider_ref"]})
    outbox.flush()


# ---------------------------------------------------------------- internal
INTERNAL = [Depends(internal_only)]


@app.post("/internal/payments", dependencies=INTERNAL, tags=["internal"])
def create_payment(body: dict):
    checkout_id, amount = to_int(body.get("checkout_id")), to_int(body.get("amount_cents"))
    if amount < 50:
        raise HTTPException(400, "Invalid amount")
    existing = db.one("SELECT * FROM payments WHERE checkout_id=:c", c=checkout_id)
    if existing:
        return {"client_secret": existing["client_secret"], "mode": MODE, "payment_id": existing["id"]}
    if MODE == "stripe":
        pi = stripe.PaymentIntent.create(amount=amount, currency="usd", automatic_payment_methods={"enabled": True},
                                         receipt_email=body.get("email") or None, statement_descriptor_suffix="BUCKDUCK",
                                         transfer_group=f"checkout_{checkout_id}",
                                         metadata={"checkout_id": str(checkout_id), "customer_id": str(body.get("customer_id")), "orders": s(body.get("orders"), 400)})
        ref, secret = pi.id, pi.client_secret
    else:
        ref = f"pi_demo_{secrets.token_hex(8)}"
        secret = f"{ref}_secret_demo"
    with db.tx() as t:
        pid = t.insert("payments", dict(checkout_id=checkout_id, customer_id=to_int(body.get("customer_id")), amount_cents=amount, currency="usd",
                                        status="requires_payment", provider=MODE, provider_ref=ref, client_secret=secret, created_at=now_iso()))
    return {"client_secret": secret, "mode": MODE, "payment_id": pid}


@app.post("/internal/payments/{checkout_id}/verify", dependencies=INTERNAL, tags=["internal"])
def verify_payment(checkout_id: int, body: dict):
    """Called when the shopper returns from paying. Confirms with Stripe before the order is released."""
    p = db.one("SELECT * FROM payments WHERE checkout_id=:c", c=checkout_id)
    if not p:
        raise HTTPException(404, "Payment not found")
    if p["status"] in ("succeeded", "refunded", "partially_refunded"):
        return {"status": "succeeded", "method": p["method"]}
    if MODE == "stripe":
        pi = stripe.PaymentIntent.retrieve(p["provider_ref"], expand=["payment_method"])
        if pi.status != "succeeded":
            return {"status": pi.status, "method": None}
        method = _wallet_method(pi)
    else:
        method = s(body.get("method"), 30) or "card"
    with db.tx() as t:
        t.run("UPDATE payments SET status='succeeded', method=:m, updated_at=:u WHERE id=:id", m=method, u=now_iso(), id=p["id"])
    return {"status": "succeeded", "method": method}


@app.post("/internal/refunds", dependencies=INTERNAL, tags=["internal"])
def refund(body: dict):
    p = db.one("SELECT * FROM payments WHERE checkout_id=:c", c=to_int(body.get("checkout_id")))
    if not p:
        return {"ok": True, "skipped": "no payment on record"}
    amount = to_int(body.get("amount_cents"))
    order_id = to_int(body.get("order_id"))
    # Idempotency: the same order + amount + reason is refunded once.
    if db.one("SELECT id FROM refunds WHERE payment_id=:p AND order_id=:o AND amount_cents=:a AND COALESCE(reason,'')=:r",
              p=p["id"], o=order_id, a=amount, r=s(body.get("reason"), 300)):
        return {"ok": True, "duplicate": True}
    already = to_int(db.scalar("SELECT COALESCE(SUM(amount_cents),0) FROM refunds WHERE payment_id=:p", p=p["id"]))
    if amount <= 0 or already + amount > p["amount_cents"]:
        raise HTTPException(400, "Refund exceeds the amount paid")
    ref = None
    if MODE == "stripe" and p["status"] != "requires_payment":
        ref = stripe.Refund.create(payment_intent=p["provider_ref"], amount=amount).id
    with db.tx() as t:
        t.insert("refunds", dict(payment_id=p["id"], order_id=order_id, amount_cents=amount, reason=s(body.get("reason"), 300),
                                 provider_ref=ref or f"re_demo_{secrets.token_hex(6)}", created_at=now_iso()))
        t.run("UPDATE payments SET status=:s, updated_at=:u WHERE id=:id",
              s="refunded" if already + amount >= p["amount_cents"] else "partially_refunded", u=now_iso(), id=p["id"])
    return {"ok": True}


@app.post("/internal/transfers", dependencies=INTERNAL, tags=["internal"])
def create_transfer(body: dict):
    """Order delivered → pay the store its share. Waits (status pending_account) until the store connects Stripe."""
    oid, sid, amount = to_int(body.get("order_id")), to_int(body.get("store_id")), to_int(body.get("amount_cents"))
    if db.one("SELECT id FROM transfers WHERE order_id=:o", o=oid):
        return {"ok": True, "duplicate": True}
    with db.tx() as t:
        t.insert("transfers", dict(order_id=oid, store_id=sid, amount_cents=amount, status="pending_account",
                                   provider_ref=s(body.get("checkout_id"), 30), created_at=now_iso()))
    _retry_pending_transfers(sid)
    return {"ok": True}


def _retry_pending_transfers(store_id: int) -> None:
    acct = db.one("SELECT * FROM merchant_accounts WHERE store_id=:s AND charges_enabled=1", s=store_id)
    if not acct:
        return
    for tr in db.all("SELECT * FROM transfers WHERE store_id=:s AND status IN ('pending_account','failed')", s=store_id):
        try:
            if MODE == "stripe":
                ref = stripe.Transfer.create(amount=tr["amount_cents"], currency="usd", destination=acct["account_id"],
                                             transfer_group=f"checkout_{tr['provider_ref']}", metadata={"order_id": str(tr["order_id"])}).id
            else:
                ref = f"tr_demo_{secrets.token_hex(6)}"
            db.one("UPDATE transfers SET status='paid', provider_ref=:r, updated_at=:u WHERE id=:id RETURNING id", r=ref, u=now_iso(), id=tr["id"])
        except Exception as e:  # noqa: BLE001
            db.one("UPDATE transfers SET status='failed', updated_at=:u WHERE id=:id RETURNING id", u=now_iso(), id=tr["id"])
            log.warning("transfer %s failed: %s", tr["id"], e)


@app.get("/internal/accounts/{store_id}", dependencies=INTERNAL, tags=["internal"])
def account(store_id: int):
    a = db.one("SELECT * FROM merchant_accounts WHERE store_id=:s", s=store_id)
    paid = [r["order_id"] for r in db.all("SELECT order_id FROM transfers WHERE store_id=:s AND status='paid'", s=store_id)]
    return {"account": a, "paid_order_ids": paid, "mode": MODE}
