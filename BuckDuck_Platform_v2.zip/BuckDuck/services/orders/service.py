"""Orders service — pricing, checkout, the order lifecycle, merchant order queue, admin operations and finance.

Owns: checkouts, orders, order_items, order_events, order settings (fees). Database: its own (ORDERS_DATABASE_URL).
Orders keep a snapshot of the store, customer and window at the time of purchase, so order history
and receipts never depend on another service being online.
"""
from __future__ import annotations

import math
from datetime import timedelta

from fastapi import Depends, HTTPException
from sqlalchemy import Column, Float, Integer, MetaData, String, Table, Text

from buckduck_common import seed
from buckduck_common.app import create_app
from buckduck_common.auth import internal_only, require
from buckduck_common.config import database_url, env
from buckduck_common.db import Database
from buckduck_common.http import call, try_call
from buckduck_common.outbox import Outbox, outbox_table
from buckduck_common.util import STATUS_LABEL, next_weekday, now_iso, req, s, to_int, today, ymd

md = MetaData()
Table("order_settings", md, Column("key", String(60), primary_key=True), Column("value", String(400), nullable=False))
Table("checkouts", md,
      Column("id", Integer, primary_key=True, autoincrement=True), Column("customer_id", Integer, nullable=False, index=True),
      Column("total_cents", Integer, nullable=False), Column("payment_status", String(20), nullable=False),
      Column("payment_method", String(30)), Column("created_at", String(40), nullable=False))
_order_cols = [
    Column("id", Integer, primary_key=True, autoincrement=True), Column("number", String(20), unique=True),
    Column("checkout_id", Integer, index=True), Column("customer_id", Integer, nullable=False, index=True),
    Column("customer_name", String(80)), Column("customer_email", String(120)),
    Column("store_id", Integer, nullable=False, index=True), Column("store_owner_id", Integer, index=True),
    Column("store_name", String(80)), Column("store_slug", String(80)), Column("store_emoji", String(8)), Column("store_color", String(7)),
    Column("store_address", String(160)), Column("store_city", String(60)), Column("store_zip", String(10)), Column("store_phone", String(30)),
    Column("window_id", Integer, index=True), Column("window_date", String(10), index=True), Column("window_start", String(5)),
    Column("window_end", String(5)), Column("window_label", String(60)),
    Column("driver_id", Integer, index=True), Column("driver_name", String(80)), Column("driver_phone", String(30)), Column("driver_vehicle", String(80)),
    Column("status", String(20), nullable=False, index=True),
    Column("subtotal_cents", Integer, default=0), Column("delivery_fee_cents", Integer, default=0), Column("service_fee_cents", Integer, default=0),
    Column("tax_cents", Integer, default=0), Column("tip_cents", Integer, default=0), Column("total_cents", Integer, default=0),
    Column("commission_cents", Integer, default=0), Column("driver_pay_cents", Integer, default=0), Column("bags", Integer, default=1),
    Column("address_line1", String(160)), Column("address_line2", String(60)), Column("city", String(60)), Column("state", String(2)),
    Column("zip", String(10)), Column("phone", String(30)), Column("notes", Text), Column("proof_note", Text),
    Column("transfer_requested", Integer, default=0), Column("created_at", String(40), nullable=False), Column("updated_at", String(40), nullable=False)]
Table("orders", md, *_order_cols)
Table("order_items", md,
      Column("id", Integer, primary_key=True, autoincrement=True), Column("order_id", Integer, nullable=False, index=True),
      Column("product_id", Integer), Column("name", String(100)), Column("emoji", String(8)), Column("unit", String(40)),
      Column("price_cents", Integer, nullable=False), Column("qty", Integer, nullable=False))
Table("order_events", md,
      Column("id", Integer, primary_key=True, autoincrement=True), Column("order_id", Integer, nullable=False, index=True),
      Column("status", String(20), nullable=False), Column("note", Text), Column("actor", String(20)), Column("at", String(40), nullable=False))
outbox_table(md)

db = Database(database_url("orders"), md)
outbox = Outbox(db)
app = create_app("orders", "Pricing, checkout, order lifecycle, merchant queue, admin operations and finance.", db=db, outbox=outbox)

DEFAULTS = {"delivery_fee_cents": "599", "service_fee_rate": "0.05", "service_fee_min_cents": "199", "tax_rate": "0",
            "driver_base_pay_cents": "550", "min_order_cents": "1500", "bag_item_capacity": "10", "service_zips": ""}
ORDER_COLS = [c.name for c in _order_cols]
LIVE = "('placed','accepted','packing','ready','picked_up','delivered')"
ITEM_COUNT = "(SELECT COALESCE(SUM(i.qty),0) FROM order_items i WHERE i.order_id=o.id) AS item_count"
SELECT_ORDER = f"SELECT o.*, c.payment_method, c.payment_status, {ITEM_COUNT} FROM orders o LEFT JOIN checkouts c ON c.id=o.checkout_id"
MERCHANT_NEXT = {"placed": ["accepted", "cancelled"], "accepted": ["packing", "cancelled"], "packing": ["ready"], "ready": []}


def setting(k: str) -> str:
    r = db.one("SELECT value FROM order_settings WHERE key=:k", k=k)
    return r["value"] if r else DEFAULTS[k]


def nset(k: str) -> float:
    return float(setting(k) or 0)


@app.on_event("startup")
def startup():
    db.create_all()
    if env("SEED_DEMO_DATA", "true") == "true" and not db.scalar("SELECT COUNT(*) FROM orders"):
        d = seed.dataset()
        with db.tx() as t:
            t.insert_many("checkouts", [dict(id=o["checkout_id"], customer_id=o["customer_id"], total_cents=o["total_cents"],
                                             payment_status=o["payment_status"], payment_method=o["payment_method"], created_at=o["created_at"]) for o in d["orders"]])
            t.insert_many("orders", [dict({k: o.get(k) for k in ORDER_COLS}, transfer_requested=1 if o["status"] == "delivered" else 0) for o in d["orders"]])
            t.insert_many("order_items", [dict(it, order_id=o["id"]) for o in d["orders"] for it in o["items"]])
            t.insert_many("order_events", [dict(ev, order_id=o["id"]) for o in d["orders"] for ev in o["events"]])
        db.fix_sequences(["checkouts", "orders", "order_items", "order_events"])
    outbox.start()


# ---------------------------------------------------------------- helpers
def with_label(o: dict) -> dict:
    o["status_label"] = STATUS_LABEL.get(o["status"], o["status"])
    return o


def order_detail(oid: int) -> dict:
    o = db.one(SELECT_ORDER + " WHERE o.id=:id", id=oid)
    if not o:
        raise HTTPException(404, "Order not found")
    o["items"] = db.all("SELECT * FROM order_items WHERE order_id=:id ORDER BY id", id=oid)
    o["events"] = db.all("SELECT * FROM order_events WHERE order_id=:id ORDER BY id", id=oid)
    return with_label(o)


def can_view(user: dict, o: dict) -> bool:
    return (user["role"] == "admin" or (user["role"] == "customer" and o["customer_id"] == user["id"])
            or (user["role"] == "merchant" and o["store_owner_id"] == user["id"]) or (user["role"] == "driver" and o["driver_id"] == user["id"]))


def set_status(t, o: dict, status: str, actor: str, note: str = "", bags: int | None = None) -> None:
    t.run("UPDATE orders SET status=:s, updated_at=:u" + (", bags=:b" if bags else "") + " WHERE id=:id",
          s=status, u=now_iso(), id=o["id"], **({"b": bags} if bags else {}))
    t.insert("order_events", dict(order_id=o["id"], status=status, note=note, actor=actor, at=now_iso()))
    outbox.enqueue(t, "delivery", f"/internal/jobs/{o['id']}/sync", {"order_status": status, "bags": bags or o["bags"]})
    if status in ("cancelled",):
        items = t.all("SELECT product_id, qty FROM order_items WHERE order_id=:id", id=o["id"])
        outbox.enqueue(t, "catalog", "/internal/stock/restore", {"order_id": o["id"], "items": items})
    if status == "delivered" and not o.get("transfer_requested"):
        t.run("UPDATE orders SET transfer_requested=1 WHERE id=:id", id=o["id"])
        outbox.enqueue(t, "payments", "/internal/transfers", {"order_id": o["id"], "store_id": o["store_id"], "checkout_id": o["checkout_id"],
                                                              "amount_cents": o["subtotal_cents"] - o["commission_cents"]})


def refund(o: dict, amount: int, reason: str) -> None:
    """Synchronous: an order is never marked refunded unless the payment service confirmed it."""
    call("payments", "POST", "/internal/refunds", json={"checkout_id": o["checkout_id"], "order_id": o["id"], "amount_cents": amount, "reason": reason})


# ---------------------------------------------------------------- pricing & checkout
def price(items) -> list[dict]:
    if not isinstance(items, list) or not items:
        raise HTTPException(400, "Your cart is empty")
    want = {}
    for it in items:
        q = to_int(it.get("qty"))
        if q < 1 or q > 99:
            raise HTTPException(400, "Invalid quantity")
        want[to_int(it.get("product_id"))] = want.get(to_int(it.get("product_id")), 0) + q
    prods = {p["id"]: p for p in call("catalog", "POST", "/internal/products/lookup", json={"ids": list(want)})["products"]}
    groups: dict[int, dict] = {}
    for pid, q in want.items():
        p = prods.get(pid)
        if not p or not p["active"]:
            raise HTTPException(400, "An item in your cart is no longer available")
        if p["store_status"] != "active":
            raise HTTPException(400, f"{p['store_name']} is not accepting orders right now")
        if p["stock"] < q:
            raise HTTPException(400, f"Only {p['stock']} left of {p['name']}")
        g = groups.setdefault(p["store_id"], {"store": p, "lines": []})
        g["lines"].append({"product": p, "qty": q})
    fee, rate, mn, tax, cap = nset("delivery_fee_cents"), nset("service_fee_rate"), nset("service_fee_min_cents"), nset("tax_rate"), nset("bag_item_capacity") or 10
    out = []
    for sid, g in groups.items():
        sub = sum(line["product"]["price_cents"] * line["qty"] for line in g["lines"])
        service = int(max(mn, round(sub * rate)))
        tx = int(round(sub * tax))
        qty = sum(line["qty"] for line in g["lines"])
        out.append(dict(store_id=sid, store=g["store"], lines=g["lines"], subtotal_cents=sub, delivery_fee_cents=int(fee), service_fee_cents=service,
                        tax_cents=tx, bags=max(1, math.ceil(qty / cap)), total_cents=sub + int(fee) + service + tx))
    return out


def quote(items, tip) -> dict:
    groups = price(items)
    tip_c = max(0, min(to_int(tip), 50000))
    total = lambda k: sum(g[k] for g in groups)  # noqa: E731
    return {"stores": [dict(store_id=g["store_id"], store_name=g["store"]["store_name"], **{k: g[k] for k in ("subtotal_cents", "delivery_fee_cents", "service_fee_cents", "tax_cents", "bags")})
                       for g in groups],
            "subtotal_cents": total("subtotal_cents"), "delivery_fee_cents": total("delivery_fee_cents"), "service_fee_cents": total("service_fee_cents"),
            "tax_cents": total("tax_cents"), "tip_cents": tip_c, "total_cents": total("total_cents") + tip_c, "min_order_cents": int(nset("min_order_cents")),
            "_groups": groups}


@app.post("/api/checkout/quote", tags=["checkout"])
def api_quote(body: dict):
    q = quote(body.get("items"), body.get("tip_cents"))
    q.pop("_groups")
    return q


@app.post("/api/checkout", tags=["checkout"])
def checkout(body: dict, user=Depends(require("customer"))):
    q = quote(body.get("items"), body.get("tip_cents"))
    if q["subtotal_cents"] < q["min_order_cents"]:
        raise HTTPException(400, f"Minimum order is ${q['min_order_cents'] / 100:.2f}")
    w = call("delivery", "GET", f"/internal/windows/{to_int(body.get('window_id'))}")["window"]
    if not w["open"]:
        raise HTTPException(400, "That delivery window is closed or full — please pick another")
    a = body.get("address") or {}
    addr = dict(address_line1=req(a.get("line1"), "Street address", 120), address_line2=s(a.get("line2"), 60), city=req(a.get("city"), "City", 60),
                state=req(a.get("state"), "State", 2).upper(), zip=req(a.get("zip"), "ZIP code", 10))
    import re
    if not re.match(r"^\d{5}(-\d{4})?$", addr["zip"]):
        raise HTTPException(400, "Enter a valid ZIP code")
    zips = [z.strip() for z in setting("service_zips").split(",") if z.strip()]
    if zips and addr["zip"][:5] not in zips:
        raise HTTPException(400, f"Sorry, we don't deliver to {addr['zip']} yet")
    phone = req(body.get("phone"), "Phone", 30)
    base = int(nset("driver_base_pay_cents"))
    groups = q["_groups"]
    tip_each, tip_rem = divmod(q["tip_cents"], len(groups))
    n = now_iso()
    order_ids = []
    with db.tx() as t:
        cid = t.insert("checkouts", dict(customer_id=user["id"], total_cents=q["total_cents"], payment_status="pending", created_at=n))
        for i, g in enumerate(groups):
            st = g["store"]
            tip = tip_each + (tip_rem if i == 0 else 0)
            oid = t.insert("orders", dict(checkout_id=cid, customer_id=user["id"], customer_name=user["name"], customer_email=user["email"],
                                          store_id=g["store_id"], store_owner_id=st["store_owner_id"], store_name=st["store_name"], store_slug=st["store_slug"],
                                          store_emoji=st["store_emoji"], store_color=st["store_color"], store_address=st["store_address"], store_city=st["store_city"],
                                          store_zip=st["store_zip"], store_phone=st["store_phone"], window_id=w["id"], window_date=w["date"],
                                          window_start=w["start_time"], window_end=w["end_time"], window_label=w["label"], status="pending_payment",
                                          subtotal_cents=g["subtotal_cents"], delivery_fee_cents=g["delivery_fee_cents"], service_fee_cents=g["service_fee_cents"],
                                          tax_cents=g["tax_cents"], tip_cents=tip, total_cents=g["total_cents"] + tip,
                                          commission_cents=round(g["subtotal_cents"] * float(st["commission_rate"])), driver_pay_cents=base + tip, bags=g["bags"],
                                          phone=phone, notes=s(body.get("notes"), 300), transfer_requested=0, created_at=n, updated_at=n, **addr))
            t.run("UPDATE orders SET number=:num WHERE id=:id", num=f"BD-{10000 + oid}", id=oid)
            t.insert_many("order_items", [dict(order_id=oid, product_id=line["product"]["id"], name=line["product"]["name"], emoji=line["product"]["emoji"],
                                               unit=line["product"]["unit"], price_cents=line["product"]["price_cents"], qty=line["qty"]) for line in g["lines"]])
            t.insert("order_events", dict(order_id=oid, status="pending_payment", note="Checkout started", actor="customer", at=n))
            order_ids.append(oid)
    try:
        pay = call("payments", "POST", "/internal/payments", json={"checkout_id": cid, "customer_id": user["id"], "amount_cents": q["total_cents"],
                                                                   "email": user["email"], "orders": ",".join(f"BD-{10000 + i}" for i in order_ids)})
    except HTTPException:
        with db.tx() as t:
            t.run("UPDATE checkouts SET payment_status='failed' WHERE id=:id", id=cid)
            t.run(f"UPDATE orders SET status='cancelled', updated_at=:u WHERE checkout_id=:c", u=now_iso(), c=cid)
        raise
    return {"checkout_id": cid, "client_secret": pay["client_secret"], "amount_cents": q["total_cents"], "order_ids": order_ids, "mode": pay["mode"]}


def mark_paid(checkout_id: int, method: str) -> None:
    with db.tx() as t:
        co = t.one("SELECT * FROM checkouts WHERE id=:id", id=checkout_id)
        if not co or co["payment_status"] == "paid":
            return
        t.run("UPDATE checkouts SET payment_status='paid', payment_method=:m WHERE id=:id", m=method or "card", id=checkout_id)
        for o in t.all("SELECT * FROM orders WHERE checkout_id=:c AND status='pending_payment'", c=checkout_id):
            t.run("UPDATE orders SET status='placed', updated_at=:u WHERE id=:id", u=now_iso(), id=o["id"])
            t.insert("order_events", dict(order_id=o["id"], status="placed", note="Payment received", actor="customer", at=now_iso()))
            items = t.all("SELECT product_id, qty FROM order_items WHERE order_id=:id", id=o["id"])
            outbox.enqueue(t, "catalog", "/internal/stock/decrement", {"order_id": o["id"], "items": items})
            outbox.enqueue(t, "delivery", "/internal/jobs", dict({k: o[k] for k in (
                "number", "window_id", "window_date", "window_start", "window_end", "store_id", "store_name", "store_address", "store_city", "store_zip",
                "customer_id", "customer_name", "address_line1", "address_line2", "city", "state", "zip", "phone", "notes", "bags", "driver_pay_cents", "tip_cents")},
                order_id=o["id"], item_count=sum(i["qty"] for i in items)))
    outbox.flush()


@app.post("/api/checkout/{cid}/confirm", tags=["checkout"])
def confirm(cid: int, body: dict, user=Depends(require("customer"))):
    co = db.one("SELECT * FROM checkouts WHERE id=:id AND customer_id=:u", id=cid, u=user["id"])
    if not co:
        raise HTTPException(404, "Checkout not found")
    if co["payment_status"] != "paid":
        r = call("payments", "POST", f"/internal/payments/{cid}/verify", json={"method": s(body.get("payment_method"), 30)})
        if r["status"] != "succeeded":
            raise HTTPException(402, "Payment is processing — we will confirm shortly" if r["status"] == "processing" else "Payment was not completed")
        mark_paid(cid, r.get("method") or "card")
    return {"ok": True, "orders": [with_label(o) for o in db.all(SELECT_ORDER + " WHERE o.checkout_id=:c ORDER BY o.id", c=cid)]}


# ---------------------------------------------------------------- customer
@app.get("/api/orders", tags=["customer"])
def my_orders(user=Depends(require("customer"))):
    return {"orders": [with_label(o) for o in db.all(SELECT_ORDER + " WHERE o.customer_id=:u AND o.status<>'pending_payment' ORDER BY o.id DESC LIMIT 100", u=user["id"])]}


@app.get("/api/orders/{oid}", tags=["customer"])
def get_order(oid: int, user=Depends(require())):
    o = order_detail(oid)
    if not can_view(user, o):
        raise HTTPException(404, "Order not found")
    return {"order": o}


@app.post("/api/orders/{oid}/cancel", tags=["customer"])
def cancel_order(oid: int, user=Depends(require("customer"))):
    o = db.one("SELECT * FROM orders WHERE id=:id AND customer_id=:u", id=oid, u=user["id"])
    if not o:
        raise HTTPException(404, "Order not found")
    if o["status"] != "placed":
        raise HTTPException(400, "This order can no longer be cancelled — the store has started preparing it")
    refund(o, o["total_cents"], "Cancelled by customer")
    with db.tx() as t:
        set_status(t, o, "cancelled", "customer", "Cancelled by customer — full refund issued")
    outbox.flush()
    return {"order": order_detail(oid)}


# ---------------------------------------------------------------- merchant
def merchant_store(user: dict) -> dict:
    st = try_call("catalog", "GET", f"/internal/stores/by-owner/{user['id']}", fallback=None)
    if st and st.get("store"):
        return st["store"]
    any_order = db.one("SELECT store_id, store_name, store_slug, store_emoji FROM orders WHERE store_owner_id=:o LIMIT 1", o=user["id"])
    if not any_order:
        raise HTTPException(503, "Store details are temporarily unavailable. Please try again in a moment.")
    return dict(id=any_order["store_id"], name=any_order["store_name"], slug=any_order["store_slug"], emoji=any_order["store_emoji"],
                status="active", commission_rate=0.15)


def next_delivery_date() -> str:
    ws = (try_call("delivery", "GET", "/internal/windows", fallback={}) or {}).get("windows") or []
    return ws[0]["date"] if ws else ymd(next_weekday(today(), 6))


@app.get("/api/merchant/summary", tags=["merchant"])
def merchant_summary(user=Depends(require("merchant"))):
    st = merchant_store(user)
    nd, td = next_delivery_date(), ymd(today())
    counts = {r["status"]: r["c"] for r in db.all("""SELECT status, COUNT(*) AS c FROM orders WHERE store_owner_id=:o AND window_date>=:d
                                                     AND status<>'pending_payment' GROUP BY status""", o=user["id"], d=td)}
    weekly = list(reversed(db.all(f"""SELECT window_date AS date, COUNT(*) AS orders, SUM(subtotal_cents) AS sales, SUM(subtotal_cents-commission_cents) AS payout
        FROM orders WHERE store_owner_id=:o AND status IN {LIVE} GROUP BY window_date ORDER BY window_date DESC LIMIT 10""", o=user["id"])))
    totals = db.one("""SELECT COUNT(*) AS orders, COALESCE(SUM(subtotal_cents),0) AS sales, COALESCE(SUM(subtotal_cents-commission_cents),0) AS payout
                       FROM orders WHERE store_owner_id=:o AND status='delivered'""", o=user["id"])
    top = db.all("""SELECT i.product_id, i.name, i.emoji, SUM(i.qty) AS qty, SUM(i.qty*i.price_cents) AS revenue FROM order_items i JOIN orders o ON o.id=i.order_id
                    WHERE o.store_owner_id=:o AND o.status NOT IN ('pending_payment','cancelled','refunded')
                    GROUP BY i.product_id, i.name, i.emoji ORDER BY qty DESC LIMIT 5""", o=user["id"])
    low = (try_call("catalog", "GET", f"/internal/stores/{st['id']}/low-stock", fallback={}) or {}).get("products", [])
    bags = db.scalar("""SELECT COALESCE(SUM(bags),0) FROM orders WHERE store_owner_id=:o AND window_date=:d
                        AND status IN ('placed','accepted','packing','ready')""", o=user["id"], d=nd)
    return {"store": st, "next_delivery_date": nd, "counts": counts, "weekly": weekly, "totals": totals, "top_products": top, "low_stock": low, "bags_needed": bags}


@app.get("/api/merchant/orders", tags=["merchant"])
def merchant_orders(status: str = "", scope: str = "upcoming", user=Depends(require("merchant"))):
    where, p = ["o.store_owner_id=:o", "o.status<>'pending_payment'"], {"o": user["id"]}
    if status:
        where.append("o.status=:s")
        p["s"] = status
    if scope == "upcoming":
        where.append("o.window_date>=:d")
        p["d"] = ymd(today())
    order = "ASC" if scope == "upcoming" else "DESC"
    rows = db.all(SELECT_ORDER + f" WHERE {' AND '.join(where)} ORDER BY o.window_date {order}, o.window_start, o.id LIMIT 300", **p)
    return {"orders": [with_label(o) for o in rows]}


@app.post("/api/merchant/orders/{oid}/status", tags=["merchant"])
def merchant_status(oid: int, body: dict, user=Depends(require("merchant"))):
    o = db.one("SELECT * FROM orders WHERE id=:id AND store_owner_id=:o", id=oid, o=user["id"])
    if not o:
        raise HTTPException(404, "Order not found")
    nxt = s(body.get("status"), 20)
    if nxt not in MERCHANT_NEXT.get(o["status"], []):
        raise HTTPException(400, f'Cannot move an order from "{STATUS_LABEL.get(o["status"])}" to "{STATUS_LABEL.get(nxt, nxt)}"')
    if nxt == "cancelled":
        refund(o, o["total_cents"], "Cancelled by store")
    bags = max(1, min(30, to_int(body.get("bags")))) if (nxt == "ready" and body.get("bags")) else None
    with db.tx() as t:
        set_status(t, o, nxt, "merchant", s(body.get("note"), 200) or ("Cancelled by store — customer refunded" if nxt == "cancelled" else ""), bags=bags)
    outbox.flush()
    return {"order": order_detail(oid)}


@app.get("/api/merchant/payouts", tags=["merchant"])
def merchant_payouts(user=Depends(require("merchant"))):
    st = merchant_store(user)
    acct = try_call("payments", "GET", f"/internal/accounts/{st['id']}", fallback=None) or {}
    paid = set(acct.get("paid_order_ids") or [])
    weeks = db.all("""SELECT window_date AS date, COUNT(*) AS orders, SUM(subtotal_cents) AS gross, SUM(commission_cents) AS commission,
                      SUM(subtotal_cents-commission_cents) AS net FROM orders WHERE store_owner_id=:o AND status='delivered'
                      GROUP BY window_date ORDER BY window_date DESC LIMIT 26""", o=user["id"])
    delivered = db.all("SELECT id, window_date FROM orders WHERE store_owner_id=:o AND status='delivered'", o=user["id"])
    by_week: dict[str, int] = {}
    for d in delivered:
        by_week[d["window_date"]] = by_week.get(d["window_date"], 0) + (1 if d["id"] in paid else 0)
    for w in weeks:
        w["transferred"] = by_week.get(w["date"], 0)
    pending = db.scalar("""SELECT COALESCE(SUM(subtotal_cents-commission_cents),0) FROM orders WHERE store_owner_id=:o
                           AND status IN ('placed','accepted','packing','ready','picked_up')""", o=user["id"])
    a = acct.get("account") or {}
    return {"store": {"id": st["id"], "commission_rate": st.get("commission_rate", 0.15), "stripe_account_id": a.get("account_id"),
                      "stripe_charges_enabled": bool(a.get("charges_enabled"))},
            "weeks": weeks, "pending_cents": pending, "payments_mode": acct.get("mode", "demo")}


# ---------------------------------------------------------------- admin
@app.get("/api/admin/overview", tags=["admin"])
def admin_overview(_=Depends(require("admin"))):
    totals = db.one(f"""SELECT COUNT(*) AS orders, COALESCE(SUM(total_cents),0) AS gmv,
        COALESCE(SUM(commission_cents+service_fee_cents+delivery_fee_cents-(driver_pay_cents-tip_cents)),0) AS net_revenue,
        COALESCE(AVG(total_cents),0) AS aov FROM orders WHERE status IN {LIVE}""")
    weekly = list(reversed(db.all(f"""SELECT window_date AS date, COUNT(*) AS orders, SUM(total_cents) AS gmv,
        SUM(commission_cents+service_fee_cents+delivery_fee_cents-(driver_pay_cents-tip_cents)) AS revenue
        FROM orders WHERE status IN {LIVE} GROUP BY window_date ORDER BY window_date DESC LIMIT 10""")))
    statuses = {r["status"]: r["c"] for r in db.all("SELECT status, COUNT(*) AS c FROM orders WHERE window_date>=:d AND status<>'pending_payment' GROUP BY status",
                                                     d=ymd(today()))}
    top = db.all(f"""SELECT store_id, store_name AS name, store_emoji AS emoji, store_color AS color, COUNT(*) AS orders, SUM(subtotal_cents) AS sales
                     FROM orders WHERE status IN {LIVE} GROUP BY store_id, store_name, store_emoji, store_color ORDER BY sales DESC LIMIT 6""")
    mix = db.all("SELECT payment_method AS method, COUNT(*) AS c FROM checkouts WHERE payment_status='paid' GROUP BY payment_method")
    ids = try_call("identity", "GET", "/internal/stats", fallback={}) or {}
    cat = try_call("catalog", "GET", "/internal/stats", fallback={}) or {}
    dlv = try_call("delivery", "GET", "/internal/stats", fallback={}) or {}
    counts = {"customers": ids.get("customer", 0), "stores": cat.get("active", 0), "pending_stores": cat.get("pending", 0),
              "drivers": dlv.get("drivers", 0), "drivers_online": dlv.get("drivers_online", 0),
              "unassigned_ready": dlv.get("unassigned_ready", db.scalar("SELECT COUNT(*) FROM orders WHERE status='ready' AND driver_id IS NULL"))}
    degraded = [n for n, v in (("identity", ids), ("catalog", cat), ("delivery", dlv)) if not v]
    return {"totals": totals, "weekly": weekly, "statuses": statuses, "top_stores": top, "counts": counts, "windows": dlv.get("windows", []),
            "payment_mix": mix, "degraded_services": degraded}


@app.get("/api/admin/orders", tags=["admin"])
def admin_orders(status: str = "", q: str = "", window_id: int = 0, _=Depends(require("admin"))):
    where, p = ["o.status<>'pending_payment'"], {}
    if status:
        where.append("o.status=:s")
        p["s"] = status
    if window_id:
        where.append("o.window_id=:w")
        p["w"] = window_id
    if q:
        where.append("(LOWER(o.number) LIKE :q OR LOWER(o.customer_name) LIKE :q OR LOWER(o.store_name) LIKE :q)")
        p["q"] = f"%{q.lower()[:60]}%"
    rows = db.all(SELECT_ORDER + f" WHERE {' AND '.join(where)} ORDER BY o.window_date DESC, o.id DESC LIMIT 300", **p)
    return {"orders": [with_label(o) for o in rows]}


@app.post("/api/admin/orders/{oid}", tags=["admin"])
def admin_update_order(oid: int, body: dict, _=Depends(require("admin"))):
    o = db.one("SELECT * FROM orders WHERE id=:id", id=oid)
    if not o:
        raise HTTPException(404, "Order not found")
    if "driver_id" in body and (to_int(body.get("driver_id")) or None) != o["driver_id"]:
        if o["status"] in ("delivered", "cancelled", "refunded"):
            raise HTTPException(400, "Order is closed")
        d = call("delivery", "POST", f"/internal/jobs/{oid}/assign", json={"driver_id": to_int(body.get("driver_id")) or None})["driver"]
        with db.tx() as t:
            t.run("UPDATE orders SET driver_id=:d, driver_name=:n, driver_phone=:p, driver_vehicle=:v, updated_at=:u WHERE id=:id",
                  d=d["id"] if d else None, n=d["name"] if d else None, p=d["phone"] if d else None, v=d["vehicle"] if d else None, u=now_iso(), id=oid)
            t.insert("order_events", dict(order_id=oid, status=o["status"], note=f"Assigned to {d['name']} by admin" if d else "Driver unassigned by admin",
                                          actor="admin", at=now_iso()))
        o = db.one("SELECT * FROM orders WHERE id=:id", id=oid)
    nxt = body.get("status")
    if nxt and nxt != o["status"]:
        if nxt not in ("placed", "accepted", "packing", "ready", "picked_up", "delivered", "cancelled"):
            raise HTTPException(400, "Invalid status")
        if nxt == "cancelled" and o["status"] not in ("pending_payment",):
            refund(o, o["total_cents"], "Cancelled by operations")
        with db.tx() as t:
            set_status(t, o, nxt, "admin", s(body.get("note"), 200) or "Updated by operations")
    outbox.flush()
    return {"order": order_detail(oid)}


@app.post("/api/admin/orders/{oid}/refund", tags=["admin"])
def admin_refund(oid: int, body: dict, _=Depends(require("admin"))):
    o = db.one("SELECT * FROM orders WHERE id=:id", id=oid)
    if not o:
        raise HTTPException(404, "Order not found")
    if o["status"] in ("refunded", "cancelled", "pending_payment"):
        raise HTTPException(400, "Order is not refundable")
    amount = min(to_int(body.get("amount_cents")) or o["total_cents"], o["total_cents"])
    reason = s(body.get("reason"), 200)
    refund(o, amount, reason or "Refund")
    with db.tx() as t:
        if amount >= o["total_cents"]:
            set_status(t, o, "refunded", "admin", reason or "Full refund")
        else:
            t.insert("order_events", dict(order_id=oid, status=o["status"], note=f"Partial refund ${amount / 100:.2f} — {reason}", actor="admin", at=now_iso()))
    outbox.flush()
    return {"order": order_detail(oid)}


@app.get("/api/admin/finance", tags=["admin"])
def admin_finance(_=Depends(require("admin"))):
    rows = db.all("""SELECT window_date AS date, COUNT(*) AS orders, SUM(total_cents) AS gmv, SUM(subtotal_cents) AS merchandise, SUM(commission_cents) AS commission,
        SUM(service_fee_cents) AS service_fees, SUM(delivery_fee_cents) AS delivery_fees, SUM(tip_cents) AS tips, SUM(driver_pay_cents) AS driver_pay,
        SUM(subtotal_cents-commission_cents) AS merchant_payouts FROM orders WHERE status='delivered' GROUP BY window_date ORDER BY window_date DESC LIMIT 26""")
    for r in rows:
        r["net_revenue"] = r["commission"] + r["service_fees"] + r["delivery_fees"] - (r["driver_pay"] - r["tips"])
    refunds = db.one("SELECT COUNT(*) AS c, COALESCE(SUM(total_cents),0) AS amt FROM orders WHERE status='refunded'")
    return {"weeks": rows, "refunds": refunds}


@app.get("/api/admin/settings", tags=["admin"])
def get_settings(_=Depends(require("admin"))):
    return {"settings": {k: setting(k) for k in DEFAULTS}}


@app.put("/api/admin/settings", tags=["admin"])
def put_settings(body: dict, _=Depends(require("admin"))):
    for k, v in (body or {}).items():
        if k not in DEFAULTS:
            continue
        v = str(v).strip()
        if k != "service_zips":
            try:
                if float(v) < 0:
                    raise ValueError
            except ValueError:
                raise HTTPException(400, f"Invalid value for {k}")  # noqa: B904
        db.one("INSERT INTO order_settings(key,value) VALUES(:k,:v) ON CONFLICT(key) DO UPDATE SET value=excluded.value RETURNING key", k=k, v=v)
    return get_settings()


# ---------------------------------------------------------------- internal (events and stats)
INTERNAL = [Depends(internal_only)]


@app.get("/internal/config", dependencies=INTERNAL, tags=["internal"])
def internal_config():
    return {"delivery_fee_cents": int(nset("delivery_fee_cents")), "service_fee_rate": nset("service_fee_rate"),
            "min_order_cents": int(nset("min_order_cents")), "driver_base_pay_cents": int(nset("driver_base_pay_cents"))}


@app.post("/internal/checkouts/{cid}/paid", dependencies=INTERNAL, tags=["internal"])
def internal_paid(cid: int, body: dict):
    """Event from the payments service (Stripe webhook). Idempotent."""
    mark_paid(cid, s(body.get("method"), 30) or "card")
    return {"ok": True}


@app.post("/internal/orders/{oid}/delivery-event", dependencies=INTERNAL, tags=["internal"])
def internal_delivery_event(oid: int, body: dict):
    """Event from the delivery service: assigned | released | picked_up | delivered. Idempotent."""
    o = db.one("SELECT * FROM orders WHERE id=:id", id=oid)
    if not o:
        return {"ok": False, "missing": True}
    ev = body.get("event")
    with db.tx() as t:
        if ev == "assigned":
            t.run("UPDATE orders SET driver_id=:d, driver_name=:n, driver_phone=:p, driver_vehicle=:v, updated_at=:u WHERE id=:id",
                  d=to_int(body.get("driver_id")), n=s(body.get("driver_name"), 80), p=s(body.get("driver_phone"), 30), v=s(body.get("driver_vehicle"), 80),
                  u=now_iso(), id=oid)
            t.insert("order_events", dict(order_id=oid, status=o["status"], note=f"Driver {s(body.get('driver_name'), 80)} assigned", actor="driver", at=now_iso()))
        elif ev == "released":
            t.run("UPDATE orders SET driver_id=NULL, driver_name=NULL, driver_phone=NULL, driver_vehicle=NULL, updated_at=:u WHERE id=:id", u=now_iso(), id=oid)
            t.insert("order_events", dict(order_id=oid, status=o["status"], note="Driver released the delivery", actor=body.get("actor") or "driver", at=now_iso()))
        elif ev == "picked_up" and o["status"] == "ready":
            t.run("UPDATE orders SET status='picked_up', updated_at=:u WHERE id=:id", u=now_iso(), id=oid)
            t.insert("order_events", dict(order_id=oid, status="picked_up", note=f"Picked up by {s(body.get('driver_name'), 80)}", actor="driver", at=now_iso()))
        elif ev == "delivered" and o["status"] in ("ready", "picked_up"):
            t.run("UPDATE orders SET status='delivered', proof_note=:p, updated_at=:u WHERE id=:id", p=s(body.get("proof_note"), 300), u=now_iso(), id=oid)
            t.insert("order_events", dict(order_id=oid, status="delivered", note=s(body.get("proof_note"), 300), actor="driver", at=now_iso()))
            if not o["transfer_requested"]:
                t.run("UPDATE orders SET transfer_requested=1 WHERE id=:id", id=oid)
                outbox.enqueue(t, "payments", "/internal/transfers", {"order_id": oid, "store_id": o["store_id"], "checkout_id": o["checkout_id"],
                                                                      "amount_cents": o["subtotal_cents"] - o["commission_cents"]})
    outbox.flush()
    return {"ok": True}


@app.get("/internal/stats/customer-order-counts", dependencies=INTERNAL, tags=["internal"])
def internal_customer_counts():
    return {str(r["customer_id"]): r["c"] for r in db.all("SELECT customer_id, COUNT(*) AS c FROM orders WHERE status<>'pending_payment' GROUP BY customer_id")}


@app.get("/internal/stats/store-sales", dependencies=INTERNAL, tags=["internal"])
def internal_store_sales():
    return {str(r["store_id"]): {"orders": r["orders"], "sales": r["sales"]} for r in
            db.all("SELECT store_id, COUNT(*) AS orders, COALESCE(SUM(subtotal_cents),0) AS sales FROM orders WHERE status='delivered' GROUP BY store_id")}


__all__ = ["app", "timedelta"]
