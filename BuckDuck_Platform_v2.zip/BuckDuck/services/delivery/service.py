"""Delivery service — Saturday delivery windows, capacity, drivers, delivery jobs and routes.

Owns: delivery_windows, drivers, delivery_jobs, delivery settings. Database: its own (DELIVERY_DATABASE_URL).
A delivery job is created (by an event from the orders service) when an order is paid. Drivers claim,
pick up and deliver jobs here; every change is sent back to the orders service through the outbox.
"""
from __future__ import annotations

import json
from datetime import datetime, timedelta

from fastapi import Depends, HTTPException
from sqlalchemy import Column, Integer, MetaData, String, Table, Text, UniqueConstraint

from buckduck_common import seed
from buckduck_common.app import create_app
from buckduck_common.auth import internal_only, require
from buckduck_common.config import DATA_DIR, database_url, env
from buckduck_common.db import Database
from buckduck_common.outbox import Outbox, outbox_table
from buckduck_common.util import next_weekday, now_iso, s, save_image, to_int, today, window_label, ymd

md = MetaData()
Table("delivery_windows", md,
      Column("id", Integer, primary_key=True, autoincrement=True),
      Column("date", String(10), nullable=False, index=True), Column("start_time", String(5), nullable=False),
      Column("end_time", String(5), nullable=False), Column("label", String(60)),
      Column("capacity", Integer, nullable=False, default=120), Column("active", Integer, nullable=False, default=1),
      UniqueConstraint("date", "start_time"))
Table("drivers", md,
      Column("id", Integer, primary_key=True, autoincrement=False),   # same id as the identity user
      Column("name", String(80), nullable=False), Column("phone", String(30)), Column("vehicle", String(80)),
      Column("online", Integer, nullable=False, default=0), Column("status", String(20), nullable=False, default="active"),
      Column("updated_at", String(40)))
Table("delivery_jobs", md,
      Column("order_id", Integer, primary_key=True, autoincrement=False),
      Column("number", String(20)), Column("window_id", Integer, index=True), Column("window_date", String(10)),
      Column("window_start", String(5)), Column("window_end", String(5)),
      Column("store_id", Integer), Column("store_name", String(80)), Column("store_address", String(160)),
      Column("store_city", String(60)), Column("store_zip", String(10)),
      Column("customer_id", Integer), Column("customer_name", String(80)),
      Column("address_line1", String(160)), Column("address_line2", String(60)), Column("city", String(60)),
      Column("state", String(2)), Column("zip", String(10)), Column("phone", String(30)), Column("notes", Text),
      Column("bags", Integer, default=1), Column("item_count", Integer, default=0),
      Column("driver_pay_cents", Integer, default=0), Column("tip_cents", Integer, default=0),
      Column("status", String(20), nullable=False, index=True),   # pending | open | picked_up | delivered | cancelled
      Column("driver_id", Integer, index=True), Column("proof_note", Text),
      Column("created_at", String(40)), Column("updated_at", String(40)), Column("delivered_at", String(40)))
Table("delivery_settings", md, Column("key", String(60), primary_key=True), Column("value", String(300), nullable=False))
outbox_table(md)

db = Database(database_url("delivery"), md)
outbox = Outbox(db)
app = create_app("delivery", "Saturday delivery windows, capacity, drivers, delivery jobs and routes.", db=db, outbox=outbox)
MEDIA_DIR = DATA_DIR / "media"
DEFAULTS = {"delivery_weekday": "6", "default_slots": '[["06:00","12:00"],["12:00","16:00"]]', "windows_weeks_ahead": "4",
            "default_window_capacity": "120", "order_cutoff_hours": "24"}
UI_STATUS = {"pending": "accepted", "open": "ready", "picked_up": "picked_up", "delivered": "delivered", "cancelled": "cancelled"}
MAX_ROUTE_STOPS = 12


def setting(k: str) -> str:
    r = db.one("SELECT value FROM delivery_settings WHERE key=:k", k=k)
    return r["value"] if r else DEFAULTS[k]


@app.on_event("startup")
def startup():
    db.create_all()
    if env("SEED_DEMO_DATA", "true") == "true" and not db.scalar("SELECT COUNT(*) FROM delivery_windows"):
        d = seed.dataset()
        with db.tx() as t:
            t.insert_many("delivery_windows", d["windows"])
            t.insert_many("drivers", [dict(id=u["id"], name=u["name"], phone=u["phone"], vehicle=u["vehicle"], online=u["online"], status="active",
                                           updated_at=u["created_at"]) for u in d["drivers"]])
            t.insert_many("delivery_jobs", d["jobs"])
        db.fix_sequences(["delivery_windows"])
    outbox.start()


# ---------------------------------------------------------------- windows
def ensure_windows() -> None:
    try:
        slots = json.loads(setting("default_slots"))
    except ValueError:
        slots = json.loads(DEFAULTS["default_slots"])
    d = next_weekday(today(), int(setting("delivery_weekday")))
    cap = int(setting("default_window_capacity"))
    with db.tx() as t:
        for _ in range(int(setting("windows_weeks_ahead"))):
            for a, b in slots:
                t.run("""INSERT INTO delivery_windows(date,start_time,end_time,label,capacity,active) VALUES(:d,:a,:b,:l,:c,1)
                         ON CONFLICT(date,start_time) DO NOTHING""", d=ymd(d), a=a, b=b, l=window_label(a, b), c=cap)
            d += timedelta(days=7)


def window_view(w: dict) -> dict:
    booked = int(db.scalar("SELECT COUNT(*) FROM delivery_jobs WHERE window_id=:w AND status<>'cancelled'", w=w["id"]) or 0)
    start = datetime.fromisoformat(f"{w['date']}T{w['start_time']}:00")
    cutoff = start - timedelta(hours=int(setting("order_cutoff_hours")))
    return dict(w, active=bool(w["active"]), booked=booked, remaining=max(0, w["capacity"] - booked), cutoff=cutoff.isoformat(),
                open=bool(w["active"]) and datetime.now() < cutoff and booked < w["capacity"])


def upcoming() -> list[dict]:
    ensure_windows()
    return [window_view(w) for w in db.all("SELECT * FROM delivery_windows WHERE date>=:d ORDER BY date, start_time", d=ymd(today()))]


@app.get("/api/windows", tags=["windows"])
def public_windows():
    return {"windows": [w for w in upcoming() if w["active"]]}


@app.get("/api/admin/windows", tags=["admin"])
def admin_windows(_=Depends(require("admin"))):
    ensure_windows()
    return {"windows": [window_view(w) for w in db.all("SELECT * FROM delivery_windows WHERE date>=:d ORDER BY date, start_time",
                                                        d=ymd(today() - timedelta(days=14)))]}


@app.post("/api/admin/windows", tags=["admin"])
def admin_add_window(body: dict, _=Depends(require("admin"))):
    d, a, b = s(body.get("date"), 10), s(body.get("start_time"), 5), s(body.get("end_time"), 5)
    try:
        datetime.strptime(d, "%Y-%m-%d"), datetime.strptime(a, "%H:%M"), datetime.strptime(b, "%H:%M")
        assert a < b
    except (ValueError, AssertionError):
        raise HTTPException(400, "Enter a valid date and time range")  # noqa: B904
    if db.one("SELECT id FROM delivery_windows WHERE date=:d AND start_time=:a", d=d, a=a):
        raise HTTPException(409, "A window already starts at that time")
    with db.tx() as t:
        wid = t.insert("delivery_windows", dict(date=d, start_time=a, end_time=b, label=window_label(a, b), capacity=max(1, to_int(body.get("capacity"), 120)), active=1))
    return {"window": window_view(db.one("SELECT * FROM delivery_windows WHERE id=:id", id=wid))}


@app.put("/api/admin/windows/{wid}", tags=["admin"])
def admin_update_window(wid: int, body: dict, _=Depends(require("admin"))):
    w = db.one("SELECT * FROM delivery_windows WHERE id=:id", id=wid)
    if not w:
        raise HTTPException(404, "Window not found")
    cap = max(0, to_int(body.get("capacity"), w["capacity"])) if body.get("capacity") is not None else w["capacity"]
    act = w["active"] if body.get("active") is None else (1 if body.get("active") else 0)
    db.one("UPDATE delivery_windows SET capacity=:c, active=:a WHERE id=:id RETURNING id", c=cap, a=act, id=wid)
    return {"window": window_view(db.one("SELECT * FROM delivery_windows WHERE id=:id", id=wid))}


@app.get("/api/admin/settings", tags=["admin"])
def get_settings(_=Depends(require("admin"))):
    return {"settings": {k: setting(k) for k in DEFAULTS}}


@app.put("/api/admin/settings", tags=["admin"])
def put_settings(body: dict, _=Depends(require("admin"))):
    for k, v in (body or {}).items():
        if k not in DEFAULTS:
            continue
        v = str(v).strip()
        if k == "default_slots":
            try:
                sl = json.loads(v)
                assert isinstance(sl, list) and sl and all(isinstance(x, list) and len(x) == 2 for x in sl)
            except (ValueError, AssertionError):
                raise HTTPException(400, 'Default windows must look like [["06:00","12:00"],["12:00","16:00"]]')  # noqa: B904
        elif k == "delivery_weekday":
            if v not in [str(i) for i in range(7)]:
                raise HTTPException(400, "Delivery day must be 0–6")
        elif not v.isdigit():
            raise HTTPException(400, f"Invalid value for {k}")
        db.one("INSERT INTO delivery_settings(key,value) VALUES(:k,:v) ON CONFLICT(key) DO UPDATE SET value=excluded.value RETURNING key", k=k, v=v)
    return get_settings()


# ---------------------------------------------------------------- drivers
def job_view(j: dict) -> dict:
    """Shape a job like an order so the driver app can show it."""
    return dict(j, id=j["order_id"], status=UI_STATUS.get(j["status"], j["status"]), job_status=j["status"])


def driver(user: dict) -> dict:
    d = db.one("SELECT * FROM drivers WHERE id=:id", id=user["id"])
    if not d:   # identity may not have delivered the profile event yet
        with db.tx() as t:
            t.run("INSERT INTO drivers(id,name,online,status,updated_at) VALUES(:id,:n,0,'active',:u) ON CONFLICT(id) DO NOTHING",
                  id=user["id"], n=user["name"], u=now_iso())
        d = db.one("SELECT * FROM drivers WHERE id=:id", id=user["id"])
    if d["status"] != "active":
        raise HTTPException(403, "Your driver account is suspended. Contact support.")
    return d


@app.get("/api/driver/summary", tags=["driver"])
def driver_summary(user=Depends(require("driver"))):
    d = driver(user)
    totals = db.one("""SELECT COUNT(*) AS deliveries, COALESCE(SUM(driver_pay_cents),0) AS earnings, COALESCE(SUM(tip_cents),0) AS tips
                       FROM delivery_jobs WHERE driver_id=:d AND status='delivered'""", d=d["id"])
    weeks = db.all("""SELECT window_date AS date, COUNT(*) AS deliveries, SUM(driver_pay_cents) AS earnings, SUM(tip_cents) AS tips FROM delivery_jobs
                      WHERE driver_id=:d AND status='delivered' GROUP BY window_date ORDER BY window_date DESC LIMIT 8""", d=d["id"])
    active = db.scalar("SELECT COUNT(*) FROM delivery_jobs WHERE driver_id=:d AND status IN ('open','picked_up')", d=d["id"])
    available = db.scalar("SELECT COUNT(*) FROM delivery_jobs WHERE status='open' AND driver_id IS NULL")
    nxt = upcoming()
    from buckduck_common.http import try_call
    base = (try_call("orders", "GET", "/internal/config", fallback={}) or {}).get("driver_base_pay_cents", seed.FEES["driver_base"])
    return {"user": dict(id=d["id"], name=d["name"], email=user["email"], role="driver", phone=d["phone"], vehicle=d["vehicle"], driver_online=bool(d["online"])),
            "totals": totals, "weeks": weeks, "active": active, "available": available, "next_window": nxt[0] if nxt else None, "base_pay_cents": base}


@app.post("/api/driver/online", tags=["driver"])
def driver_online(body: dict, user=Depends(require("driver"))):
    driver(user)
    db.one("UPDATE drivers SET online=:o, updated_at=:u WHERE id=:id RETURNING id", o=1 if body.get("online") else 0, u=now_iso(), id=user["id"])
    return {"online": bool(body.get("online"))}


@app.get("/api/driver/available", tags=["driver"])
def driver_available(user=Depends(require("driver"))):
    driver(user)
    rows = db.all("SELECT * FROM delivery_jobs WHERE status='open' AND driver_id IS NULL ORDER BY window_date, window_start, order_id LIMIT 100")
    # Customer's street address and phone stay hidden until the driver accepts the job.
    return {"orders": [dict(job_view(j), address_line1=None, address_line2=None, phone=None, customer_name=None) for j in rows]}


@app.get("/api/driver/route", tags=["driver"])
def driver_route(user=Depends(require("driver"))):
    driver(user)
    rows = db.all("""SELECT * FROM delivery_jobs WHERE driver_id=:d AND status IN ('open','picked_up')
                     ORDER BY window_date, window_start, CASE status WHEN 'picked_up' THEN 0 ELSE 1 END, order_id""", d=user["id"])
    return {"orders": [job_view(j) for j in rows]}


@app.get("/api/driver/history", tags=["driver"])
def driver_history(user=Depends(require("driver"))):
    driver(user)
    rows = db.all("SELECT * FROM delivery_jobs WHERE driver_id=:d AND status='delivered' ORDER BY delivered_at DESC LIMIT 60", d=user["id"])
    return {"orders": [job_view(j) for j in rows]}


def emit(t, order_id: int, event: str, **data) -> None:
    outbox.enqueue(t, "orders", f"/internal/orders/{order_id}/delivery-event", dict(event=event, at=now_iso(), **data))


@app.post("/api/driver/orders/{oid}/claim", tags=["driver"])
def driver_claim(oid: int, user=Depends(require("driver"))):
    d = driver(user)
    if not d["online"]:
        raise HTTPException(400, "Go online to accept deliveries")
    if db.scalar("SELECT COUNT(*) FROM delivery_jobs WHERE driver_id=:d AND status IN ('open','picked_up')", d=d["id"]) >= MAX_ROUTE_STOPS:
        raise HTTPException(400, f"You have reached the {MAX_ROUTE_STOPS}-stop route limit")
    with db.tx() as t:
        if not t.run("UPDATE delivery_jobs SET driver_id=:d, updated_at=:u WHERE order_id=:o AND status='open' AND driver_id IS NULL", d=d["id"], u=now_iso(), o=oid):
            raise HTTPException(409, "Another driver already accepted this delivery")
        emit(t, oid, "assigned", driver_id=d["id"], driver_name=d["name"], driver_phone=d["phone"], driver_vehicle=d["vehicle"], actor="driver")
    outbox.flush()
    return {"order": job_view(db.one("SELECT * FROM delivery_jobs WHERE order_id=:o", o=oid))}


@app.post("/api/driver/orders/{oid}/release", tags=["driver"])
def driver_release(oid: int, user=Depends(require("driver"))):
    with db.tx() as t:
        if not t.run("UPDATE delivery_jobs SET driver_id=NULL, updated_at=:u WHERE order_id=:o AND driver_id=:d AND status='open'", u=now_iso(), o=oid, d=user["id"]):
            raise HTTPException(400, "Only un-picked orders can be released")
        emit(t, oid, "released", actor="driver")
    outbox.flush()
    return {"ok": True}


@app.post("/api/driver/orders/{oid}/status", tags=["driver"])
def driver_status(oid: int, body: dict, user=Depends(require("driver"))):
    j = db.one("SELECT * FROM delivery_jobs WHERE order_id=:o AND driver_id=:d", o=oid, d=user["id"])
    if not j:
        raise HTTPException(404, "Order not found")
    nxt = s(body.get("status"), 20)
    if not ((j["status"] == "open" and nxt == "picked_up") or (j["status"] == "picked_up" and nxt == "delivered")):
        raise HTTPException(400, "Invalid status change")
    proof = None
    if nxt == "delivered":
        proof = s(body.get("proof_note"), 200)
        if not proof:
            raise HTTPException(400, 'Add a delivery note (e.g. "Left at front door")')
        if body.get("photo_data"):
            proof = f"{proof} | photo: {save_image(body['photo_data'], MEDIA_DIR)}"
    n = now_iso()
    with db.tx() as t:
        t.run("UPDATE delivery_jobs SET status=:s, proof_note=:p, updated_at=:u, delivered_at=:da WHERE order_id=:o",
              s=nxt, p=proof if proof is not None else j["proof_note"], u=n, da=n if nxt == "delivered" else j["delivered_at"], o=oid)
        emit(t, oid, nxt, proof_note=proof, actor="driver", driver_name=user["name"])
    outbox.flush()
    return {"order": job_view(db.one("SELECT * FROM delivery_jobs WHERE order_id=:o", o=oid))}


@app.get("/api/admin/drivers", tags=["admin"])
def admin_drivers(_=Depends(require("admin"))):
    rows = db.all("""SELECT d.*, d.online AS driver_online,
        (SELECT COUNT(*) FROM delivery_jobs j WHERE j.driver_id=d.id AND j.status='delivered') AS deliveries,
        (SELECT COALESCE(SUM(driver_pay_cents),0) FROM delivery_jobs j WHERE j.driver_id=d.id AND j.status='delivered') AS earnings,
        (SELECT COUNT(*) FROM delivery_jobs j WHERE j.driver_id=d.id AND j.status IN ('open','picked_up')) AS active
        FROM drivers d ORDER BY d.online DESC, d.name""")
    from buckduck_common.http import try_call
    emails = {u["id"]: u["email"] for u in (try_call("identity", "GET", "/internal/users", fallback={},
                                                     params={"ids": ",".join(str(r["id"]) for r in rows)}) or {}).get("users", [])}
    for r in rows:
        r["driver_online"] = bool(r["driver_online"])
        r["email"] = emails.get(r["id"], "")
    return {"drivers": rows}


# ---------------------------------------------------------------- internal (events from other services)
INTERNAL = [Depends(internal_only)]


@app.get("/internal/windows/{wid}", dependencies=INTERNAL, tags=["internal"])
def internal_window(wid: int):
    w = db.one("SELECT * FROM delivery_windows WHERE id=:id", id=wid)
    if not w:
        raise HTTPException(404, "Delivery window not found")
    return {"window": window_view(w)}


@app.get("/internal/windows", dependencies=INTERNAL, tags=["internal"])
def internal_windows():
    return {"windows": upcoming()}


@app.post("/internal/jobs", dependencies=INTERNAL, tags=["internal"])
def internal_create_job(body: dict):
    """Order paid → create the delivery job (idempotent)."""
    cols = ["order_id", "number", "window_id", "window_date", "window_start", "window_end", "store_id", "store_name", "store_address", "store_city",
            "store_zip", "customer_id", "customer_name", "address_line1", "address_line2", "city", "state", "zip", "phone", "notes", "bags",
            "item_count", "driver_pay_cents", "tip_cents"]
    data = {k: body.get(k) for k in cols}
    data.update(status="pending", created_at=now_iso(), updated_at=now_iso())
    with db.tx() as t:
        t.run(f"INSERT INTO delivery_jobs({','.join(data)}) VALUES({','.join(':' + k for k in data)}) ON CONFLICT(order_id) DO NOTHING", **data)
    return {"ok": True}


@app.post("/internal/jobs/{oid}/sync", dependencies=INTERNAL, tags=["internal"])
def internal_sync_job(oid: int, body: dict):
    """Order status changed in the orders service → mirror it on the job."""
    j = db.one("SELECT * FROM delivery_jobs WHERE order_id=:o", o=oid)
    if not j:
        return {"ok": False, "missing": True}
    st = body.get("order_status")
    target = {"placed": "pending", "accepted": "pending", "packing": "pending", "ready": "open", "picked_up": "picked_up",
              "delivered": "delivered", "cancelled": "cancelled", "refunded": "cancelled"}.get(st)
    if not target:
        return {"ok": True}
    bags = to_int(body.get("bags"), j["bags"]) or j["bags"]
    driver_id = j["driver_id"] if target != "cancelled" else None
    if j["status"] == "delivered" and target != "delivered":
        target = "delivered" if st not in ("cancelled", "refunded") else target
    n = now_iso()
    delivered_at = (j["delivered_at"] or n) if target == "delivered" else j["delivered_at"]
    db.one("UPDATE delivery_jobs SET status=:s, bags=:b, driver_id=:d, updated_at=:u, delivered_at=:da WHERE order_id=:o RETURNING order_id",
           s=target, b=bags, d=driver_id, u=n, da=delivered_at, o=oid)
    return {"ok": True}


@app.post("/internal/jobs/{oid}/assign", dependencies=INTERNAL, tags=["internal"])
def internal_assign(oid: int, body: dict):
    """Admin assigns (or clears) a driver from the console. Returns the driver snapshot."""
    j = db.one("SELECT * FROM delivery_jobs WHERE order_id=:o", o=oid)
    if not j:
        raise HTTPException(404, "Delivery job not found")
    did = body.get("driver_id")
    if did:
        d = db.one("SELECT * FROM drivers WHERE id=:id AND status='active'", id=to_int(did))
        if not d:
            raise HTTPException(400, "Driver not found")
        db.one("UPDATE delivery_jobs SET driver_id=:d, updated_at=:u WHERE order_id=:o RETURNING order_id", d=d["id"], u=now_iso(), o=oid)
        return {"driver": {k: d[k] for k in ("id", "name", "phone", "vehicle")}}
    db.one("UPDATE delivery_jobs SET driver_id=NULL, updated_at=:u WHERE order_id=:o RETURNING order_id", u=now_iso(), o=oid)
    return {"driver": None}


@app.post("/internal/drivers", dependencies=INTERNAL, tags=["internal"])
def internal_upsert_driver(body: dict):
    did = to_int(body.get("id"))
    with db.tx() as t:
        t.run("""INSERT INTO drivers(id,name,phone,vehicle,online,status,updated_at) VALUES(:id,:n,:p,:v,0,'active',:u)
                 ON CONFLICT(id) DO UPDATE SET name=excluded.name, phone=excluded.phone, vehicle=COALESCE(excluded.vehicle, drivers.vehicle), updated_at=excluded.updated_at""",
              id=did, n=s(body.get("name"), 80) or "Driver", p=s(body.get("phone"), 30), v=s(body.get("vehicle"), 80) or None, u=now_iso())
    return {"ok": True}


@app.get("/internal/drivers/{did}", dependencies=INTERNAL, tags=["internal"])
def internal_driver(did: int):
    return {"driver": db.one("SELECT * FROM drivers WHERE id=:id", id=did)}


@app.post("/internal/drivers/{did}/status", dependencies=INTERNAL, tags=["internal"])
def internal_driver_status(did: int, body: dict):
    st = "suspended" if body.get("status") == "suspended" else "active"
    with db.tx() as t:
        if st == "suspended":
            t.run("UPDATE drivers SET status=:s, online=0, updated_at=:u WHERE id=:id", s=st, u=now_iso(), id=did)
        else:
            t.run("UPDATE drivers SET status=:s, updated_at=:u WHERE id=:id", s=st, u=now_iso(), id=did)
        if st == "suspended":
            for j in t.all("SELECT order_id FROM delivery_jobs WHERE driver_id=:d AND status='open'", d=did):
                t.run("UPDATE delivery_jobs SET driver_id=NULL WHERE order_id=:o", o=j["order_id"])
                emit(t, j["order_id"], "released", actor="admin")
    outbox.flush()
    return {"ok": True}


@app.get("/internal/stats", dependencies=INTERNAL, tags=["internal"])
def internal_stats():
    return {"drivers": db.scalar("SELECT COUNT(*) FROM drivers"),
            "drivers_online": db.scalar("SELECT COUNT(*) FROM drivers WHERE online=1 AND status='active'"),
            "unassigned_ready": db.scalar("SELECT COUNT(*) FROM delivery_jobs WHERE status='open' AND driver_id IS NULL"),
            "windows": upcoming()[:4]}


@app.get("/internal/config", dependencies=INTERNAL, tags=["internal"])
def internal_config():
    w = next((x for x in upcoming() if x["open"]), None)
    return {"delivery_weekday": int(setting("delivery_weekday")), "next_window": w}
