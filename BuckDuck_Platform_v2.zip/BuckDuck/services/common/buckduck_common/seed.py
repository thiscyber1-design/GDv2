"""Deterministic demo dataset.

Each service seeds ONLY the tables it owns from this one dataset, so IDs line up across the five
separate databases (for example, order 42 in the orders DB matches delivery job 42 in the delivery
DB). Set SEED_DEMO_DATA=false to start every database empty.
"""
from __future__ import annotations

import math
import random
from datetime import datetime, time as dtime, timedelta, timezone
from functools import lru_cache

from .util import next_weekday, slugify, today, window_label, ymd

DEMO_PASSWORD = "demo1234"

STORES = [
    dict(name="Accra Market", owner="merchant@buckduck.com", owner_name="Efua Boateng", category="African Groceries", emoji="🌍", color="#B7791F", zip="77036",
         tagline="Ghanaian staples, fresh every week", description="Family-owned since 2009. Gari, kenkey, palm oil, smoked fish and the flavors of home — packed fresh for Saturday delivery.",
         products=[("Gari (White), 4 lb", "Staples", 899, "4 lb bag", "🍚"), ("Red Palm Oil", "Pantry", 1099, "1 L", "🫙"), ("Ripe Plantains", "Produce", 499, "bunch of 5", "🍌"),
                   ("Shito Hot Pepper Sauce", "Pantry", 799, "12 oz jar", "🌶️"), ("Fresh Kenkey", "Prepared", 1299, "5 balls", "🍙"), ("Fufu Flour", "Staples", 699, "24 oz", "🥣"),
                   ("Smoked Herring", "Seafood", 1499, "1 lb", "🐟"), ("Kontomire Leaves", "Produce", 599, "1 lb", "🥬"), ("Jollof Spice Blend", "Spices", 499, "6 oz", "🧂"),
                   ("Roasted Corn Cereal", "Breakfast", 899, "1 kg", "🥣"), ("Puna Yam", "Produce", 1299, "per tuber", "🍠"), ("Chocolate Malt Drink Mix", "Beverages", 899, "400 g", "☕")]),
    dict(name="Green Valley Produce", owner="greenvalley@buckduck.com", owner_name="Daniel Ortiz", category="Fresh Produce", emoji="🥬", color="#2F855A", zip="77042",
         tagline="Farm-direct fruits & vegetables", description="We source from Texas growers every Thursday so your produce is at peak freshness on Saturday.",
         products=[("Roma Tomatoes", "Vegetables", 199, "per lb", "🍅"), ("Red Onions", "Vegetables", 349, "3 lb bag", "🧅"), ("Hass Avocados", "Fruit", 599, "4 count", "🥑"),
                   ("Baby Spinach", "Greens", 449, "10 oz", "🥬"), ("Bananas", "Fruit", 69, "per lb", "🍌"), ("Honeycrisp Apples", "Fruit", 699, "3 lb bag", "🍎"),
                   ("Strawberries", "Fruit", 499, "1 lb", "🍓"), ("Carrots", "Vegetables", 249, "2 lb", "🥕"), ("Sweet Potatoes", "Vegetables", 149, "per lb", "🍠"),
                   ("Lemons", "Fruit", 399, "2 lb bag", "🍋"), ("Broccoli Crowns", "Vegetables", 299, "per lb", "🥦"), ("Bell Peppers", "Vegetables", 449, "3 pack", "🫑")]),
    dict(name="Lagos Pantry", owner="lagos@buckduck.com", owner_name="Tunde Adeyemi", category="African Groceries", emoji="🌶️", color="#C53030", zip="77099",
         tagline="Nigerian kitchen essentials", description="Egusi, ogbono, crayfish, stockfish and everything you need for Sunday stew — delivered Saturday.",
         products=[("Ground Egusi", "Pantry", 899, "1 lb", "🥜"), ("Semolina Flour", "Staples", 999, "5 lb", "🌾"), ("Honey Beans", "Staples", 1099, "4 lb", "🫘"),
                   ("Ground Crayfish", "Seafood", 1199, "8 oz", "🦐"), ("Ogbono Seeds", "Pantry", 1099, "8 oz", "🥜"), ("Suya Spice (Yaji)", "Spices", 599, "6 oz", "🌶️"),
                   ("Chin Chin", "Snacks", 499, "14 oz", "🍪"), ("Instant Noodles", "Pantry", 1899, "40 pack", "🍜"), ("Stockfish Cuts", "Seafood", 2499, "1 lb", "🐟"),
                   ("Frozen Ugu Leaves", "Frozen", 699, "1 lb", "🥬"), ("Yellow Garri", "Staples", 899, "4 lb", "🍚"), ("Malt Drink", "Beverages", 899, "6 pack", "🥤")]),
    dict(name="Island Spice Mart", owner="island@buckduck.com", owner_name="Marcia Campbell", category="Caribbean", emoji="🍍", color="#D69E2E", zip="77071",
         tagline="Caribbean flavor, island fresh", description="From scotch bonnets to saltfish — the authentic taste of Jamaica, Trinidad and beyond.",
         products=[("Scotch Bonnet Peppers", "Produce", 399, "8 oz", "🌶️"), ("Canned Ackee", "Pantry", 1299, "19 oz", "🥫"), ("Jerk Seasoning", "Spices", 699, "10 oz", "🍖"),
                   ("Callaloo", "Pantry", 349, "19 oz can", "🥬"), ("Coco Bread", "Bakery", 499, "4 pack", "🥖"), ("Breadfruit", "Produce", 599, "each", "🍈"),
                   ("Dried Sorrel", "Beverages", 699, "4 oz", "🌺"), ("Island Curry Powder", "Spices", 499, "8 oz", "🍛"), ("Ginger Beer", "Beverages", 799, "4 pack", "🥤"),
                   ("Boneless Saltfish", "Seafood", 1399, "1 lb", "🐟"), ("Golden Pineapple", "Produce", 399, "each", "🍍"), ("Coconut Milk", "Pantry", 249, "13.5 oz", "🥥")]),
    dict(name="Prime Cut Halal Meats", owner="primecut@buckduck.com", owner_name="Yusuf Hassan", category="Meat & Seafood", emoji="🥩", color="#9B2C2C", zip="77074",
         tagline="Hand-cut halal meats & fresh fish", description="Certified halal butcher. Every order is cut, sealed and chilled the morning of delivery.",
         products=[("Whole Chicken", "Poultry", 1299, "4–5 lb", "🍗"), ("Goat Meat, Cubed", "Goat & Lamb", 999, "per lb", "🥩"), ("Beef Stew Meat", "Beef", 899, "per lb", "🥩"),
                   ("Lamb Chops", "Goat & Lamb", 1699, "per lb", "🍖"), ("Whole Tilapia", "Seafood", 799, "per lb", "🐟"), ("Party Wings", "Poultry", 1199, "3 lb", "🍗"),
                   ("Ground Beef 80/20", "Beef", 699, "per lb", "🥩"), ("Turkey Wings", "Poultry", 899, "2 lb", "🦃"), ("Jumbo Shrimp", "Seafood", 1299, "1 lb", "🦐"), ("Suya-Cut Beef", "Beef", 1099, "per lb", "🥩")]),
    dict(name="Golden Crust Bakery", owner="goldencrust@buckduck.com", owner_name="Grace Okafor", category="Bakery", emoji="🥐", color="#975A16", zip="77057",
         tagline="Baked before sunrise, delivered by noon", description="Sweet breads, meat pies and pastries baked Saturday at 3 AM for the morning window.",
         products=[("Sourdough Loaf", "Bread", 799, "each", "🍞"), ("Sweet Bread Loaf", "Bread", 599, "each", "🍞"), ("Meat Pies", "Savory", 999, "4 pack", "🥧"),
                   ("Butter Croissants", "Pastry", 899, "4 pack", "🥐"), ("Puff-Puff", "Pastry", 699, "dozen", "🍩"), ("Banana Bread", "Bread", 899, "loaf", "🍌"),
                   ("Bagels", "Bread", 699, "6 pack", "🥯"), ("Cinnamon Rolls", "Pastry", 1099, "4 pack", "🥮")]),
    dict(name="Nairobi Fresh", owner="nairobi@buckduck.com", owner_name="Wanjiru Kamau", category="African Groceries", emoji="☕", color="#276749", zip="77036", pending=True,
         tagline="East African groceries & coffee", description="Ugali flour, chai masala, Kenyan coffee and more.",
         products=[("Maize Flour (Ugali)", "Staples", 799, "2 kg", "🌽"), ("Kenyan AA Coffee", "Beverages", 1599, "12 oz", "☕"), ("Chai Masala", "Spices", 599, "4 oz", "🫖")]),
]
CUSTOMERS = ["Ama Mensah", "Kofi Owusu", "Chidinma Eze", "Jessica Turner", "Michael Brooks", "Abena Darko", "Samuel Johnson", "Nadia Rahman",
             "Kevin Nguyen", "Funmi Balogun", "Andre Williams", "Priya Patel", "Yaw Antwi", "Rachel Kim", "Olu Adebayo", "Tasha Green"]
DRIVERS = [("Kwame Asante", "driver@buckduck.com", "Toyota Sienna · Silver"), ("Luis Ramirez", "luis@buckduck.com", "Ford Transit · White"),
           ("Brianna Scott", "brianna@buckduck.com", "Honda CR-V · Blue"), ("Emeka Nwosu", "emeka@buckduck.com", "Chevy Express · White"),
           ("Hannah Lee", "hannah@buckduck.com", "Kia Carnival · Gray")]
STREETS = ["Bellaire Blvd", "Westheimer Rd", "Bissonnet St", "Beechnut St", "Fondren Rd", "Hillcroft Ave", "Gessner Rd", "Richmond Ave", "Wilcrest Dr", "Kirkwood Rd"]
SLOTS = [("06:00", "12:00"), ("12:00", "16:00")]
FEES = dict(delivery=599, service_rate=0.05, service_min=199, commission=0.15, driver_base=550)


@lru_cache(maxsize=1)
def dataset() -> dict:
    rnd = random.Random(20261004)
    pick = rnd.choice
    now = datetime.now(timezone.utc)
    iso = lambda d: d.isoformat()  # noqa: E731
    days_ago = lambda n: now - timedelta(days=n)  # noqa: E731

    users, stores, products, windows, orders, jobs = [], [], [], [], [], []
    phone = lambda: f"(713) 555-{1000 + rnd.randint(0, 8998)}"  # noqa: E731

    def add_user(email, name, role, **extra):
        u = dict(id=len(users) + 1, email=email, name=name, role=role, phone=extra.get("phone") or phone(), status="active",
                 created_at=iso(days_ago(120 + rnd.randint(0, 60))), vehicle=extra.get("vehicle"), online=1 if extra.get("online") else 0)
        users.append(u)
        return u

    add_user("admin@buckduck.com", "BuckDuck Operations", "admin")
    customers = [add_user("customer@buckduck.com" if i == 0 else f"{n.split()[0].lower()}@example.com", n, "customer") for i, n in enumerate(CUSTOMERS)]
    drivers = [add_user(e, n, "driver", vehicle=v, online=i < 3) for i, (n, e, v) in enumerate(DRIVERS)]

    for si, st in enumerate(STORES):
        owner = add_user(st["owner"], st["owner_name"], "merchant")
        store = dict(id=si + 1, owner_id=owner["id"], name=st["name"], slug=slugify(st["name"]), tagline=st["tagline"], description=st["description"],
                     category=st["category"], address=f"{1000 + rnd.randint(0, 8999)} {pick(STREETS)}", city="Houston", state="TX", zip=st["zip"],
                     phone=f"(713) 555-0{100 + si}", color=st["color"], emoji=st["emoji"], logo_url=None,
                     status="pending" if st.get("pending") else "active", commission_rate=FEES["commission"],
                     rating=round(4.5 + rnd.random() * 0.5, 1), created_at=iso(days_ago(2 if st.get("pending") else 100)))
        stores.append(store)
        for name, cat, price, unit, emoji in st["products"]:
            products.append(dict(id=len(products) + 1, store_id=store["id"], name=name, description=f"{name} from {st['name']}.", category=cat,
                                 price_cents=price, unit=unit, stock=20 + rnd.randint(0, 79), emoji=emoji, image_url=None, active=1,
                                 created_at=iso(days_ago(90))))

    by_store = {s["id"]: [p for p in products if p["store_id"] == s["id"]] for s in stores}
    active_stores = [s for s in stores if s["status"] == "active"]
    sat = next_weekday(today(), 6)

    def add_windows(d):
        ids = []
        for a, b in SLOTS:
            w = dict(id=len(windows) + 1, date=ymd(d), start_time=a, end_time=b, label=window_label(a, b), capacity=120, active=1)
            windows.append(w)
            ids.append(w)
        return ids

    def make_order(cust, store, win, status, created, driver=None):
        n = 1 + rnd.randint(0, 4)
        items, used = [], set()
        for _ in range(n):
            p = pick(by_store[store["id"]])
            if p["id"] in used:
                continue
            used.add(p["id"])
            items.append(dict(product_id=p["id"], name=p["name"], emoji=p["emoji"], unit=p["unit"], price_cents=p["price_cents"], qty=1 + rnd.randint(0, 2)))
        sub = sum(i["price_cents"] * i["qty"] for i in items)
        service = max(FEES["service_min"], round(sub * FEES["service_rate"]))
        tip = pick([0, 200, 300, 500, 500, 800])
        oid = len(orders) + 1
        flow = ["placed", status] if status in ("refunded", "cancelled") else \
            ["placed", "accepted", "packing", "ready", "picked_up", "delivered"][: ["placed", "accepted", "packing", "ready", "picked_up", "delivered"].index(status) + 1]
        events = [dict(status=st, note="", actor="system", at=iso(created + timedelta(hours=6 * i))) for i, st in enumerate(flow)]
        qty = sum(i["qty"] for i in items)
        o = dict(id=oid, number=f"BD-{10000 + oid}", checkout_id=oid, customer_id=cust["id"], customer_name=cust["name"], customer_email=cust["email"],
                 store_id=store["id"], store_owner_id=store["owner_id"], store_name=store["name"], store_slug=store["slug"], store_emoji=store["emoji"],
                 store_color=store["color"], store_address=store["address"], store_city=store["city"], store_zip=store["zip"], store_phone=store["phone"],
                 window_id=win["id"], window_date=win["date"], window_start=win["start_time"], window_end=win["end_time"], window_label=win["label"],
                 driver_id=driver["id"] if driver else None, driver_name=driver["name"] if driver else None, driver_phone=driver["phone"] if driver else None,
                 driver_vehicle=driver["vehicle"] if driver else None, status=status, subtotal_cents=sub, delivery_fee_cents=FEES["delivery"],
                 service_fee_cents=service, tax_cents=0, tip_cents=tip, total_cents=sub + FEES["delivery"] + service + tip,
                 commission_cents=round(sub * FEES["commission"]), driver_pay_cents=FEES["driver_base"] + tip, bags=max(1, math.ceil(qty / 10)),
                 address_line1=f"{100 + rnd.randint(0, 9799)} {pick(STREETS)}", address_line2="", city="Houston", state="TX",
                 zip=pick(["77036", "77042", "77072", "77099", "77074", "77057"]), phone=f"(713) 555-{2000 + rnd.randint(0, 6999)}",
                 notes="Please ring the doorbell." if rnd.random() < 0.2 else "", proof_note="Left at front door" if status == "delivered" else None,
                 payment_method=pick(["card", "card", "apple_pay", "google_pay"]), payment_status="refunded" if status == "refunded" else "paid",
                 created_at=iso(created), updated_at=events[-1]["at"], items=items, events=events, item_count=qty)
        orders.append(o)
        return o

    for w in range(8, 0, -1):
        d = sat - timedelta(days=7 * w)
        wins = add_windows(d)
        for _ in range(14 + (8 - w) * 4 + rnd.randint(0, 5)):
            created = datetime.combine(d, dtime(12), tzinfo=timezone.utc) - timedelta(days=1 + rnd.random() * 5)
            st = "refunded" if rnd.random() < 0.04 else "delivered"
            make_order(pick(customers), pick(active_stores), pick(wins), st, created, pick(drivers) if st == "delivered" else None)

    wins = add_windows(sat)
    for st, n in [("placed", 9), ("accepted", 6), ("packing", 5), ("ready", 6), ("ready_claimed", 3)]:
        for i in range(n):
            created = now - timedelta(days=rnd.random() * 2.5)
            store = active_stores[0] if i == 0 else pick(active_stores)
            cust = customers[0] if (i == 0 and st == "placed") else pick(customers)
            make_order(cust, store, pick(wins), "ready" if st == "ready_claimed" else st, created, drivers[0] if st == "ready_claimed" else None)
    make_order(customers[0], active_stores[1], wins[0], "packing", days_ago(1))

    job_status = {"placed": "pending", "accepted": "pending", "packing": "pending", "ready": "open", "picked_up": "picked_up",
                  "delivered": "delivered", "refunded": "cancelled", "cancelled": "cancelled"}
    for o in orders:
        jobs.append(dict(order_id=o["id"], number=o["number"], window_id=o["window_id"], window_date=o["window_date"], window_start=o["window_start"],
                         window_end=o["window_end"], store_id=o["store_id"], store_name=o["store_name"], store_address=o["store_address"],
                         store_city=o["store_city"], store_zip=o["store_zip"], customer_id=o["customer_id"], customer_name=o["customer_name"],
                         address_line1=o["address_line1"], address_line2=o["address_line2"], city=o["city"], state=o["state"], zip=o["zip"],
                         phone=o["phone"], notes=o["notes"], bags=o["bags"], item_count=o["item_count"], driver_pay_cents=o["driver_pay_cents"],
                         tip_cents=o["tip_cents"], status=job_status[o["status"]], driver_id=o["driver_id"], proof_note=o["proof_note"],
                         created_at=o["created_at"], updated_at=o["updated_at"], delivered_at=o["updated_at"] if o["status"] == "delivered" else None))

    return dict(users=users, stores=stores, products=products, windows=windows, orders=orders, jobs=jobs,
                customers=customers, drivers=drivers)
