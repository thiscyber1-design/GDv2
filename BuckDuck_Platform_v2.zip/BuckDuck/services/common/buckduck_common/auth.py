"""Authentication shared by every service.

The identity service signs a JWT. Every other service verifies it on its own with the shared
secret, so no service has to call identity on each request. Service-to-service calls use a
separate internal token that is never sent to browsers.
"""
from __future__ import annotations

import hashlib
import hmac
import secrets
import time

import jwt
from fastapi import Depends, Header, HTTPException

from .config import INTERNAL_TOKEN, JWT_SECRET

TOKEN_TTL_SECONDS = 7 * 24 * 3600
PBKDF2_ITERATIONS = 240_000


def hash_password(password: str, *, iterations: int = PBKDF2_ITERATIONS) -> str:
    salt = secrets.token_hex(16)
    dk = hashlib.pbkdf2_hmac("sha256", password.encode(), salt.encode(), iterations)
    return f"pbkdf2_sha256${iterations}${salt}${dk.hex()}"


def verify_password(password: str, stored: str) -> bool:
    try:
        algo, iters, salt, digest = stored.split("$")
        dk = hashlib.pbkdf2_hmac("sha256", password.encode(), salt.encode(), int(iters))
        return algo == "pbkdf2_sha256" and hmac.compare_digest(dk.hex(), digest)
    except Exception:  # noqa: BLE001
        return False


def create_token(user: dict) -> str:
    now = int(time.time())
    claims = {"sub": str(user["id"]), "role": user["role"], "name": user["name"], "email": user["email"],
              "iat": now, "exp": now + TOKEN_TTL_SECONDS}
    return jwt.encode(claims, JWT_SECRET, algorithm="HS256")


def decode_token(token: str) -> dict | None:
    try:
        c = jwt.decode(token, JWT_SECRET, algorithms=["HS256"])
        return {"id": int(c["sub"]), "role": c["role"], "name": c.get("name", ""), "email": c.get("email", "")}
    except Exception:  # noqa: BLE001
        return None


def optional_user(authorization: str | None = Header(default=None)) -> dict | None:
    if not authorization or not authorization.lower().startswith("bearer "):
        return None
    return decode_token(authorization[7:].strip())


def require(*roles: str):
    """FastAPI dependency: the caller must be signed in with one of `roles`."""
    def dep(user: dict | None = Depends(optional_user)) -> dict:
        if not user:
            raise HTTPException(401, "Please sign in to continue")
        if roles and user["role"] not in roles:
            raise HTTPException(403, "You do not have access to this area")
        return user
    return dep


def internal_only(x_internal_token: str | None = Header(default=None)) -> None:
    if not x_internal_token or not hmac.compare_digest(x_internal_token, INTERNAL_TOKEN):
        raise HTTPException(403, "Internal endpoint")
