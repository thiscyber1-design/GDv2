"""Thin, portable database layer (SQLite for local dev, PostgreSQL in production)."""
from __future__ import annotations

from contextlib import contextmanager
from decimal import Decimal
from typing import Any, Iterator

from sqlalchemy import MetaData, create_engine, event, text
from sqlalchemy.engine import Connection


def _norm(v: Any) -> Any:
    if isinstance(v, Decimal):
        return int(v) if v == v.to_integral_value() else float(v)
    return v


def row(r) -> dict:
    return {k: _norm(v) for k, v in r._mapping.items()}


class Database:
    def __init__(self, url: str, metadata: MetaData):
        self.url = url
        self.metadata = metadata
        self.is_sqlite = url.startswith("sqlite")
        kw: dict = {"future": True, "pool_pre_ping": True}
        if self.is_sqlite:
            kw["connect_args"] = {"check_same_thread": False, "timeout": 15}
        else:
            kw.update(pool_size=10, max_overflow=10)
        self.engine = create_engine(url, **kw)
        if self.is_sqlite:
            @event.listens_for(self.engine, "connect")
            def _pragmas(dbapi_conn, _):  # noqa: ANN001
                cur = dbapi_conn.cursor()
                cur.execute("PRAGMA journal_mode=WAL")
                cur.execute("PRAGMA busy_timeout=15000")
                cur.execute("PRAGMA foreign_keys=ON")
                cur.close()

    def create_all(self) -> None:
        self.metadata.create_all(self.engine)

    @contextmanager
    def tx(self) -> Iterator["Tx"]:
        with self.engine.begin() as conn:
            yield Tx(conn)

    # convenience for single statements outside an explicit transaction
    def all(self, sql: str, **p) -> list[dict]:
        with self.tx() as t:
            return t.all(sql, **p)

    def one(self, sql: str, **p) -> dict | None:
        with self.tx() as t:
            return t.one(sql, **p)

    def scalar(self, sql: str, **p):
        with self.tx() as t:
            return t.scalar(sql, **p)

    def fix_sequences(self, tables: list[str]) -> None:
        """After inserting rows with explicit ids, move PostgreSQL sequences past them."""
        if self.is_sqlite:
            return
        with self.tx() as t:
            for tbl in tables:
                t.conn.execute(text(
                    f"SELECT setval(pg_get_serial_sequence('{tbl}', 'id'), COALESCE((SELECT MAX(id) FROM {tbl}), 0) + 1, false)"))


class Tx:
    def __init__(self, conn: Connection):
        self.conn = conn

    def all(self, sql: str, **p) -> list[dict]:
        return [row(r) for r in self.conn.execute(text(sql), p)]

    def one(self, sql: str, **p) -> dict | None:
        r = self.conn.execute(text(sql), p).first()
        return row(r) if r is not None else None

    def scalar(self, sql: str, **p):
        return _norm(self.conn.execute(text(sql), p).scalar())

    def run(self, sql: str, **p) -> int:
        """Execute a write; returns affected row count."""
        return self.conn.execute(text(sql), p).rowcount

    def insert(self, table: str, data: dict) -> int:
        cols = ", ".join(data)
        vals = ", ".join(f":{k}" for k in data)
        r = self.conn.execute(text(f"INSERT INTO {table} ({cols}) VALUES ({vals}) RETURNING id"), data).first()
        return int(r[0])

    def insert_many(self, table: str, rows: list[dict]) -> None:
        if not rows:
            return
        cols = list(rows[0])
        self.conn.execute(text(f"INSERT INTO {table} ({', '.join(cols)}) VALUES ({', '.join(':' + c for c in cols)})"), rows)
