"""Transactional outbox: reliable events between services.

A service writes an event into its own `outbox` table in the same transaction as the business
change. After commit the event is delivered to the target service's internal endpoint. If the target
is down, a background thread keeps retrying with backoff, so no event is lost and neither service
has to be online at the same moment. Receivers are idempotent, so duplicate delivery is safe.
"""
from __future__ import annotations

import json
import logging
import threading
import time
from datetime import datetime, timedelta, timezone

import httpx
from sqlalchemy import Column, Integer, MetaData, String, Table, Text

from .config import INTERNAL_TOKEN, SERVICE_URLS

log = logging.getLogger("buckduck.outbox")


def outbox_table(metadata: MetaData) -> Table:
    return Table(
        "outbox", metadata,
        Column("id", Integer, primary_key=True, autoincrement=True),
        Column("target", String(30), nullable=False),
        Column("path", String(200), nullable=False),
        Column("payload", Text, nullable=False),
        Column("attempts", Integer, nullable=False, default=0),
        Column("next_attempt_at", String(40), nullable=False),
        Column("delivered_at", String(40)),
        Column("last_error", Text),
        Column("created_at", String(40), nullable=False),
    )


def _now() -> datetime:
    return datetime.now(timezone.utc)


class Outbox:
    def __init__(self, db):
        self.db = db
        self._lock = threading.Lock()
        self._client = httpx.Client(timeout=httpx.Timeout(4.0, connect=1.5), headers={"X-Internal-Token": INTERNAL_TOKEN})
        self._started = False

    def enqueue(self, tx, target: str, path: str, payload: dict) -> None:
        n = _now().isoformat()
        tx.insert("outbox", {"target": target, "path": path, "payload": json.dumps(payload), "attempts": 0,
                             "next_attempt_at": n, "created_at": n})

    def flush(self) -> None:
        """Deliver every due event now (called right after a request commits)."""
        if not self._lock.acquire(timeout=10):
            return
        try:
            due = self.db.all("SELECT * FROM outbox WHERE delivered_at IS NULL AND next_attempt_at <= :n ORDER BY id LIMIT 200",
                              n=_now().isoformat())
            blocked: set[str] = set()   # keep per-target ordering: stop at the first failure for a target
            for ev in due:
                if ev["target"] in blocked:
                    continue
                try:
                    r = self._client.post(SERVICE_URLS[ev["target"]] + ev["path"], json=json.loads(ev["payload"]))
                    if r.status_code >= 500:
                        raise RuntimeError(f"HTTP {r.status_code}")
                    if r.status_code >= 400:   # permanent rejection: record and move on
                        log.error("outbox event %s rejected by %s: %s", ev["id"], ev["target"], r.text[:300])
                    self.db.one("UPDATE outbox SET delivered_at=:d, attempts=attempts+1, last_error=:e WHERE id=:id RETURNING id",
                                d=_now().isoformat(), e=None if r.status_code < 400 else r.text[:500], id=ev["id"])
                except Exception as e:  # noqa: BLE001
                    blocked.add(ev["target"])
                    attempts = ev["attempts"] + 1
                    delay = min(300, 2 ** min(attempts, 8))
                    self.db.one("UPDATE outbox SET attempts=:a, next_attempt_at=:n, last_error=:e WHERE id=:id RETURNING id",
                                a=attempts, n=(_now() + timedelta(seconds=delay)).isoformat(), e=str(e)[:500], id=ev["id"])
        finally:
            self._lock.release()

    def start(self, interval: float = 3.0) -> None:
        if self._started:
            return
        self._started = True

        def loop():
            while True:
                time.sleep(interval)
                try:
                    self.flush()
                except Exception as e:  # noqa: BLE001
                    log.warning("outbox loop error: %s", e)
        threading.Thread(target=loop, daemon=True, name="outbox").start()

    def pending(self) -> int:
        return int(self.db.scalar("SELECT COUNT(*) FROM outbox WHERE delivered_at IS NULL") or 0)
