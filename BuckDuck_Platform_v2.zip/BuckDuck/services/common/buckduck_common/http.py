"""Service-to-service HTTP calls.

`call()` raises ServiceUnavailable when the other service is down, so the caller can return a clear
503. `try_call()` returns a fallback instead, so a service keeps working (with less detail) when a
dependency is offline. This is what lets each service run independently.
"""
from __future__ import annotations

import logging

import httpx
from fastapi import HTTPException

from .config import INTERNAL_TOKEN, SERVICE_URLS

log = logging.getLogger("buckduck.http")
_client = httpx.Client(timeout=httpx.Timeout(5.0, connect=2.0), headers={"X-Internal-Token": INTERNAL_TOKEN})

FRIENDLY = {
    "identity": "Accounts are temporarily unavailable",
    "catalog": "Store listings are temporarily unavailable",
    "orders": "Ordering is temporarily unavailable",
    "payments": "Payments are temporarily unavailable",
    "delivery": "Delivery scheduling is temporarily unavailable",
}


class ServiceUnavailable(HTTPException):
    def __init__(self, service: str):
        super().__init__(503, f"{FRIENDLY.get(service, 'A service is unavailable')}. Please try again in a moment.")
        self.service = service


def call(service: str, method: str, path: str, *, json=None, params=None, timeout: float | None = None):
    url = SERVICE_URLS[service] + path
    try:
        r = _client.request(method, url, json=json, params=params, timeout=timeout or 5.0)
    except httpx.HTTPError as e:
        log.warning("%s %s unreachable: %s", service, path, e)
        raise ServiceUnavailable(service) from e
    if r.status_code >= 500:
        log.warning("%s %s returned %s", service, path, r.status_code)
        raise ServiceUnavailable(service)
    data = r.json() if r.content else {}
    if r.status_code >= 400:
        raise HTTPException(r.status_code, data.get("error") or data.get("detail") or "Request failed")
    return data


def try_call(service: str, method: str, path: str, fallback=None, **kw):
    try:
        return call(service, method, path, **kw)
    except HTTPException:
        return fallback
