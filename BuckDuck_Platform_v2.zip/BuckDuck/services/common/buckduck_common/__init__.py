"""Shared building blocks for BuckDuck microservices.

Every service is deployed and runs on its own, with its own database. This package holds only
infrastructure code (config, DB access, auth, service-to-service HTTP, the event outbox, seed data).
It holds no business logic, so no service depends on another's internals.
"""
