import os
from pathlib import Path


def _load_env_file() -> None:
    """Load a .env file from the repository root if present (existing env vars win)."""
    for parent in Path(__file__).resolve().parents:
        f = parent / ".env"
        if f.is_file():
            for line in f.read_text().splitlines():
                line = line.strip()
                if not line or line.startswith("#") or "=" not in line:
                    continue
                k, v = line.split("=", 1)
                os.environ.setdefault(k.strip(), v.strip().strip('"').strip("'"))
            return


_load_env_file()


def env(key: str, default: str | None = None) -> str | None:
    v = os.environ.get(key)
    return v if v not in (None, "") else default


ENVIRONMENT = env("ENVIRONMENT", "development")
IS_PROD = ENVIRONMENT == "production"
DEMO_MODE = env("DEMO_MODE", "true").lower() == "true"
JWT_SECRET = env("JWT_SECRET") or ("" if IS_PROD else "dev-only-jwt-secret-change-me")
INTERNAL_TOKEN = env("INTERNAL_TOKEN") or ("" if IS_PROD else "dev-only-internal-token")
if IS_PROD and (not JWT_SECRET or not INTERNAL_TOKEN):
    raise RuntimeError("JWT_SECRET and INTERNAL_TOKEN must be set in production")

DATA_DIR = Path(env("DATA_DIR", str(Path.cwd() / "data")))
DATA_DIR.mkdir(parents=True, exist_ok=True)

# Where each service lives. In Docker Compose these are the container names.
def _svc_url(v: str) -> str:
    # Hosts such as Render provide "host:port"; accept that as well as full URLs.
    return v if v.startswith(("http://", "https://")) else f"http://{v}"


SERVICE_URLS = {
    "identity": env("IDENTITY_URL", "http://127.0.0.1:8001"),
    "catalog": env("CATALOG_URL", "http://127.0.0.1:8002"),
    "orders": env("ORDERS_URL", "http://127.0.0.1:8003"),
    "payments": env("PAYMENTS_URL", "http://127.0.0.1:8004"),
    "delivery": env("DELIVERY_URL", "http://127.0.0.1:8005"),
}
SERVICE_URLS = {k: _svc_url(v) for k, v in SERVICE_URLS.items()}


def database_url(service: str) -> str:
    """Each service has its OWN database. Default: a SQLite file per service."""
    url = env("DATABASE_URL") or env(f"{service.upper()}_DATABASE_URL")
    if url:
        if url.startswith("postgres://"):
            url = "postgresql+psycopg://" + url[len("postgres://"):]
        elif url.startswith("postgresql://"):
            url = "postgresql+psycopg://" + url[len("postgresql://"):]
        return url
    return f"sqlite:///{DATA_DIR / (service + '.db')}"
