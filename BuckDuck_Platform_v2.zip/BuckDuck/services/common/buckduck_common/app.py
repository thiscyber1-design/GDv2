"""Standard FastAPI setup shared by all services: errors as {"error": ...}, health, logging."""
from __future__ import annotations

import logging

from fastapi import FastAPI, HTTPException, Request
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.gzip import GZipMiddleware
from fastapi.responses import JSONResponse
from starlette.exceptions import HTTPException as StarletteHTTPException

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(levelname)s %(message)s")
logging.getLogger("httpx").setLevel(logging.WARNING)


def create_app(name: str, description: str, *, db=None, outbox=None) -> FastAPI:
    app = FastAPI(title=f"BuckDuck {name} service", description=description, version="2.0.0",
                  docs_url="/docs", redoc_url=None, openapi_url="/openapi.json")
    app.add_middleware(GZipMiddleware, minimum_size=800)
    log = logging.getLogger(f"buckduck.{name}")

    @app.exception_handler(StarletteHTTPException)
    async def http_err(_: Request, exc: StarletteHTTPException):
        return JSONResponse({"error": exc.detail}, status_code=exc.status_code, headers=getattr(exc, "headers", None))

    @app.exception_handler(RequestValidationError)
    async def validation_err(_: Request, exc: RequestValidationError):
        first = exc.errors()[0] if exc.errors() else {}
        field = ".".join(str(x) for x in first.get("loc", [])[1:]) or "request"
        return JSONResponse({"error": f"Invalid {field}: {first.get('msg', 'check your input')}"}, status_code=400)

    @app.exception_handler(Exception)
    async def unhandled(_: Request, exc: Exception):
        log.exception("Unhandled error: %s", exc)
        return JSONResponse({"error": "Something went wrong. Please try again."}, status_code=500)

    @app.get("/healthz", tags=["ops"])
    def healthz():
        out = {"ok": True, "service": name}
        if db is not None:
            try:
                db.scalar("SELECT 1")
                out["database"] = "ok"
            except Exception:  # noqa: BLE001
                out.update(ok=False, database="down")
        if outbox is not None:
            try:
                out["outbox_pending"] = outbox.pending()
            except Exception:  # noqa: BLE001
                pass
        return JSONResponse(out, status_code=200 if out["ok"] else 503)

    return app
