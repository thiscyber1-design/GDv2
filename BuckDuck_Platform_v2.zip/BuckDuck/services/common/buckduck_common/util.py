from __future__ import annotations

import base64
import re
import secrets
from datetime import date, datetime, timedelta, timezone
from pathlib import Path

from fastapi import HTTPException

STATUS_LABEL = {
    "pending_payment": "Awaiting payment", "placed": "Order placed", "accepted": "Accepted by store",
    "packing": "Packing in BuckDuck bags", "ready": "Ready for pickup", "picked_up": "Out for delivery",
    "delivered": "Delivered", "cancelled": "Cancelled", "refunded": "Refunded",
}


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def today() -> date:
    return datetime.now().date()


def ymd(d: date) -> str:
    return d.isoformat()


def slugify(s: str) -> str:
    return (re.sub(r"[^a-z0-9]+", "-", str(s).lower()).strip("-")[:60]) or "store"


def s(v, max_len: int = 200) -> str:
    return "" if v is None else str(v).strip()[:max_len]


def req(v, name: str, max_len: int = 200) -> str:
    out = s(v, max_len)
    if not out:
        raise HTTPException(400, f"{name} is required")
    return out


def to_int(v, default: int = 0) -> int:
    try:
        return int(float(v))
    except (TypeError, ValueError):
        return default


def fmt_time(t: str) -> str:
    h, m = (int(x) for x in t.split(":"))
    ap = "PM" if h >= 12 else "AM"
    hh = h % 12 or 12
    return f"{hh}:{m:02d} {ap}" if m else f"{hh} {ap}"


def window_label(start: str, end: str) -> str:
    part = "Morning" if int(start.split(":")[0]) < 12 else "Afternoon"
    return f"{part} · {fmt_time(start)} – {fmt_time(end)}"


def next_weekday(d: date, weekday_js: int) -> date:
    """weekday_js uses JavaScript numbering: 0=Sunday … 6=Saturday."""
    py = (weekday_js - 1) % 7
    return d + timedelta(days=(py - d.weekday()) % 7)


def save_image(data_url: str, media_dir: Path, max_bytes: int = 4 * 1024 * 1024) -> str:
    m = re.match(r"^data:image/(png|jpe?g|webp|gif);base64,(.+)$", str(data_url or ""), re.S)
    if not m:
        raise HTTPException(400, "Unsupported image. Use PNG, JPG, WEBP or GIF.")
    raw = base64.b64decode(m.group(2))
    if len(raw) > max_bytes:
        raise HTTPException(400, "Image too large (max 4 MB)")
    media_dir.mkdir(parents=True, exist_ok=True)
    ext = "jpg" if m.group(1) in ("jpeg", "jpg") else m.group(1)
    name = f"{secrets.token_hex(12)}.{ext}"
    (media_dir / name).write_bytes(raw)
    return f"/media/{name}"
