/* StoreFront USA public pages: progressive enhancement only. Every page is fully readable without JS. */
(() => {
  'use strict';
  const KEY = 'bd_cart';
  const read = (k, d) => { try { const v = localStorage.getItem(k); return v ? JSON.parse(v) : d; } catch { return d; } };
  const write = (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch { /* storage unavailable */ } };
  let cart = read(KEY, []);
  const qtyOf = (id) => (cart.find((i) => i.product_id === id) || {}).qty || 0;

  function toast(msg) {
    let box = document.querySelector('.toasts');
    if (!box) { box = document.createElement('div'); box.className = 'toasts'; box.setAttribute('role', 'status'); document.body.appendChild(box); }
    while (box.children.length >= 2) box.firstChild.remove();
    const t = document.createElement('div'); t.className = 'toast'; t.textContent = msg; box.appendChild(t);
    setTimeout(() => t.remove(), 3000);
  }

  function setQty(p, q) {
    const max = p.stock ?? 99;
    if (q > max) { toast(`Only ${max} available`); q = max; }
    const i = cart.findIndex((x) => x.product_id === p.id);
    if (q <= 0) { if (i >= 0) cart.splice(i, 1); }
    else if (i >= 0) cart[i].qty = q;
    else cart.push({ product_id: p.id, qty: q, name: p.name, price_cents: p.price_cents, emoji: p.emoji, image_url: p.image_url, unit: p.unit,
      stock: p.stock, store_id: p.store_id, store_name: p.store_name, store_slug: p.store_slug });
    write(KEY, cart);
    render();
  }

  function slot(el) {
    const p = JSON.parse(el.dataset.product);
    const q = qtyOf(p.id);
    const big = el.classList.contains('pdp-add');
    if (!q) {
      el.innerHTML = `<button class="btn ${big ? 'btn-gold btn-lg' : 'btn-primary btn-sm add-btn'} btn-block" type="button" data-inc ${p.stock < 1 ? 'disabled' : ''}>${p.stock < 1 ? 'Sold out' : (big ? 'Add to cart' : '+ Add')}</button>`;
    } else {
      el.innerHTML = `<div class="stepper${big ? ' stepper-lg' : ''}"><button type="button" data-dec aria-label="Remove one ${p.name}">−</button><span aria-live="polite">${q} in cart</span><button type="button" data-inc aria-label="Add one ${p.name}">+</button></div>`;
    }
  }

  function render() {
    document.querySelectorAll('[data-cart-ctl]').forEach(slot);
    const n = cart.reduce((a, i) => a + i.qty, 0);
    document.querySelectorAll('[data-cart-count]').forEach((el) => { el.textContent = n; el.classList.toggle('hidden', !n); });
  }

  document.addEventListener('click', (e) => {
    const b = e.target.closest('[data-inc],[data-dec]');
    if (b) {
      const el = b.closest('[data-cart-ctl]'); if (!el) return;
      const p = JSON.parse(el.dataset.product);
      const before = qtyOf(p.id);
      setQty(p, before + (b.hasAttribute('data-inc') ? 1 : -1));
      if (!before) toast(`Added ${p.name}`);
      return;
    }
    const f = e.target.closest('[data-filter-cat]');
    if (f) {
      const cat = f.dataset.filterCat;
      document.querySelectorAll('[data-filter-cat]').forEach((c) => c.classList.toggle('active', c === f));
      document.querySelectorAll('[data-cat-section]').forEach((s) => s.classList.toggle('hidden', cat !== 'All' && s.dataset.catSection !== cat));
    }
  });

  // Keep the cart badge in sync across tabs (and with the app at /app/).
  window.addEventListener('storage', (e) => { if (e.key === KEY) { cart = read(KEY, []); render(); } });

  // Signed-in visitors see "Account" (or their dashboard) instead of "Sign in".
  const token = read('bd_token', null);
  if (token) {
    try {
      const claims = JSON.parse(atob(token.split('.')[1].replace(/-/g, '+').replace(/_/g, '/')));
      const dest = { merchant: ['#/merchant', 'My store'], driver: ['#/driver', 'Driver app'], admin: ['#/admin', 'Admin'] }[claims.role] || ['#/account', 'Account'];
      if (claims.exp * 1000 > Date.now()) document.querySelectorAll('[data-account-link]').forEach((a) => { a.href = '/app/' + dest[0]; a.textContent = dest[1]; });
    } catch { /* ignore malformed token */ }
  }
  render();
  if ('serviceWorker' in navigator && location.protocol === 'https:') navigator.serviceWorker.register('/sw.js').catch(() => {});
})();
