"""Web service — the StoreFront USA website (server-rendered, SEO-friendly) and the API gateway.

* Public pages (home, stores, categories, store pages, product pages, guides) are rendered on the
  server with real URLs, titles, meta descriptions, canonical links, Open Graph tags, JSON-LD
  structured data, a live sitemap.xml and robots.txt — so search engines can index every store and product.
* Signed-in areas (cart, checkout, account, merchant portal, driver app, admin console) are a
  single-page app at /app/ and are marked noindex.
* /api/* is routed to the right microservice. The browser only ever talks to this service.
Owns no database. If a back-end service is down, pages still render with a clear message.
"""
from __future__ import annotations

import json
import re
import time
from datetime import date, datetime
from pathlib import Path
from urllib.parse import quote_plus

import httpx
from fastapi import Request
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse, PlainTextResponse, RedirectResponse, Response
from fastapi.staticfiles import StaticFiles
from jinja2 import Environment, FileSystemLoader, select_autoescape

from buckduck_common.app import create_app
from buckduck_common.config import DEMO_MODE, INTERNAL_TOKEN, SERVICE_URLS, env
from buckduck_common.util import fmt_time, slugify

HERE = Path(__file__).resolve().parent
app = create_app("web", "StoreFront USA website (server-rendered) and API gateway.")
app.mount("/static", StaticFiles(directory=HERE / "static"), name="static")
jinja = Environment(loader=FileSystemLoader(HERE / "templates"), autoescape=select_autoescape(["html", "xml"]), trim_blocks=True, lstrip_blocks=True)
client = httpx.AsyncClient(timeout=httpx.Timeout(10.0, connect=2.0))
SITE = {"name": "BuckDuck", "marketplace": "StoreFront USA", "tagline": "Your neighborhood grocers. Delivered every Saturday.",
        "city": env("LAUNCH_CITY", "Houston, TX"), "demo": DEMO_MODE}
DAYS = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"]

# ------------------------------------------------------------------ API gateway
ROUTES = [
    ("/api/auth/", "identity"), ("/api/me", "identity"), ("/api/admin/users", "identity"),
    ("/api/stores", "catalog"), ("/api/products", "catalog"), ("/api/search", "catalog"), ("/api/catalog/", "catalog"),
    ("/api/merchant/store", "catalog"), ("/api/merchant/products", "catalog"), ("/api/admin/stores", "catalog"),
    ("/api/windows", "delivery"), ("/api/driver/", "delivery"), ("/api/admin/windows", "delivery"), ("/api/admin/drivers", "delivery"),
    ("/api/payments/", "payments"), ("/api/merchant/stripe/", "payments"), ("/api/stripe/", "payments"),
    ("/api/checkout", "orders"), ("/api/orders", "orders"), ("/api/merchant/", "orders"), ("/api/admin/", "orders"),
]
FORWARD_HEADERS = ("authorization", "content-type", "stripe-signature", "accept")
SETTINGS_OWNERS = {"catalog": ["default_commission_rate"],
                   "delivery": ["delivery_weekday", "default_slots", "windows_weeks_ahead", "default_window_capacity", "order_cutoff_hours"],
                   "orders": ["delivery_fee_cents", "service_fee_rate", "service_fee_min_cents", "tax_rate", "driver_base_pay_cents",
                              "min_order_cents", "bag_item_capacity", "service_zips"]}


def service_for(path: str) -> str | None:
    """Match whole path segments only, so /api/me never captures /api/merchant/..."""
    for prefix, svc in ROUTES:
        base = prefix.rstrip("/")
        if path == base or path.startswith(base + "/"):
            return svc
    return None


def unavailable(svc: str) -> JSONResponse:
    names = {"identity": "Accounts", "catalog": "Store listings", "orders": "Ordering", "payments": "Payments", "delivery": "Delivery scheduling"}
    return JSONResponse({"error": f"{names.get(svc, 'This feature')} is temporarily unavailable. Please try again in a moment."}, status_code=503)


async def internal_get(svc: str, path: str, params: dict | None = None, timeout: float = 4.0):
    r = await client.get(SERVICE_URLS[svc] + path, params=params, headers={"X-Internal-Token": INTERNAL_TOKEN}, timeout=timeout)
    r.raise_for_status()
    return r.json()


@app.get("/api/config", tags=["gateway"])
async def api_config():
    """Composite: fees (orders) + next window (delivery) + payment mode (payments). Missing parts fall back to defaults."""
    out = {"brand": "BuckDuck", "marketplace": "StoreFront USA", "demo": DEMO_MODE, "delivery_weekday": 6, "delivery_fee_cents": 599,
           "service_fee_rate": 0.05, "min_order_cents": 1500, "next_window": None, "payments": {"mode": "demo", "publishableKey": None, "country": "US", "currency": "usd"}}
    for svc, path, fn in (("orders", "/internal/config", lambda d: out.update({k: d[k] for k in ("delivery_fee_cents", "service_fee_rate", "min_order_cents")})),
                          ("delivery", "/internal/config", lambda d: out.update(delivery_weekday=d["delivery_weekday"], next_window=d["next_window"])),
                          ("payments", "/api/payments/config", lambda d: out.update(payments=d))):
        try:
            fn(await internal_get(svc, path))
        except Exception:  # noqa: BLE001
            pass
    return out


@app.api_route("/api/admin/settings", methods=["GET", "PUT"], tags=["gateway"])
async def admin_settings(request: Request):
    """Composite: each setting lives in the service that uses it."""
    hdr = {"authorization": request.headers.get("authorization", "")}
    body = await request.json() if request.method == "PUT" else None
    merged = {}
    for svc, keys in SETTINGS_OWNERS.items():
        try:
            if request.method == "PUT":
                part = {k: v for k, v in (body or {}).items() if k in keys}
                r = await client.put(SERVICE_URLS[svc] + "/api/admin/settings", json=part, headers=hdr)
            else:
                r = await client.get(SERVICE_URLS[svc] + "/api/admin/settings", headers=hdr)
        except httpx.HTTPError:
            return unavailable(svc)
        if r.status_code >= 400:
            return JSONResponse(r.json(), status_code=r.status_code)
        merged.update(r.json()["settings"])
    return {"settings": merged}


@app.api_route("/api/{rest:path}", methods=["GET", "POST", "PUT", "DELETE", "PATCH"], include_in_schema=False)
async def gateway(rest: str, request: Request):
    path = "/api/" + rest
    svc = service_for(path)
    if not svc:
        return JSONResponse({"error": "Not found"}, status_code=404)
    headers = {k: v for k, v in request.headers.items() if k.lower() in FORWARD_HEADERS}
    headers["x-forwarded-for"] = request.headers.get("x-forwarded-for") or (request.client.host if request.client else "")
    headers["x-forwarded-proto"] = request.headers.get("x-forwarded-proto") or request.url.scheme
    try:
        r = await client.request(request.method, SERVICE_URLS[svc] + path, params=request.query_params, content=await request.body(), headers=headers)
    except httpx.HTTPError:
        return unavailable(svc)
    return Response(r.content, status_code=r.status_code, media_type=r.headers.get("content-type", "application/json"),
                    headers={"Cache-Control": "no-store"})


@app.get("/media/{name}", include_in_schema=False)
async def media(name: str):
    try:
        r = await client.get(f"{SERVICE_URLS['catalog']}/media/{name}")
    except httpx.HTTPError:
        return Response(status_code=503)
    return Response(r.content, status_code=r.status_code, media_type=r.headers.get("content-type"),
                    headers={"Cache-Control": r.headers.get("cache-control", "public, max-age=86400")})


# ------------------------------------------------------------------ cached reads for pages
_cache: dict[str, tuple[float, object]] = {}


async def cached(key: str, svc: str, path: str, ttl: float = 30.0, params: dict | None = None):
    hit = _cache.get(key)
    if hit and time.time() - hit[0] < ttl:
        return hit[1]
    try:
        data = await internal_get(svc, path, params)
    except httpx.HTTPStatusError as e:
        if e.response.status_code == 404:
            return None
        if hit:
            return hit[1]   # serve stale content rather than fail
        raise
    except httpx.HTTPError:
        if hit:
            return hit[1]
        raise
    _cache[key] = (time.time(), data)
    return data


# ------------------------------------------------------------------ SEO helpers
def base_url(request: Request) -> str:
    return (env("PUBLIC_BASE_URL") or str(request.base_url)).rstrip("/")


def money(c) -> str:
    return f"${(c or 0) / 100:,.2f}"


def product_path(p: dict) -> str:
    return f"/products/{p['id']}-{slugify(p['name'])}"


def category_path(c: str) -> str:
    return f"/categories/{slugify(c)}"


def ld(*objs) -> str:
    """JSON-LD script content, safe to embed."""
    out = []
    for o in objs:
        out.append(json.dumps(o, ensure_ascii=False).replace("</", "<\\/"))
    return out


def breadcrumbs(request: Request, items: list[tuple[str, str]]) -> dict:
    b = base_url(request)
    return {"@context": "https://schema.org", "@type": "BreadcrumbList",
            "itemListElement": [{"@type": "ListItem", "position": i + 1, "name": n, "item": b + u} for i, (n, u) in enumerate(items)]}


def window_text(w: dict | None) -> str:
    if not w:
        return ""
    d = date.fromisoformat(w["date"])
    return f"{d.strftime('%A, %B')} {d.day} · {fmt_time(w['start_time'])}–{fmt_time(w['end_time'])}"


def fmt_cutoff(iso: str) -> str:
    d = datetime.fromisoformat(iso)
    return f"{d.strftime('%a %b')} {d.day}, {fmt_time(d.strftime('%H:%M'))}"


jinja.globals.update(fmt_cutoff=fmt_cutoff, money=money, product_path=product_path, category_path=category_path, slugify=slugify, site=SITE, quote_plus=quote_plus,
                     fmt_time=fmt_time, window_text=window_text, year=datetime.now().year, DAYS=DAYS)
jinja.filters["json"] = lambda v: json.dumps(v, ensure_ascii=False).replace("</", "<\\/")


def page(request: Request, template: str, *, title: str, description: str, path: str, status: int = 200, noindex: bool = False,
         jsonld: list | None = None, og_image: str | None = None, **ctx) -> HTMLResponse:
    b = base_url(request)
    html = jinja.get_template(template).render(
        request=request, title=title, description=description[:300], canonical=b + path, base=b, noindex=noindex, path=path,
        jsonld=ld(*(jsonld or [])), og_image=og_image or f"{b}/static/og-image.png", **ctx)
    return HTMLResponse(html, status_code=status, headers={"Cache-Control": "public, max-age=60" if status == 200 and not noindex else "no-store"})


def outage(request: Request, path: str, what: str = "Store listings") -> HTMLResponse:
    return page(request, "message.html", title="We'll be right back · BuckDuck", description="BuckDuck is briefly unavailable.", path=path, status=503,
                noindex=True, heading="We'll be right back", message=f"{what} are temporarily unavailable. Please refresh in a minute.")


def not_found(request: Request) -> HTMLResponse:
    return page(request, "message.html", title="Page not found · BuckDuck", description="This page does not exist.", path=request.url.path,
                status=404, noindex=True, heading="We couldn't find that page", message="It may have moved, or the store may no longer be listed.")


async def next_windows() -> list[dict]:
    try:
        ws = (await cached("windows", "delivery", "/api/windows", ttl=60)) or {}
    except httpx.HTTPError:
        return []
    ws = ws.get("windows", [])
    first = next((w for w in ws if w["open"]), ws[0] if ws else None)
    return [w for w in ws if first and w["date"] == first["date"]]


ORG = lambda b: {"@context": "https://schema.org", "@type": "Organization", "name": "BuckDuck", "alternateName": "StoreFront USA",  # noqa: E731
                 "url": b + "/", "logo": b + "/static/icons/icon-512.png", "slogan": "One cart. Many stores. Delivered Saturday."}


def store_ld(b: str, st: dict) -> dict:
    out = {"@context": "https://schema.org", "@type": "GroceryStore", "@id": f"{b}/stores/{st['slug']}#store", "name": st["name"],
           "description": st.get("description") or st.get("tagline") or "", "url": f"{b}/stores/{st['slug']}",
           "address": {"@type": "PostalAddress", "streetAddress": st.get("address") or "", "addressLocality": st.get("city") or "",
                       "addressRegion": st.get("state") or "", "postalCode": st.get("zip") or "", "addressCountry": "US"}}
    if st.get("phone"):
        out["telephone"] = st["phone"]
    out["image"] = b + st["logo_url"] if st.get("logo_url") else b + "/static/og-image.png"
    return out


def offer(b: str, p: dict, st: dict) -> dict:
    return {"@type": "Offer", "price": f"{p['price_cents'] / 100:.2f}", "priceCurrency": "USD", "url": b + product_path(p),
            "availability": "https://schema.org/InStock" if p.get("stock", 0) > 0 else "https://schema.org/OutOfStock",
            "seller": {"@type": "GroceryStore", "name": st["name"], "@id": f"{b}/stores/{st['slug']}#store"}}


# ------------------------------------------------------------------ pages
@app.get("/", response_class=HTMLResponse, include_in_schema=False)
async def home(request: Request):
    b = base_url(request)
    try:
        data = await cached("stores:", "catalog", "/api/stores")
    except httpx.HTTPError:
        return outage(request, "/")
    wins = await next_windows()
    site_ld = {"@context": "https://schema.org", "@type": "WebSite", "name": "StoreFront USA by BuckDuck", "url": b + "/",
               "potentialAction": {"@type": "SearchAction", "target": {"@type": "EntryPoint", "urlTemplate": b + "/search?q={search_term_string}"},
                                   "query-input": "required name=search_term_string"}}
    return page(request, "home.html", title="BuckDuck · Saturday Grocery Delivery from Local African & Caribbean Stores",
                description=f"Shop African, Caribbean and local grocery stores in {SITE['city']} in one cart. Packed in sealed BuckDuck bags and delivered every Saturday in the window you choose.",
                path="/", jsonld=[ORG(b), site_ld], stores=data["stores"], categories=data["categories"], windows=wins)


@app.get("/stores", response_class=HTMLResponse, include_in_schema=False)
async def stores(request: Request, category: str = ""):
    if category:
        return RedirectResponse(category_path(category), status_code=301)
    b = base_url(request)
    try:
        data = await cached("stores:", "catalog", "/api/stores")
    except httpx.HTTPError:
        return outage(request, "/stores")
    lst = {"@context": "https://schema.org", "@type": "ItemList", "name": "Grocery stores on StoreFront USA",
           "itemListElement": [{"@type": "ListItem", "position": i + 1, "url": f"{b}/stores/{s['slug']}", "name": s["name"]} for i, s in enumerate(data["stores"])]}
    return page(request, "stores.html", title=f"Grocery Stores Delivering in {SITE['city']} · StoreFront USA",
                description=f"Browse {len(data['stores'])} local African, Caribbean, halal, produce and bakery stores. Order from several stores in one cart and get it all delivered Saturday.",
                path="/stores", jsonld=[lst, breadcrumbs(request, [("Home", "/"), ("Stores", "/stores")])],
                stores=data["stores"], categories=data["categories"], current_category=None, heading="All stores")


@app.get("/categories/{slug}", response_class=HTMLResponse, include_in_schema=False)
async def category(request: Request, slug: str):
    try:
        data = await cached("stores:", "catalog", "/api/stores")
    except httpx.HTTPError:
        return outage(request, f"/categories/{slug}")
    cat = next((c for c in data["categories"] if slugify(c) == slug), None)
    if not cat:
        return not_found(request)
    lst = [s for s in data["stores"] if s["category"] == cat]
    return page(request, "stores.html", title=f"{cat} Delivered Saturday in {SITE['city']} · StoreFront USA",
                description=f"Order {cat.lower()} from {len(lst)} local store{'s' if len(lst) != 1 else ''} on StoreFront USA. Packed in BuckDuck bags and delivered in your Saturday window.",
                path=f"/categories/{slug}", jsonld=[breadcrumbs(request, [("Home", "/"), ("Stores", "/stores"), (cat, f"/categories/{slug}")])],
                stores=lst, categories=data["categories"], current_category=cat, heading=cat)


@app.get("/stores/{slug}", response_class=HTMLResponse, include_in_schema=False)
async def store_page(request: Request, slug: str):
    b = base_url(request)
    try:
        data = await cached(f"store:{slug}", "catalog", f"/api/stores/{slug}")
    except httpx.HTTPError:
        return outage(request, f"/stores/{slug}")
    if not data:
        return not_found(request)
    st, products = data["store"], data["products"]
    groups: dict[str, list] = {}
    for p in products:
        groups.setdefault(p["category"] or "Other", []).append(p)
    items_ld = dict(store_ld(b, st), hasOfferCatalog={"@type": "OfferCatalog", "name": f"{st['name']} products",
                                                       "itemListElement": [{"@type": "Offer", "itemOffered": {"@type": "Product", "name": p["name"], "url": b + product_path(p)},
                                                                            "price": f"{p['price_cents'] / 100:.2f}", "priceCurrency": "USD"} for p in products[:60]]})
    return page(request, "store.html", title=f"{st['name']} · {st['category']} Delivery in {st['city']}, {st['state']} · BuckDuck",
                description=f"{st['name']}: {st.get('tagline') or st['category']}. Order online from {len(products)} products — packed in BuckDuck bags and delivered Saturday in {st['city']}.",
                path=f"/stores/{slug}", jsonld=[items_ld, breadcrumbs(request, [("Home", "/"), ("Stores", "/stores"), (st["name"], f"/stores/{slug}")])],
                store=st, groups=groups, products=products, windows=await next_windows(),
                og_image=b + st["logo_url"] if st.get("logo_url") else None)


@app.get("/products/{pid_slug}", response_class=HTMLResponse, include_in_schema=False)
async def product_page(request: Request, pid_slug: str):
    m = re.match(r"^(\d+)(?:-(.*))?$", pid_slug)
    if not m:
        return not_found(request)
    b = base_url(request)
    try:
        data = await cached(f"product:{m.group(1)}", "catalog", f"/api/products/{m.group(1)}")
    except httpx.HTTPError:
        return outage(request, f"/products/{pid_slug}")
    if not data:
        return not_found(request)
    p, st = data["product"], data["store"]
    canonical = product_path(p)
    if request.url.path != canonical:
        return RedirectResponse(canonical, status_code=301)
    prod_ld = {"@context": "https://schema.org", "@type": "Product", "name": p["name"], "description": p.get("description") or p["name"],
               "category": p.get("category"), "sku": f"BD-{p['id']}", "brand": {"@type": "Brand", "name": st["name"]}, "offers": offer(b, p, st)}
    if p.get("image_url"):
        prod_ld["image"] = b + p["image_url"]
    return page(request, "product.html", title=f"{p['name']} — {money(p['price_cents'])} at {st['name']} · BuckDuck",
                description=f"Buy {p['name']} ({p.get('unit') or 'each'}) for {money(p['price_cents'])} from {st['name']} in {st['city']}. Delivered Saturday in sealed BuckDuck bags.",
                path=canonical, jsonld=[prod_ld, breadcrumbs(request, [("Home", "/"), ("Stores", "/stores"), (st["name"], f"/stores/{st['slug']}"), (p["name"], canonical)])],
                product=dict(p, store_id=st["id"], store_name=st["name"], store_slug=st["slug"]), store=st, related=data["related"],
                windows=await next_windows(), og_image=b + p["image_url"] if p.get("image_url") else None)


@app.get("/search", response_class=HTMLResponse, include_in_schema=False)
async def search(request: Request, q: str = ""):
    q = q.strip()[:60]
    try:
        data = await cached(f"search:{q.lower()}", "catalog", "/api/search", params={"q": q}, ttl=20) if q else {"products": []}
    except httpx.HTTPError:
        return outage(request, "/search")
    return page(request, "search.html", title=f"“{q}” — search StoreFront USA" if q else "Search StoreFront USA",
                description="Search products across every StoreFront USA store.", path="/search", noindex=True, q=q, products=data["products"])


FAQ = [
    ("When does BuckDuck deliver?", "Every Saturday, in two windows: Morning (6 AM–12 PM) and Afternoon (12 PM–4 PM). You choose your window at checkout."),
    ("When do I need to order by?", "Orders close 24 hours before each window starts, so stores have time to pack. The next cutoff is shown on every page."),
    ("Can I order from more than one store?", "Yes. Fill one cart from as many stores as you like. Each store packs its part in sealed BuckDuck bags and everything arrives in the same window."),
    ("How much does delivery cost?", "Delivery is $5.99 per store, plus a 5% service fee (minimum $1.99). Tips are optional and go 100% to your driver."),
    ("How do I pay?", "Pay securely with a credit or debit card, Apple Pay or Google Pay. Payments are processed by Stripe; BuckDuck never stores your card."),
    ("Can I cancel?", "You can cancel for a full refund until the store accepts your order. After that, contact support and we will help."),
]


@app.get("/how-it-works", response_class=HTMLResponse, include_in_schema=False)
async def how_it_works(request: Request):
    faq_ld = {"@context": "https://schema.org", "@type": "FAQPage",
              "mainEntity": [{"@type": "Question", "name": q, "acceptedAnswer": {"@type": "Answer", "text": a}} for q, a in FAQ]}
    return page(request, "how.html", title="How BuckDuck Saturday Grocery Delivery Works", path="/how-it-works",
                description="Order from several local grocery stores in one cart, pick a Saturday window, and get everything delivered in sealed BuckDuck bags. Fees, cutoffs and FAQs.",
                jsonld=[faq_ld, breadcrumbs(request, [("Home", "/"), ("How it works", "/how-it-works")])], faq=FAQ, windows=await next_windows())


@app.get("/sell", response_class=HTMLResponse, include_in_schema=False)
async def sell(request: Request):
    return page(request, "sell.html", title="Sell on StoreFront USA · Open Your Grocery Storefront", path="/sell",
                description="Open a branded online storefront for your grocery store. BuckDuck handles payments, packaging and Saturday delivery. 15% commission, no setup fees.",
                jsonld=[breadcrumbs(request, [("Home", "/"), ("Sell on StoreFront USA", "/sell")])])


@app.get("/drive", response_class=HTMLResponse, include_in_schema=False)
async def drive(request: Request):
    return page(request, "drive.html", title="Drive with BuckDuck · Saturday Delivery Driver Jobs", path="/drive",
                description="Earn base pay per delivery plus 100% of tips on batched Saturday grocery routes. Morning and afternoon shifts. Apply in minutes.",
                jsonld=[breadcrumbs(request, [("Home", "/"), ("Drive with BuckDuck", "/drive")])])


# ------------------------------------------------------------------ crawl files
@app.get("/robots.txt", response_class=PlainTextResponse, include_in_schema=False)
async def robots(request: Request):
    return PlainTextResponse(f"User-agent: *\nAllow: /\nDisallow: /app/\nDisallow: /api/\nDisallow: /search\n\nSitemap: {base_url(request)}/sitemap.xml\n")


@app.get("/sitemap.xml", include_in_schema=False)
async def sitemap(request: Request):
    b = base_url(request)
    try:
        data = await cached("sitemap", "catalog", "/api/catalog/sitemap", ttl=300)
    except httpx.HTTPError:
        data = {"stores": [], "products": [], "categories": []}
    urls = [(b + "/", None, "daily", "1.0"), (b + "/stores", None, "daily", "0.9"), (b + "/how-it-works", None, "monthly", "0.6"),
            (b + "/sell", None, "monthly", "0.5"), (b + "/drive", None, "monthly", "0.5")]
    urls += [(b + category_path(c), None, "weekly", "0.7") for c in data["categories"]]
    urls += [(f"{b}/stores/{s['slug']}", (s["lastmod"] or "")[:10] or None, "daily", "0.8") for s in data["stores"]]
    urls += [(b + product_path(p), (p["lastmod"] or "")[:10] or None, "weekly", "0.6") for p in data["products"]]
    xml = jinja.get_template("sitemap.xml").render(urls=urls)
    return Response(xml, media_type="application/xml", headers={"Cache-Control": "public, max-age=600"})


# ------------------------------------------------------------------ the signed-in app (portals) + PWA files
@app.get("/app", include_in_schema=False)
async def app_redirect():
    return RedirectResponse("/app/", status_code=301)


@app.get("/app/", response_class=HTMLResponse, include_in_schema=False)
async def spa(request: Request):
    return HTMLResponse(jinja.get_template("app.html").render(site=SITE), headers={"Cache-Control": "no-cache", "X-Robots-Tag": "noindex"})


@app.get("/sw.js", include_in_schema=False)
async def sw():
    return FileResponse(HERE / "static" / "sw.js", media_type="application/javascript", headers={"Cache-Control": "no-cache"})


@app.get("/manifest.webmanifest", include_in_schema=False)
async def manifest():
    return FileResponse(HERE / "static" / "manifest.webmanifest", media_type="application/manifest+json")


@app.get("/favicon.ico", include_in_schema=False)
async def favicon():
    return FileResponse(HERE / "static" / "icons" / "icon-192.png", media_type="image/png")


@app.get("/.well-known/apple-developer-merchantid-domain-association", include_in_schema=False)
async def apple_pay_domain():
    f = HERE / "static" / ".well-known" / "apple-developer-merchantid-domain-association"
    return FileResponse(f) if f.is_file() else PlainTextResponse("Not configured", status_code=404)


@app.middleware("http")
async def security_headers(request: Request, call_next):
    resp = await call_next(request)
    resp.headers.setdefault("X-Content-Type-Options", "nosniff")
    resp.headers.setdefault("Referrer-Policy", "strict-origin-when-cross-origin")
    resp.headers.setdefault("X-Frame-Options", "SAMEORIGIN")
    resp.headers.setdefault("Permissions-Policy", "camera=(self), geolocation=(), microphone=()")
    resp.headers.setdefault("Content-Security-Policy", "default-src 'self'; script-src 'self' https://js.stripe.com https://pay.google.com; "
                            "frame-src https://js.stripe.com https://hooks.stripe.com https://pay.google.com; connect-src 'self' https://api.stripe.com; "
                            "img-src 'self' data: blob: https:; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; "
                            "font-src 'self' https://fonts.gstatic.com data:; script-src-attr 'none'; base-uri 'self'; form-action 'self'")
    if request.url.scheme == "https" or request.headers.get("x-forwarded-proto") == "https":
        resp.headers.setdefault("Strict-Transport-Security", "max-age=31536000; includeSubDomains")
    return resp


@app.exception_handler(404)
async def html_404(request: Request, exc):
    if request.url.path.startswith(("/api/", "/static/", "/media/")):
        return JSONResponse({"error": "Not found"}, status_code=404)
    return not_found(request)
