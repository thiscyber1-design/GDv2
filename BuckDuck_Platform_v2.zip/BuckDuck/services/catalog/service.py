"""Catalog service — stores, storefronts, products, stock and product photos.

Owns: stores, products, catalog settings. Database: its own (CATALOG_DATABASE_URL).
Works on its own: browsing and search keep running even if ordering or payments are down.
"""
from __future__ import annotations

from pathlib import Path

from fastapi import Depends, HTTPException
from fastapi.responses import FileResponse
from sqlalchemy import Column, Float, Integer, MetaData, String, Table, Text

from buckduck_common import seed
from buckduck_common.app import create_app
from buckduck_common.auth import internal_only, require
from buckduck_common.config import DATA_DIR, database_url, env
from buckduck_common.db import Database
from buckduck_common.http import try_call
from buckduck_common.util import now_iso, req, s, save_image, slugify, to_int

md = MetaData()
Table("stores", md,
      Column("id", Integer, primary_key=True, autoincrement=True),
      Column("owner_id", Integer, nullable=False, index=True),
      Column("name", String(80), nullable=False), Column("slug", String(80), unique=True, nullable=False),
      Column("tagline", String(140)), Column("description", Text), Column("category", String(60)),
      Column("address", String(160)), Column("city", String(60)), Column("state", String(2)), Column("zip", String(10)),
      Column("phone", String(30)), Column("color", String(7)), Column("emoji", String(8)), Column("logo_url", String(200)),
      Column("status", String(20), nullable=False, default="pending", index=True),
      Column("commission_rate", Float, nullable=False, default=0.15), Column("rating", Float, nullable=False, default=4.8),
      Column("created_at", String(40), nullable=False), Column("updated_at", String(40)))
Table("products", md,
      Column("id", Integer, primary_key=True, autoincrement=True),
      Column("store_id", Integer, nullable=False, index=True),
      Column("name", String(100), nullable=False), Column("description", Text), Column("category", String(60)),
      Column("price_cents", Integer, nullable=False), Column("unit", String(40)), Column("stock", Integer, nullable=False, default=0),
      Column("emoji", String(8)), Column("image_url", String(200)), Column("active", Integer, nullable=False, default=1),
      Column("created_at", String(40), nullable=False), Column("updated_at", String(40)))
Table("catalog_settings", md, Column("key", String(60), primary_key=True), Column("value", String(200), nullable=False))
# Stock changes are applied idempotently: each order id is recorded once per direction.
Table("stock_movements", md,
      Column("id", Integer, primary_key=True, autoincrement=True),
      Column("order_id", Integer, nullable=False), Column("direction", String(10), nullable=False),
      Column("created_at", String(40), nullable=False))

db = Database(database_url("catalog"), md)
app = create_app("catalog", "Stores, storefronts, products and stock.", db=db)
MEDIA_DIR = Path(env("MEDIA_DIR", str(DATA_DIR / "media")))
DEFAULTS = {"default_commission_rate": "0.15"}
STORE_PUBLIC = "id,name,slug,tagline,description,category,address,city,state,zip,phone,color,emoji,logo_url,rating,status,created_at,updated_at"
PRODUCT_PUBLIC = "id,store_id,name,description,category,price_cents,unit,stock,emoji,image_url,created_at,updated_at"


def setting(key: str) -> str:
    r = db.one("SELECT value FROM catalog_settings WHERE key=:k", k=key)
    return r["value"] if r else DEFAULTS[key]


@app.on_event("startup")
def startup():
    db.create_all()
    MEDIA_DIR.mkdir(parents=True, exist_ok=True)
    if env("SEED_DEMO_DATA", "true") == "true" and not db.scalar("SELECT COUNT(*) FROM stores"):
        d = seed.dataset()
        with db.tx() as t:
            t.insert_many("stores", [{k: st[k] for k in ("id", "owner_id", "name", "slug", "tagline", "description", "category", "address", "city", "state",
                                                          "zip", "phone", "color", "emoji", "logo_url", "status", "commission_rate", "rating", "created_at")}
                                     for st in d["stores"]])
            t.insert_many("products", d["products"])
        db.fix_sequences(["stores", "products"])


# ---------------------------------------------------------------- public browsing
@app.get("/api/stores", tags=["browse"])
def list_stores(q: str = "", category: str = ""):
    like = f"%{q.lower()[:60]}%"
    sql = f"""SELECT s.id,s.name,s.slug,s.tagline,s.category,s.city,s.state,s.zip,s.color,s.emoji,s.logo_url,s.rating,s.updated_at,s.created_at,
              (SELECT COUNT(*) FROM products p WHERE p.store_id=s.id AND p.active=1) AS product_count
              FROM stores s WHERE s.status='active' AND (LOWER(s.name) LIKE :q OR LOWER(s.category) LIKE :q OR LOWER(COALESCE(s.tagline,'')) LIKE :q)"""
    p = {"q": like}
    if category:
        sql += " AND s.category=:c"
        p["c"] = category
    stores = db.all(sql + " ORDER BY s.rating DESC, s.name", **p)
    cats = [r["category"] for r in db.all("SELECT category, COUNT(*) AS c FROM stores WHERE status='active' GROUP BY category ORDER BY c DESC, category")]
    return {"stores": stores, "categories": cats}


@app.get("/api/stores/{slug}", tags=["browse"])
def get_store(slug: str):
    st = db.one(f"SELECT {STORE_PUBLIC} FROM stores WHERE slug=:s", s=slug)
    if not st or st["status"] != "active":
        raise HTTPException(404, "Store not found")
    products = db.all(f"SELECT {PRODUCT_PUBLIC} FROM products WHERE store_id=:id AND active=1 ORDER BY category, name", id=st["id"])
    return {"store": st, "products": products}


@app.get("/api/products/{pid}", tags=["browse"])
def get_product(pid: int):
    p = db.one(f"SELECT {PRODUCT_PUBLIC}, active FROM products WHERE id=:id", id=pid)
    st = db.one(f"SELECT {STORE_PUBLIC} FROM stores WHERE id=:id", id=p["store_id"]) if p else None
    if not p or not p["active"] or not st or st["status"] != "active":
        raise HTTPException(404, "Product not found")
    related = db.all(f"SELECT {PRODUCT_PUBLIC} FROM products WHERE store_id=:s AND active=1 AND id<>:id ORDER BY (category=:c) DESC, name LIMIT 8",
                     s=st["id"], id=pid, c=p["category"])
    return {"product": p, "store": st, "related": related}


@app.get("/api/search", tags=["browse"])
def search(q: str = ""):
    q = q.strip()[:60]
    if not q:
        return {"products": []}
    return {"products": db.all("""SELECT p.id,p.name,p.category,p.price_cents,p.unit,p.stock,p.emoji,p.image_url,
        s.name AS store_name,s.slug AS store_slug,s.id AS store_id FROM products p JOIN stores s ON s.id=p.store_id
        WHERE p.active=1 AND s.status='active' AND (LOWER(p.name) LIKE :q OR LOWER(p.category) LIKE :q) ORDER BY p.name LIMIT 60""", q=f"%{q.lower()}%")}


@app.get("/api/catalog/sitemap", tags=["browse"])
def sitemap_entries():
    """Everything a search engine should index, with last-modified dates."""
    stores = db.all("SELECT id,slug,category,COALESCE(updated_at,created_at) AS lastmod FROM stores WHERE status='active'")
    products = db.all("""SELECT p.id,p.name,COALESCE(p.updated_at,p.created_at) AS lastmod FROM products p JOIN stores s ON s.id=p.store_id
                         WHERE p.active=1 AND s.status='active'""")
    return {"stores": stores, "products": products, "categories": sorted({x["category"] for x in stores if x["category"]})}


@app.get("/media/{name}", tags=["browse"])
def media(name: str):
    f = (MEDIA_DIR / name).resolve()
    if MEDIA_DIR.resolve() not in f.parents or not f.is_file():
        raise HTTPException(404, "Not found")
    return FileResponse(f, headers={"Cache-Control": "public, max-age=2592000, immutable"})


# ---------------------------------------------------------------- merchant
def my_store(user: dict) -> dict:
    st = db.one("SELECT * FROM stores WHERE owner_id=:o", o=user["id"])
    if not st:
        raise HTTPException(404, "No store found for this account")
    return st


@app.get("/api/merchant/store", tags=["merchant"])
def merchant_store(user=Depends(require("merchant"))):
    return {"store": my_store(user)}


@app.put("/api/merchant/store", tags=["merchant"])
def update_store(body: dict, user=Depends(require("merchant"))):
    st = my_store(user)
    logo = save_image(body["logo_data"], MEDIA_DIR, 2 * 1024 * 1024) if body.get("logo_data") else st["logo_url"]
    color = body.get("color") if isinstance(body.get("color"), str) and len(body["color"]) == 7 and body["color"].startswith("#") else st["color"]
    pick = lambda k, n: s(body[k] if body.get(k) is not None else st[k], n)  # noqa: E731
    db.one("""UPDATE stores SET name=:name, tagline=:tagline, description=:description, category=:category, address=:address, city=:city,
              state=:state, zip=:zip, phone=:phone, color=:color, emoji=:emoji, logo_url=:logo, updated_at=:u WHERE id=:id RETURNING id""",
           name=req(body.get("name") or st["name"], "Store name", 80), tagline=pick("tagline", 120), description=pick("description", 1000),
           category=pick("category", 60), address=pick("address", 160), city=pick("city", 60), state=pick("state", 2).upper(), zip=pick("zip", 10),
           phone=pick("phone", 30), color=color, emoji=pick("emoji", 8) or "🛒", logo=logo, u=now_iso(), id=st["id"])
    return {"store": my_store(user)}


@app.get("/api/merchant/products", tags=["merchant"])
def merchant_products(user=Depends(require("merchant"))):
    return {"products": db.all("SELECT * FROM products WHERE store_id=:s ORDER BY category, name", s=my_store(user)["id"])}


def product_fields(body: dict, existing: dict | None = None) -> dict:
    e = existing or {}
    try:
        price = round(float(body["price"]) * 100) if body.get("price") not in (None, "") else e.get("price_cents")
    except (TypeError, ValueError):
        price = None
    if not price or price <= 0 or price > 1_000_000:
        raise HTTPException(400, "Enter a valid price")
    image = e.get("image_url")
    if body.get("image_data"):
        image = save_image(body["image_data"], MEDIA_DIR)
    if body.get("remove_image"):
        image = None
    val = lambda k, n: s(body[k] if body.get(k) is not None else e.get(k), n)  # noqa: E731
    active = e.get("active", 1) if body.get("active") is None else (1 if body.get("active") in (True, 1, "1", "true", "on") else 0)
    return dict(name=req(body.get("name") or e.get("name"), "Product name", 100), description=val("description", 500),
                category=val("category", 60) or "General", price_cents=price, unit=val("unit", 40),
                stock=max(0, to_int(body.get("stock") if body.get("stock") is not None else e.get("stock"))),
                emoji=val("emoji", 8) or "🛒", image_url=image, active=active, updated_at=now_iso())


@app.post("/api/merchant/products", tags=["merchant"])
def create_product(body: dict, user=Depends(require("merchant"))):
    st = my_store(user)
    f = product_fields(body)
    with db.tx() as t:
        pid = t.insert("products", dict(f, store_id=st["id"], created_at=now_iso()))
    return {"product": db.one("SELECT * FROM products WHERE id=:id", id=pid)}


@app.put("/api/merchant/products/{pid}", tags=["merchant"])
def update_product(pid: int, body: dict, user=Depends(require("merchant"))):
    st = my_store(user)
    p = db.one("SELECT * FROM products WHERE id=:id AND store_id=:s", id=pid, s=st["id"])
    if not p:
        raise HTTPException(404, "Product not found")
    f = product_fields(body, p)
    db.one("UPDATE products SET " + ", ".join(f"{k}=:{k}" for k in f) + " WHERE id=:id RETURNING id", **f, id=pid)
    return {"product": db.one("SELECT * FROM products WHERE id=:id", id=pid)}


@app.delete("/api/merchant/products/{pid}", tags=["merchant"])
def delete_product(pid: int, user=Depends(require("merchant"))):
    st = my_store(user)
    if not db.one("UPDATE products SET active=0, updated_at=:u WHERE id=:id AND store_id=:s RETURNING id", u=now_iso(), id=pid, s=st["id"]):
        raise HTTPException(404, "Product not found")
    return {"ok": True}


# ---------------------------------------------------------------- admin
@app.get("/api/admin/stores", tags=["admin"])
def admin_stores(_=Depends(require("admin"))):
    stores = db.all("""SELECT s.*, (SELECT COUNT(*) FROM products p WHERE p.store_id=s.id AND p.active=1) AS product_count FROM stores s
                       ORDER BY CASE s.status WHEN 'pending' THEN 0 ELSE 1 END, s.name""")
    owners = {u["id"]: u for u in (try_call("identity", "GET", "/internal/users", fallback={},
                                            params={"ids": ",".join(str(x["owner_id"]) for x in stores)}) or {}).get("users", [])}
    sales = try_call("orders", "GET", "/internal/stats/store-sales", fallback={}) or {}
    for st in stores:
        o = owners.get(st["owner_id"], {})
        sv = sales.get(str(st["id"]), {})
        st.update(owner_name=o.get("name", f"Owner #{st['owner_id']}"), owner_email=o.get("email", ""),
                  delivered_orders=sv.get("orders", 0), sales_cents=sv.get("sales", 0))
    return {"stores": stores}


@app.post("/api/admin/stores/{sid}", tags=["admin"])
def admin_store_update(sid: int, body: dict, _=Depends(require("admin"))):
    st = db.one("SELECT * FROM stores WHERE id=:id", id=sid)
    if not st:
        raise HTTPException(404, "Store not found")
    status = body.get("status") if body.get("status") in ("pending", "active", "suspended") else st["status"]
    rate = st["commission_rate"] if body.get("commission_rate") is None else float(body["commission_rate"])
    if not 0 <= rate <= 0.5:
        raise HTTPException(400, "Commission must be between 0% and 50%")
    db.one("UPDATE stores SET status=:s, commission_rate=:r, updated_at=:u WHERE id=:id RETURNING id", s=status, r=rate, u=now_iso(), id=sid)
    return {"store": db.one("SELECT * FROM stores WHERE id=:id", id=sid)}


@app.get("/api/admin/settings", tags=["admin"])
def get_settings(_=Depends(require("admin"))):
    return {"settings": {k: setting(k) for k in DEFAULTS}}


@app.put("/api/admin/settings", tags=["admin"])
def put_settings(body: dict, _=Depends(require("admin"))):
    for k, v in (body or {}).items():
        if k not in DEFAULTS:
            continue
        try:
            if not 0 <= float(v) <= 0.5:
                raise ValueError
        except (TypeError, ValueError):
            raise HTTPException(400, "Default commission must be between 0 and 0.5")  # noqa: B904
        db.one("INSERT INTO catalog_settings(key,value) VALUES(:k,:v) ON CONFLICT(key) DO UPDATE SET value=excluded.value RETURNING key", k=k, v=str(v))
    return get_settings()


# ---------------------------------------------------------------- internal (service-to-service)
INTERNAL = [Depends(internal_only)]


@app.post("/internal/stores", dependencies=INTERNAL, tags=["internal"])
def internal_create_store(body: dict):
    owner = to_int(body.get("owner_id"))
    if db.one("SELECT id FROM stores WHERE owner_id=:o", o=owner):
        return {"store": db.one("SELECT * FROM stores WHERE owner_id=:o", o=owner)}
    name = req(body.get("name"), "Store name", 80)
    slug, n = slugify(name), 1
    while db.one("SELECT id FROM stores WHERE slug=:s", s=slug):
        n += 1
        slug = f"{slugify(name)}-{n}"
    with db.tx() as t:
        sid = t.insert("stores", dict(owner_id=owner, name=name, slug=slug, tagline=s(body.get("tagline"), 120), description=s(body.get("description"), 1000),
                                      category=s(body.get("category"), 60) or "Groceries", address=s(body.get("address"), 160), city=s(body.get("city"), 60),
                                      state=s(body.get("state"), 2).upper(), zip=s(body.get("zip"), 10), phone=s(body.get("phone"), 30), color="#1E3A8A",
                                      emoji="🛒", status="pending", commission_rate=float(setting("default_commission_rate")), rating=4.8, created_at=now_iso()))
    return {"store": db.one("SELECT * FROM stores WHERE id=:id", id=sid)}


@app.get("/internal/stores/by-owner/{owner_id}", dependencies=INTERNAL, tags=["internal"])
def internal_store_by_owner(owner_id: int):
    return {"store": db.one("SELECT * FROM stores WHERE owner_id=:o", o=owner_id)}


@app.get("/internal/stores/{sid}/low-stock", dependencies=INTERNAL, tags=["internal"])
def internal_low_stock(sid: int):
    return {"products": db.all("SELECT id,name,emoji,stock FROM products WHERE store_id=:s AND active=1 AND stock<15 ORDER BY stock LIMIT 6", s=sid)}


@app.post("/internal/products/lookup", dependencies=INTERNAL, tags=["internal"])
def internal_lookup(body: dict):
    """Authoritative prices and store details for checkout. Client-sent prices are never trusted."""
    ids = [to_int(i) for i in body.get("ids", [])][:200]
    if not ids:
        return {"products": []}
    rows = db.all(f"""SELECT p.id,p.store_id,p.name,p.price_cents,p.unit,p.stock,p.emoji,p.active,
        s.name AS store_name,s.slug AS store_slug,s.status AS store_status,s.commission_rate,s.owner_id AS store_owner_id,s.emoji AS store_emoji,
        s.color AS store_color,s.address AS store_address,s.city AS store_city,s.zip AS store_zip,s.phone AS store_phone
        FROM products p JOIN stores s ON s.id=p.store_id WHERE p.id IN ({','.join(str(i) for i in ids)})""")
    return {"products": rows}


@app.post("/internal/stock/{direction}", dependencies=INTERNAL, tags=["internal"])
def internal_stock(direction: str, body: dict):
    """direction=decrement when an order is paid, restore when it is cancelled. Idempotent per order."""
    if direction not in ("decrement", "restore"):
        raise HTTPException(404, "Not found")
    oid = to_int(body.get("order_id"))
    with db.tx() as t:
        if t.one("SELECT id FROM stock_movements WHERE order_id=:o AND direction=:d", o=oid, d=direction):
            return {"ok": True, "duplicate": True}
        if direction == "restore" and not t.one("SELECT id FROM stock_movements WHERE order_id=:o AND direction='decrement'", o=oid):
            return {"ok": True, "skipped": True}
        for it in body.get("items", []):
            q = max(0, to_int(it.get("qty")))
            if direction == "decrement":
                cur = t.scalar("SELECT stock FROM products WHERE id=:id", id=to_int(it.get("product_id")))
                if cur is not None:
                    t.run("UPDATE products SET stock=:v WHERE id=:id", v=max(0, int(cur) - q), id=to_int(it.get("product_id")))
            else:
                t.run("UPDATE products SET stock=stock+:q WHERE id=:id", q=q, id=to_int(it.get("product_id")))
        t.insert("stock_movements", dict(order_id=oid, direction=direction, created_at=now_iso()))
    return {"ok": True}


@app.get("/internal/stats", dependencies=INTERNAL, tags=["internal"])
def internal_stats():
    return {r["status"]: r["c"] for r in db.all("SELECT status, COUNT(*) AS c FROM stores GROUP BY status")}
