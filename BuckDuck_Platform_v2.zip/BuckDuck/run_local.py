#!/usr/bin/env python3
"""Run the whole BuckDuck platform locally — one process per microservice.

    python run_local.py                 # all services, SQLite database per service in ./data
    python run_local.py catalog web     # only the services you name (each still works on its own)

Open http://localhost:8000 . Stop with Ctrl-C.
"""
from __future__ import annotations

import os
import signal
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SERVICES = {"identity": 8001, "catalog": 8002, "orders": 8003, "payments": 8004, "delivery": 8005, "web": 8000}


def main() -> None:
    wanted = [a for a in sys.argv[1:] if a in SERVICES] or list(SERVICES)
    env = dict(os.environ)
    env.setdefault("DATA_DIR", str(ROOT / "data"))
    for name, port in SERVICES.items():
        env.setdefault(f"{name.upper()}_URL", f"http://127.0.0.1:{port}")
    procs = []
    # Start back-end services first, the web front end last.
    for name in sorted(wanted, key=lambda n: n == "web"):
        port = SERVICES[name]
        e = dict(env, PYTHONPATH=os.pathsep.join([str(ROOT / "services" / "common"), str(ROOT / "services" / name)]), SERVICE_NAME=name)
        cmd = [sys.executable, "-m", "uvicorn", "service:app", "--host", "127.0.0.1", "--port", str(port), "--log-level", "warning"]
        procs.append((name, subprocess.Popen(cmd, cwd=ROOT / "services" / name, env=e)))
        print(f"  {name:<9} http://127.0.0.1:{port}  (docs: /docs)")
        time.sleep(0.3)
    print("\nBuckDuck is starting — open http://localhost:8000   (Ctrl-C to stop)\n")

    def stop(*_):
        for _, p in procs:
            p.terminate()
        for _, p in procs:
            try:
                p.wait(timeout=8)
            except subprocess.TimeoutExpired:
                p.kill()
        sys.exit(0)

    signal.signal(signal.SIGINT, stop)
    signal.signal(signal.SIGTERM, stop)
    while True:
        for name, p in procs:
            if p.poll() is not None:
                print(f"!! {name} exited with code {p.returncode}")
                procs.remove((name, p))
        time.sleep(1)


if __name__ == "__main__":
    main()
