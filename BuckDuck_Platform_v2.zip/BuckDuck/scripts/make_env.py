#!/usr/bin/env python3
"""Create a .env file from .env.example with strong random secrets filled in.

    python scripts/make_env.py                 # demo mode, simulated payments
    python scripts/make_env.py --production    # DEMO_MODE=false, no demo data
"""
import re
import secrets
import sys
from pathlib import Path

root = Path(__file__).resolve().parents[1]
dest = root / ".env"
if dest.exists() and "--force" not in sys.argv:
    sys.exit(".env already exists (use --force to overwrite)")
SECRET_KEYS = {"JWT_SECRET", "INTERNAL_TOKEN", "POSTGRES_ADMIN_PASSWORD", "IDENTITY_DB_PASSWORD", "CATALOG_DB_PASSWORD",
               "ORDERS_DB_PASSWORD", "PAYMENTS_DB_PASSWORD", "DELIVERY_DB_PASSWORD"}
prod = "--production" in sys.argv
out = []
for line in (root / ".env.example").read_text().splitlines():
    m = re.match(r"^([A-Z_]+)=(.*)$", line)
    if m and m.group(1) in SECRET_KEYS and not m.group(2):
        line = f"{m.group(1)}={secrets.token_urlsafe(36)}"
    elif m and prod and m.group(1) in ("DEMO_MODE", "SEED_DEMO_DATA"):
        line = f"{m.group(1)}=false"
    out.append(line)
dest.write_text("\n".join(out) + "\n")
dest.chmod(0o600)
print(f"Wrote {dest} with fresh secrets. Add your Stripe keys and PUBLIC_BASE_URL before going live.")
